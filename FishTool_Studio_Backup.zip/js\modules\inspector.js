function syncControllerUI() {
  if (!selectedTrackRow) return;
  const id = selectedTrackRow.dataset.layerId || 'default';
  const t = getLayerTransform(id);

  const valPosX = document.getElementById('val-pos-x');
  const valPosY = document.getElementById('val-pos-y');
  const valPosZ = document.getElementById('val-pos-z');
  if (valPosX) valPosX.textContent = Number(t.posX).toFixed(2);
  if (valPosY) valPosY.textContent = Number(-t.posY).toFixed(2);
  if (valPosZ) valPosZ.textContent = Number(t.posZ).toFixed(2);

  updateInfiniteRuler('z-ruler', -t.posZ);

  renderDialRotation(t);

  const valScaleW = document.getElementById('val-scale-w');
  const valScaleH = document.getElementById('val-scale-h');
  if (valScaleW) valScaleW.textContent = Number(t.scaleW).toFixed(1);
  if (valScaleH) valScaleH.textContent = Number(t.scaleH).toFixed(1);

  updateInfiniteRuler('ruler-w', (t.scaleW - 100) * 2);
  updateInfiniteRuler('ruler-h', (t.scaleH - 100) * 2);

  const linkBtn = document.getElementById('btn-link');
  const wheelH = document.getElementById('wheel-h');
  const wheelArea = document.querySelector('.controller-wheel-area');
  if (linkBtn) linkBtn.classList.toggle('linked', t.isLinked);
  if (wheelH) wheelH.style.display = t.isLinked ? 'none' : 'flex';
  if (wheelArea) wheelArea.classList.toggle('linked-mode', !!t.isLinked);

  const opacitySlider = document.getElementById('opacity-slider');
  const valOpacity = document.getElementById('val-opacity');
  if (opacitySlider) {
    opacitySlider.value = t.opacity;
    opacitySlider.style.background = `linear-gradient(to right, #FAB778 ${t.opacity}%, rgba(0, 0, 0, 0.3) ${t.opacity}%)`;
  }
  if (valOpacity) valOpacity.textContent = `${Math.round(t.opacity)}%`;

  document.querySelectorAll('.controller-blend-item').forEach(item => {
    item.classList.toggle('is-selected', item.dataset.mode === t.blendMode);
  });

  updateKeyframeUI();
  requestAllKeyframeMarkersRender();
  applyTransformToThreeMesh(id, t);
  requestCanvasOverlayRender();
  render3D();
}

let _overlayRaf = null;
function requestCanvasOverlayRender() {
  if (_overlayRaf) return;
  _overlayRaf = requestAnimationFrame(() => {
    _overlayRaf = null;
    renderCanvasOverlay();
  });
}

let _kfMarkersRaf = null;
function requestAllKeyframeMarkersRender() {
  if (_kfMarkersRaf) return;
  _kfMarkersRaf = requestAnimationFrame(() => {
    _kfMarkersRaf = null;
    renderAllKeyframeMarkers();
  });
}


let globalRotationDialInstance = null;

function renderDialRotation(t) {
  const axis = (t && t.rotationAxis) || activeRotationAxis || 'Z';
  activeRotationAxis = axis;
  const curRot = axis === 'X' ? t.rotX : (axis === 'Y' ? t.rotY : t.rotZ);

  if (globalRotationDialInstance) {
    globalRotationDialInstance.setValue(curRot);
  } else {
    // Fallback if FishUI instance is still initializing
    const valRot = document.getElementById('val-rot');
    const rotMult = document.getElementById('rot-multiplier');
    const knob = document.getElementById('dial-knob');
    const trail = document.getElementById('dial-trail-path');
    const trailOverlay = document.getElementById('dial-trail-overlay-path');

    const absDeg = Math.abs(curRot);
    const turns = Math.floor(absDeg / 360);
    const remainder = absDeg % 360;
    const sign = curRot < 0 ? '-' : '+';

    if (rotMult) {
      if (turns > 0) {
        rotMult.textContent = `${turns}×`;
        rotMult.style.display = 'block';
      } else {
        rotMult.textContent = '';
        rotMult.style.display = 'none';
      }
    }

    if (valRot) {
      const dispDeg = turns > 0 ? Math.round(remainder) : Math.round(absDeg);
      valRot.textContent = `${sign}${dispDeg}°`;
    }

    const dialEl = document.getElementById('dial-area');
    const w = dialEl && dialEl.clientWidth > 0 ? dialEl.clientWidth : 116;
    const h = dialEl && dialEl.clientHeight > 0 ? dialEl.clientHeight : 116;
    const cx = w / 2;
    const cy = h / 2;
    const trackRadius = (75 / 180) * w;
    const radius = trackRadius;

    const rad = ((curRot - 90) * Math.PI) / 180;
    const kx = cx + trackRadius * Math.cos(rad);
    const ky = cy + trackRadius * Math.sin(rad);

    if (knob) {
      knob.style.left = `${kx}px`;
      knob.style.top = `${ky}px`;
      knob.style.transform = 'translate(-50%, -50%)';
    }

    const fullCirclePath = `M ${cx} ${cy - radius} A ${radius} ${radius} 0 1 1 ${cx} ${cy + radius} A ${radius} ${radius} 0 1 1 ${cx} ${cy - radius}`;
    const startX = cx;
    const startY = cy - radius;

    if (trail) {
      if (absDeg < 0.5) {
        trail.setAttribute('d', '');
      } else if (absDeg >= 360) {
        trail.setAttribute('d', fullCirclePath);
      } else {
        const sweep = curRot > 0 ? 1 : 0;
        const endRad = ((curRot - 90) * Math.PI) / 180;
        const endX = cx + radius * Math.cos(endRad);
        const endY = cy + radius * Math.sin(endRad);
        const largeArc = absDeg > 180 ? 1 : 0;
        trail.setAttribute('d', `M ${startX} ${startY} A ${radius} ${radius} 0 ${largeArc} ${sweep} ${endX} ${endY}`);
      }
    }

    if (trailOverlay) {
      trailOverlay.setAttribute('d', '');
    }
  }

  document.querySelectorAll('#rotation-axis-switch button').forEach(b => {
    b.classList.toggle('active', (b.dataset.rotationAxis || 'Z') === axis);
  });
}

const BLEND_MODES = [
  'NORMAL', 'DARKEN', 'MULTIPLY', 'COLOR_BURN', 'LIGHTEN', 'SCREEN',
  'COLOR_DODGE', 'OVERLAY', 'SOFT_LIGHT', 'HARD_LIGHT', 'DIFFERENCE', 'EXCLUSION'
];

function initBlendList() {
  const list = document.getElementById('blend-list');
  if (!list) return;
  list.innerHTML = '';
  BLEND_MODES.forEach(mode => {
    const item = document.createElement('div');
    item.className = 'controller-blend-item' + (mode === 'NORMAL' ? ' is-selected' : '');
    item.dataset.mode = mode;
    item.innerHTML = `
      <span>${mode.replace(/_/g, ' ')}</span>
      <span class="material-symbols-rounded">check</span>
    `;
    item.addEventListener('click', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      const t = getLayerTransform(id);
      t.blendMode = mode;
      document.querySelectorAll('.controller-blend-item').forEach(i => i.classList.remove('is-selected'));
      item.classList.add('is-selected');
    });
    list.appendChild(item);
  });
}

function initMovePad() {
  const pad = document.getElementById('move-pad');
  if (!pad) return;

  if (window.FishUI && window.FishUI.createMovePad) {
    window.FishUI.createMovePad({
      container: pad,
      sensitivityX: 2.0,
      sensitivityY: 2.0,
      invertY: true,
      onMove: ({ dx, dy }) => {
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId || 'default';
        const t = getLayerTransform(id);
        t.posX = Math.round(t.posX + dx);
        t.posY = Math.round(t.posY + dy);
        recordTransformChange(id, t);
        syncControllerUI();
      }
    });
  }
}

function initZWheel() {
  // Driven smoothly and hardware-accelerated via FishUI.createRuler on #z-ruler
}

function initRotationDial() {
  const dial = document.getElementById('dial-area');
  if (!dial) return;

  if (window.FishUI && window.FishUI.createRotationDial) {
    globalRotationDialInstance = window.FishUI.createRotationDial({
      container: dial,
      knob: document.getElementById('dial-knob'),
      trail: document.getElementById('dial-trail-path'),
      trailOverlay: document.getElementById('dial-trail-overlay-path'),
      valLabel: document.getElementById('val-rot'),
      multiplierLabel: document.getElementById('rot-multiplier'),
      onChange: (newRot) => {
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId || 'default';
        const t = getLayerTransform(id);
        if (activeRotationAxis === 'X') t.rotX = newRot;
        else if (activeRotationAxis === 'Y') t.rotY = newRot;
        else t.rotZ = newRot;
        recordTransformChange(id, t);
        syncControllerUI();
      }
    });
  }

  document.querySelectorAll('#rotation-axis-switch button').forEach(b => {
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      const axis = b.dataset.rotationAxis || 'Z';
      activeRotationAxis = axis;
      if (selectedTrackRow) {
        const id = selectedTrackRow.dataset.layerId || 'default';
        if (!layerTransforms.has(id)) {
          getLayerTransform(id);
        }
        const base = layerTransforms.get(id);
        if (base) base.rotationAxis = axis;
      }
      document.querySelectorAll('#rotation-axis-switch button').forEach(btn => {
        btn.classList.toggle('active', (btn.dataset.rotationAxis || 'Z') === axis);
      });
      syncControllerUI();
    });
  });
}

function initScaleWheels() {
  const linkBtn = document.getElementById('btn-link');
  if (linkBtn) {
    linkBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      if (!layerTransforms.has(id)) {
        getLayerTransform(id);
      }
      const base = layerTransforms.get(id);
      if (base) {
        base.isLinked = !base.isLinked;
      }
      const t = getLayerTransform(id);
      if (base) {
        t.isLinked = base.isLinked;
      }
      recordTransformChange(id, t);
      syncControllerUI();
    });
  }
}

let globalOpacitySliderInstance = null;

function initOpacityControl() {
  const slider = document.getElementById('opacity-slider');
  if (!slider) return;

  if (window.FishUI && window.FishUI.createSlider) {
    globalOpacitySliderInstance = window.FishUI.createSlider({
      input: slider,
      valLabel: document.getElementById('val-opacity'),
      unit: '%',
      onChange: (val) => {
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId || 'default';
        const t = getLayerTransform(id);
        t.opacity = val;
        recordTransformChange(id, t);
        syncControllerUI();
      }
    });
  } else {
    slider.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      const t = getLayerTransform(id);
      t.opacity = parseFloat(slider.value) || 0;
      recordTransformChange(id, t);
      syncControllerUI();
    });
  }
}

function openInspectorSubpanel(subpanelEl, subpanelClass, onBeforeShow) {
  const drawer = document.getElementById('layerInspectorDrawer');
  const toolsGrid = document.querySelector('.inspector-tools-grid');
  const quickStrip = document.querySelector('.inspector-quick-strip');
  if (!drawer || !subpanelEl) return;

  drawer.classList.remove('subpanel-color', 'subpanel-border-shadow', 'subpanel-move', 'subpanel-graph', 'subpanel-shape');
  if (subpanelClass) drawer.classList.add('subpanel-open', subpanelClass);

  if (quickStrip) quickStrip.style.display = 'none';
  if (toolsGrid) toolsGrid.style.display = 'none';

  document.querySelectorAll('.inspector-subpanel').forEach(p => {
    if (p !== subpanelEl) p.style.display = 'none';
  });

  subpanelEl.style.display = 'flex';
  if (onBeforeShow) onBeforeShow();
}

function closeInspectorSubpanel(subpanelEl, onAfterClose) {
  const drawer = document.getElementById('layerInspectorDrawer');
  const toolsGrid = document.querySelector('.inspector-tools-grid');
  const quickStrip = document.querySelector('.inspector-quick-strip');
  if (!drawer) return;

  drawer.classList.remove('subpanel-open', 'subpanel-color', 'subpanel-move', 'subpanel-border-shadow', 'subpanel-graph', 'subpanel-shape', 'in-subpanel');

  if (subpanelEl) subpanelEl.style.display = 'none';
  document.querySelectorAll('.inspector-subpanel').forEach(p => {
    p.style.display = 'none';
  });

  if (quickStrip) quickStrip.style.display = 'flex';
  if (toolsGrid) toolsGrid.style.display = 'grid';

  if (onAfterClose) onAfterClose();
}

function initMoveTransformController() {
  initInfiniteRuler('z-ruler', true);
  initInfiniteRuler('ruler-w', false);
  initInfiniteRuler('ruler-h', false);
  initBlendList();
  initMovePad();
  initZWheel();
  initRotationDial();
  initScaleWheels();
  initOpacityControl();

  // Fish Top Tabs API — single style source (edit .fish-top-tabs / --fish-tab-* → global)
  if (window.FishUI && window.FishUI.createTopTabs) {
    window.FishUI.createTopTabs({
      container: '.controller-tab-switch',
      onSwitch: (targetPanel) => {
        activeControllerPanel = targetPanel || 'move';
        document.querySelectorAll('.controller-panel').forEach(p => {
          p.style.display = 'none';
          p.classList.remove('active');
        });
        const activeP = document.getElementById(`card-${targetPanel}`);
        if (activeP) {
          activeP.style.display = 'flex';
          activeP.classList.add('active');
        }
        updateKeyframeUI();
        renderAllKeyframeMarkers();
      }
    });
  } else {
    const switchBtns = document.querySelectorAll('.controller-tab-switch .controller-switch-btn');
    switchBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const targetPanel = btn.dataset.targetPanel || 'move';
        activeControllerPanel = targetPanel;
        switchBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.controller-panel').forEach(p => {
          p.style.display = 'none';
          p.classList.remove('active');
        });
        const activeP = document.getElementById(`card-${targetPanel}`);
        if (activeP) {
          activeP.style.display = 'flex';
          activeP.classList.add('active');
        }
        updateKeyframeUI();
        renderAllKeyframeMarkers();
      });
    });
  }

  const btnInspMove = document.getElementById('btnInspMoveTransform');
  const btnBackTools = document.getElementById('btnBackToToolsGrid');
  const toolsGrid = document.querySelector('.inspector-tools-grid');
  const quickStrip = document.querySelector('.inspector-quick-strip');
  const panelMove = document.getElementById('panelMoveTransform');

  // Modular Keyframe Controller via FishUI
  if (window.FishUI && window.FishUI.createKeyframeController) {
    globalMoveTransformKfController = window.FishUI.createKeyframeController({
      toggleButton: '#btnToggleKeyframe',
      graphButton: '#btnKeyframeGraph',
      getChannel: () => getActiveKeyframeChannel() || 'position',
      getLayerId: () => selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default',
      getCurrentTime: () => elapsed,
      getKeyframes: (layerId) => layerKeyframes.get(layerId) || [],
      getCurrentValue: (layerId, ch) => getLayerTransform(layerId),
      onToggle: () => {
        toggleKeyframe();
      },
      onOpenGraph: ({ channel }) => {
        openGraphEditor(channel || getActiveKeyframeChannel() || 'position');
      }
    });
  } else {
    const btnToggleKf = document.getElementById('btnToggleKeyframe');
    if (btnToggleKf) {
      btnToggleKf.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleKeyframe();
      });
    }
  }

  if (btnInspMove && toolsGrid && panelMove) {
    btnInspMove.addEventListener('click', (e) => {
      e.stopPropagation();
      openInspectorSubpanel(panelMove, 'subpanel-move', () => {
        syncControllerUI();
        renderAllKeyframeMarkers();
        updateKeyframeUI();
      });
    });
  }

  if (btnBackTools && toolsGrid && panelMove) {
    btnBackTools.addEventListener('click', (e) => {
      e.stopPropagation();
      closeInspectorSubpanel(panelMove, () => {
        renderAllKeyframeMarkers();
        updateKeyframeUI();
      });
    });
  }

  // Color & Fill panel toggle
  const btnInspColor = document.getElementById('btnInspColorFill');
  const panelColor = document.getElementById('panelColorFill');
  const btnBackColor = document.getElementById('btnBackFromColorFill');
  if (btnInspColor && toolsGrid && panelColor) {
    btnInspColor.addEventListener('click', (e) => {
      e.stopPropagation();
      openInspectorSubpanel(panelColor, 'subpanel-color', () => {
        // Sync UI with current layer fill
        const id = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default';
        const fill = getLayerFill(id);
        if (fill.type === 'gradient') {
          switchFillTab('gradient');
          if (fill.gradientType) activeGradientType = fill.gradientType;
          if (fill.gradientStops && fill.gradientStops.length) {
            gradientStops = fill.gradientStops.map(s => ({ offset: s.offset, color: s.color }));
          }
          updateGradientTypeUI();
          renderGradient();
        } else if (fill.type === 'media') {
          switchFillTab('media');
        } else {
          switchFillTab('color');
          const col = fill.color || '#FAB778';
          if (fillPreview) fillPreview.style.background = col;
          if (inputFillColor) inputFillColor.value = col;
        }
      });
    });
  }
  if (btnBackColor && toolsGrid && panelColor) {
    btnBackColor.addEventListener('click', (e) => {
      e.stopPropagation();
      closeInspectorSubpanel(panelColor);
    });
  }
  // Fill actions — via Fish Top Tabs API (global style)
  const fillTabColor = document.getElementById('fillTabColor');
  const fillTabMedia = document.getElementById('fillTabMedia');
  const fillTabGradient = document.getElementById('fillTabGradient');
  function switchFillTab(name) {
    // API handles active class, manual fallback if needed
    document.querySelectorAll('#colorFillTabs [data-fill-tab]').forEach(b => b.classList.toggle('active', b.dataset.fillTab === name));
    if (fillTabColor) fillTabColor.style.display = name === 'color' ? 'flex' : 'none';
    if (fillTabMedia) fillTabMedia.style.display = name === 'media' ? 'flex' : 'none';
    if (fillTabGradient) fillTabGradient.style.display = name === 'gradient' ? 'flex' : 'none';
  }
  if (window.FishUI && window.FishUI.createTopTabs) {
    window.FishUI.createTopTabs({
      container: '#colorFillTabs',
      onSwitch: (tabId) => switchFillTab(tabId)
    });
  } else {
    document.querySelectorAll('#colorFillTabs [data-fill-tab]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        switchFillTab(btn.dataset.fillTab);
      });
    });
  }
  // Color grid
  const colorGrid = document.getElementById('fillColorGrid');
  const inputFillColor = document.getElementById('inputFillColor');
  const fillPreview = document.getElementById('fillColorPreview');
  const paletteColors = ['#FAB778','#FFF2C2','#000000','#FFFFFF','#EB5757','#27AE60','#2D9CDB','#BB6BD9','#F2994A','#F2C94C','#9E4310','#D06423','#541F05','#732D06','#FF8A65','#FFCC80','#FFE0B2','#B0BEC5','#90A4AE','#6D4C41','#E91E63','#00BCD4','#4CAF50','#FFEB3B'];
  function applyFillColor(col, alpha) {
    if (fillPreview) fillPreview.style.background = col;
    if (inputFillColor) inputFillColor.value = col;
    if (selectedTrackRow) {
      const id = selectedTrackRow.dataset.layerId || 'default';
      const fill = getLayerFill(id);
      fill.type = 'color';
      fill.color = col;
      if (alpha !== undefined) fill.alpha = alpha;
      fill.mediaUrl = null;
      applyFillToMeshGlobal(id);
      triggerAutoSave();
    }
  }
  if (colorGrid) {
    colorGrid.innerHTML = '';
    paletteColors.forEach(col => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'fill-color-swatch-btn';
      b.style.cssText = 'width:100%; aspect-ratio:1; border-radius:5px; border:1px solid rgba(255,242,194,0.22); cursor:pointer; background:' + col + '; padding:0; margin:0;';
      b.title = col;
      b.addEventListener('click', () => applyFillColor(col, 1));
      colorGrid.appendChild(b);
    });
  }
  const btnCustomFillColor = document.getElementById('btnCustomFillColor');
  if (btnCustomFillColor) {
    btnCustomFillColor.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default';
      const fill = getLayerFill(id);
      const curCol = fill.type === 'color' ? (fill.color || '#FAB778') : '#FAB778';
      const curAlpha = fill.type === 'color' && fill.alpha !== undefined ? fill.alpha : 1;
      if (window.openGlobalColorPicker) {
        window.openGlobalColorPicker({
          color: curCol,
          alpha: curAlpha,
          anchorElement: btnCustomFillColor,
          onChange: (res) => {
            applyFillColor(res.hex, res.alpha !== undefined ? res.alpha : 1);
          }
        });
      } else if (inputFillColor) {
        inputFillColor.click();
      }
    });
  }
  if (inputFillColor) {
    inputFillColor.addEventListener('input', () => applyFillColor(inputFillColor.value));
  }
  // Global Media Library & Pool functions are defined at top-level scope

  // Hook to window
  window.getGlobalMediaLibrary = getGlobalMediaLibrary;
  window.addGlobalMedia = addGlobalMedia;
  window.removeGlobalMedia = removeGlobalMedia;
  window.syncAllMediaGrids = syncAllMediaGrids;
  window.createMediaThumbnailElement = createMediaThumbnailElement;

  const btnUploadMedia = document.getElementById('btnUploadMedia');
  const inputFillMedia = document.getElementById('inputFillMedia');

  if (btnUploadMedia && inputFillMedia) {
    btnUploadMedia.addEventListener('click', () => inputFillMedia.click());
    inputFillMedia.addEventListener('change', () => {
      const file = inputFillMedia.files && inputFillMedia.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          const dataUrl = reader.result;
          addGlobalMedia(dataUrl, file.name, file.type);
          if (selectedTrackRow) {
            const id = selectedTrackRow.dataset.layerId || 'default';
            const fill = getLayerFill(id);
            fill.type = 'media';
            fill.mediaUrl = dataUrl;
            fill.color = null;
            fill.gradientType = null;
            const mesh = meshLayerMap.get(id);
            if (mesh) {
              new THREE.TextureLoader().load(dataUrl, (tex) => {
                tex.colorSpace = THREE.SRGBColorSpace;
                mesh.material.map = tex;
                mesh.material.color = new THREE.Color('#FFFFFF');
                mesh.material.needsUpdate = true;
                render3D();
              });
            }
            triggerAutoSave();
          }
        };
        reader.readAsDataURL(file);
      }
    });
  }

  syncAllMediaGrids();

  // ----------------------------------------------------
  // Gradient Advanced Panel (Alight Motion Inspired UI)
  // ----------------------------------------------------
  const gradientBar = document.getElementById('gradientBar');
  const gradientStopsEl = document.getElementById('gradientStops');
  const btnAddStop = document.getElementById('btnAddGradientStop');
  const btnRemoveStop = document.getElementById('btnRemoveGradientStop');
  const btnEditStopColor = document.getElementById('btnEditGradientStopColor');
  const gradientStopColorChip = document.getElementById('gradientStopColorChip');
  const lblGradientStopColor = document.getElementById('lblGradientStopColor');
  const gradientTypeButtons = document.querySelectorAll('#gradientTypeBar .gradient-type-btn');

  let activeGradientType = 'linear';
  let gradientStops = [
    { offset: 0, color: '#000000' },
    { offset: 1, color: '#FFFFFF' }
  ];
  let selectedStopIdx = 0;

  function updateGradientTypeUI() {
    gradientTypeButtons.forEach(btn => {
      if (btn.getAttribute('data-type') === activeGradientType) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  gradientTypeButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-type');
      if (type) {
        activeGradientType = type;
        updateGradientTypeUI();
        renderGradient();
        applyGradient();
      }
    });
  });

  function renderGradient() {
    gradientStops.sort((a,b) => a.offset - b.offset);
    if (selectedStopIdx >= gradientStops.length) {
      selectedStopIdx = gradientStops.length - 1;
    }
    if (selectedStopIdx < 0) selectedStopIdx = 0;

    // Build CSS Gradient string for track with transparent checkerboard support
    const stopsCss = gradientStops.map(s => {
      let col = s.color;
      if (s.alpha !== undefined && s.alpha < 1) {
        const p = parseHexOrRgb(col);
        col = `rgba(${p.r}, ${p.g}, ${p.b}, ${s.alpha})`;
      }
      return col + ' ' + (s.offset * 100).toFixed(1) + '%';
    }).join(', ');

    let trackCss = 'linear-gradient(90deg, ' + stopsCss + '), repeating-conic-gradient(#4A1D05 0% 25%, #732D06 0% 50%) 50% / 10px 10px';
    if (gradientBar) {
      gradientBar.style.background = trackCss;
    }

    // Render Custom Stop Handles
    if (gradientStopsEl) {
      gradientStopsEl.innerHTML = '';
      gradientStops.forEach((s, idx) => {
        const handle = document.createElement('div');
        handle.className = 'gradient-stop-handle' + (idx === selectedStopIdx ? ' selected' : '');
        handle.style.left = (s.offset * 100) + '%';
        handle.title = `Stop ${idx + 1}: ${s.color} (${Math.round(s.offset * 100)}%)`;

        const shape = document.createElement('div');
        shape.className = 'gradient-stop-shape';
        let shapeBg = s.color;
        if (s.alpha !== undefined && s.alpha < 1) {
          const p = parseHexOrRgb(s.color);
          shapeBg = `linear-gradient(rgba(${p.r},${p.g},${p.b},${s.alpha}), rgba(${p.r},${p.g},${p.b},${s.alpha})), repeating-conic-gradient(#4A1D05 0% 25%, #732D06 0% 50%) 50% / 8px 8px`;
        }
        shape.style.background = shapeBg;

        handle.appendChild(shape);

        // Click / select handle
        handle.addEventListener('click', (e) => {
          e.stopPropagation();
          selectedStopIdx = idx;
          renderGradient();
          const targetEl = (gradientStopsEl && gradientStopsEl.children[selectedStopIdx]) || handle;
          openStopColorPicker(targetEl);
        });

        // Double click to open color picker
        handle.addEventListener('dblclick', (e) => {
          e.stopPropagation();
          selectedStopIdx = idx;
          renderGradient();
          const targetEl = (gradientStopsEl && gradientStopsEl.children[selectedStopIdx]) || handle;
          openStopColorPicker(targetEl);
        });

        // Drag handle
        let dragging = false;
        const onDown = (e) => {
          e.preventDefault();
          e.stopPropagation();
          dragging = true;
          selectedStopIdx = idx;
          const rect = gradientBar.getBoundingClientRect();

          const onMove = (me) => {
            const clientX = me.touches ? me.touches[0].clientX : me.clientX;
            let off = (clientX - rect.left) / rect.width;
            off = Math.max(0, Math.min(1, off));
            s.offset = Math.round(off * 100) / 100;
            renderGradient();
            applyGradient();
          };

          const onUp = () => {
            dragging = false;
            window.removeEventListener('mousemove', onMove);
            window.removeEventListener('mouseup', onUp);
            window.removeEventListener('touchmove', onMove);
            window.removeEventListener('touchend', onUp);
          };

          window.addEventListener('mousemove', onMove);
          window.addEventListener('mouseup', onUp);
          window.addEventListener('touchmove', onMove, { passive: false });
          window.addEventListener('touchend', onUp);
        };

        handle.addEventListener('mousedown', onDown);
        handle.addEventListener('touchstart', onDown, { passive: false });

        gradientStopsEl.appendChild(handle);
      });
    }

    if (btnRemoveStop) {
      btnRemoveStop.disabled = gradientStops.length <= 2;
    }
  }

  function openStopColorPicker(anchorEl) {
    const curStop = gradientStops[selectedStopIdx];
    if (!curStop) return;

    const targetAnchor = anchorEl || (gradientStopsEl && gradientStopsEl.children[selectedStopIdx]) || gradientBar;

    if (window.openGlobalColorPicker) {
      const parsed = parseHexOrRgb(curStop.color);
      const alphaVal = curStop.alpha !== undefined ? curStop.alpha : (parsed.a !== undefined ? parsed.a : 1);
      window.openGlobalColorPicker({
        color: curStop.color,
        alpha: alphaVal,
        anchorElement: targetAnchor,
        onChange: (res) => {
          if (gradientStops[selectedStopIdx]) {
            gradientStops[selectedStopIdx].color = res.rgba || res.hex;
            gradientStops[selectedStopIdx].alpha = res.alpha !== undefined ? res.alpha : 1;
            renderGradient();
            applyGradient();
          }
        }
      });
    }
  }

  function applyGradient() {
    if (!selectedTrackRow) return;
    const id = selectedTrackRow.dataset.layerId || 'default';
    const fill = getLayerFill(id);
    fill.type = 'gradient';
    fill.gradientType = activeGradientType;
    fill.gradientStops = gradientStops.map(s => ({ offset: s.offset, color: s.color }));
    fill.color = null;
    fill.mediaUrl = null;

    applyFillToMeshGlobal(id);
    triggerAutoSave();
  }

  // Click on empty gradient bar to insert a new stop
  if (gradientBar) {
    gradientBar.addEventListener('click', (e) => {
      if (e.target !== gradientBar && e.target !== gradientStopsEl) return;
      const rect = gradientBar.getBoundingClientRect();
      let off = (e.clientX - rect.left) / rect.width;
      off = Math.max(0, Math.min(1, Math.round(off * 100) / 100));

      const curColor = gradientStops[selectedStopIdx] ? gradientStops[selectedStopIdx].color : '#FFFFFF';
      gradientStops.push({ offset: off, color: curColor });
      selectedStopIdx = gradientStops.length - 1;
      renderGradient();
      applyGradient();
    });
  }

  // Add Stop button
  if (btnAddStop) {
    btnAddStop.addEventListener('click', (e) => {
      e.stopPropagation();
      let off = 0.5;
      if (gradientStops.length >= 2) {
        let maxGap = 0, gapMid = 0.5;
        const sorted = [...gradientStops].sort((a,b) => a.offset - b.offset);
        for (let i = 0; i < sorted.length - 1; i++) {
          const gap = sorted[i+1].offset - sorted[i].offset;
          if (gap > maxGap) {
            maxGap = gap;
            gapMid = (sorted[i].offset + sorted[i+1].offset) / 2;
          }
        }
        off = Math.round(gapMid * 100) / 100;
      }
      const curColor = gradientStops[selectedStopIdx] ? gradientStops[selectedStopIdx].color : '#FAB778';
      gradientStops.push({ offset: off, color: curColor });
      selectedStopIdx = gradientStops.length - 1;
      renderGradient();
      applyGradient();
    });
  }

  // Remove Stop button
  if (btnRemoveStop) {
    btnRemoveStop.addEventListener('click', (e) => {
      e.stopPropagation();
      if (gradientStops.length <= 2) return;
      gradientStops.splice(selectedStopIdx, 1);
      selectedStopIdx = Math.max(0, Math.min(selectedStopIdx, gradientStops.length - 1));
      renderGradient();
      applyGradient();
    });
  }

  // Init gradient panel state
  updateGradientTypeUI();
  renderGradient();

  // Modular Graph Editor via FishUI
  if (window.FishUI && window.FishUI.createGraphEditor) {
    globalGraphEditor = window.FishUI.createGraphEditor({
      canvas: '#graphEditorCanvas',
      container: '#panelGraphEditor',
      toggleGridButton: '#btnToggleGrid',
      toggleOvershootButton: '#btnToggleOvershoot',
      libraryButton: '#btnGraphLibrary',
      saveLibraryButton: '#btnSaveToLibrary',
      closeLibraryButton: '#btnCloseGraphLibrary',
      libraryOverlay: '#graphLibraryOverlay',
      libraryList: '#graphLibraryList',
      backButton: '#btnBackFromGraph',
      onCurveChange: ({ cp1, cp2, isOvershoot }) => {
        graphEditorState.cp1 = { ...cp1 };
        graphEditorState.cp2 = { ...cp2 };
        graphEditorState.isOvershoot = isOvershoot;
        graphEditorState.dirty = true;
        applyGraphEasingToKeyframe();
      },
      onClose: () => {
        closeGraphEditor(false);
      }
    });
  } else {
    const btnKfGraph = document.getElementById('btnKeyframeGraph');
    if (btnKfGraph) {
      btnKfGraph.addEventListener('click', (e) => {
        e.stopPropagation();
        const channel = getActiveKeyframeChannel() || 'position';
        openGraphEditor(channel);
      });
    }

    const btnBackFromGraph = document.getElementById('btnBackFromGraph');
    if (btnBackFromGraph) {
      btnBackFromGraph.addEventListener('click', (e) => {
        e.stopPropagation();
        closeGraphEditor(false);
      });
    }

    const btnGraphLibrary = document.getElementById('btnGraphLibrary');
    if (btnGraphLibrary) {
      btnGraphLibrary.addEventListener('click', (e) => {
        e.stopPropagation();
        openGraphLibrary();
      });
    }

    const btnToggleGrid = document.getElementById('btnToggleGrid');
    if (btnToggleGrid) {
      btnToggleGrid.addEventListener('click', (e) => {
        e.stopPropagation();
        graphEditorState.showGrid = !graphEditorState.showGrid;
        updateGraphButtonsUI();
        renderGraphCanvas();
      });
    }

    const btnToggleOvershoot = document.getElementById('btnToggleOvershoot');
    if (btnToggleOvershoot) {
      btnToggleOvershoot.addEventListener('click', (e) => {
        e.stopPropagation();
        graphEditorState.isOvershoot = !graphEditorState.isOvershoot;
        if (graphEditorState.isOvershoot) {
          if (graphEditorState.cp1.y <= 1.0 && graphEditorState.cp1.y >= 0 && graphEditorState.cp2.y <= 1.0 && graphEditorState.cp2.y >= 0) {
            graphEditorState.cp1 = { x: 0.34, y: 1.35 };
            graphEditorState.cp2 = { x: 0.64, y: 1.0 };
          }
        } else {
          graphEditorState.cp1.y = Math.max(0, Math.min(1, graphEditorState.cp1.y));
          graphEditorState.cp2.y = Math.max(0, Math.min(1, graphEditorState.cp2.y));
        }
        graphEditorState.dirty = true;
        updateGraphButtonsUI();
        applyGraphEasingToKeyframe();
        renderGraphCanvas();
      });
    }

    const btnCloseGraphLibrary = document.getElementById('btnCloseGraphLibrary');
    if (btnCloseGraphLibrary) {
      btnCloseGraphLibrary.addEventListener('click', (e) => {
        e.stopPropagation();
        closeGraphLibrary();
      });
    }

    const btnSaveToLibrary = document.getElementById('btnSaveToLibrary');
    if (btnSaveToLibrary) {
      btnSaveToLibrary.addEventListener('click', (e) => {
        e.stopPropagation();
        saveCurrentGraphToLibrary();
      });
    }

    initGraphEditorInteraction();
  }
}

// ════════════════════════════════════════════════════════════════
// Border & Shadow Controller Suite (Themed & Compact)
// ════════════════════════════════════════════════════════════════
const layerBorderShadow = new Map();

function getLayerBorderShadow(id) {
  if (!layerBorderShadow.has(id)) {
    layerBorderShadow.set(id, {
      stroke: {
        enabled: false,
        color: '#000000',
        size: 4.0,
        cap: 'butt',
        align: 'center'
      },
      shadow: {
        enabled: false,
        color: '#000000',
        size: 4,
        alpha: 100,
        posX: 3,
        posY: 3
      }
    });
  }
  const base = layerBorderShadow.get(id);
  const kfs = layerKeyframes.get(id);
  if (!kfs || kfs.length === 0) return base;
  const hasAny = (ch) => kfs.some(k => k[ch] !== undefined);
  if (!hasAny('strokeColor') && !hasAny('strokeSize') && !hasAny('shadowColor') && !hasAny('shadowSize') && !hasAny('shadowAlpha') && !hasAny('shadowPosX') && !hasAny('shadowPosY')) {
    return base;
  }
  function interpChannel(channel, defaultVal, isColor) {
    const relevant = kfs.filter(k => k[channel] !== undefined);
    if (relevant.length === 0) return defaultVal;
    if (relevant.length === 1 || elapsed <= relevant[0].time) return relevant[0][channel];
    const last = relevant[relevant.length - 1];
    if (elapsed >= last.time) return last[channel];
    for (let i = 0; i < relevant.length - 1; i++) {
      const k1 = relevant[i], k2 = relevant[i+1];
      if (elapsed >= k1.time && elapsed <= k2.time) {
        const span = k2.time - k1.time;
        const rawT = span > 0 ? (elapsed - k1.time) / span : 0;
        const easing = k1['easing_' + channel] || k1.easing;
        let t = rawT;
        if (easing && easing.cp1x !== undefined) t = solveCubicBezier(easing.cp1x, easing.cp1y, easing.cp2x, easing.cp2y, rawT);
        if (isColor) {
          const c1 = parseHexOrRgbLocal(k1[channel]);
          const c2 = parseHexOrRgbLocal(k2[channel]);
          const r = Math.round(c1.r + (c2.r - c1.r) * t);
          const g = Math.round(c1.g + (c2.g - c1.g) * t);
          const b = Math.round(c1.b + (c2.b - c1.b) * t);
          return `rgb(${r},${g},${b})`;
        }
        return k1[channel] + (k2[channel] - k1[channel]) * t;
      }
    }
    return defaultVal;
  }
  return {
    stroke: {
      enabled: base.stroke.enabled,
      color: hasAny('strokeColor') ? interpChannel('strokeColor', base.stroke.color, true) : base.stroke.color,
      size: hasAny('strokeSize') ? interpChannel('strokeSize', base.stroke.size) : base.stroke.size,
      cap: base.stroke.cap,
      align: base.stroke.align
    },
    shadow: {
      enabled: base.shadow.enabled,
      color: hasAny('shadowColor') ? interpChannel('shadowColor', base.shadow.color, true) : base.shadow.color,
      size: hasAny('shadowSize') ? interpChannel('shadowSize', base.shadow.size) : base.shadow.size,
      alpha: hasAny('shadowAlpha') ? interpChannel('shadowAlpha', base.shadow.alpha) : base.shadow.alpha,
      posX: hasAny('shadowPosX') ? interpChannel('shadowPosX', base.shadow.posX) : base.shadow.posX,
      posY: hasAny('shadowPosY') ? interpChannel('shadowPosY', base.shadow.posY) : base.shadow.posY
    }
  };
}

function getActiveBorderShadowChannel() {
  const panel = document.getElementById('panelBorderShadow');
  if (!panel || panel.style.display === 'none') return null;
  const activeTab = document.querySelector('#borderShadowTabs .controller-switch-btn.active');
  const tab = activeTab ? activeTab.dataset.bsTab : 'stroke';
  if (tab === 'stroke') {
    // cek param aktif atau color swatch
    const activeParam = document.querySelector('#bsTabStroke .bs-param-btn.active');
    if (activeParam && activeParam.id === 'btnStrokeSizeParam') return 'strokeSize';
    return 'strokeColor';
  } else {
    const activeParam = document.querySelector('#bsTabShadow .bs-param-btn.active');
    if (activeParam) {
      if (activeParam.id === 'btnShadowColorTrigger') return 'shadowColor';
      if (activeParam.id === 'btnShadowSizeParam') return 'shadowSize';
      if (activeParam.id === 'btnShadowAlphaParam') return 'shadowAlpha';
      if (activeParam.id === 'btnShadowPosParam') return activeShadowAxis === 'X' ? 'shadowPosX' : 'shadowPosY';
    }
    return 'shadowSize';
  }
}

function cleanupBorderShadowKeyframes(id, channels) {
  const kfs = layerKeyframes.get(id);
  if (!kfs || !kfs.length) return;
  let changed = false;
  for (let i = kfs.length - 1; i >= 0; i--) {
    const kf = kfs[i];
    let touched = false;
    channels.forEach(ch => {
      if (kf[ch] !== undefined) {
        delete kf[ch];
        touched = true;
      }
      const eKey = 'easing_' + ch;
      if (kf[eKey] !== undefined) {
        delete kf[eKey];
        touched = true;
      }
    });
    // also clean generic easing if it no longer corresponds to any remaining channel
    if (touched) changed = true;
    const hasMeaningful = ['posX','posY','posZ','rotX','rotY','rotZ','scaleW','scaleH','opacity','strokeColor','strokeSize','shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].some(p => kf[p] !== undefined);
    if (!hasMeaningful) {
      // remove empty keyframe (only time + orphan easing left)
      kfs.splice(i, 1);
      changed = true;
    } else if (kf.easing) {
      const hasAnyEasing = Object.keys(kf).some(k => k.startsWith('easing_'));
      if (!hasAnyEasing) delete kf.easing;
    }
  }
  if (changed) {
    renderAllKeyframeMarkers();
    updateBorderShadowKeyframeUI();
  }
}

function syncBorderShadowDisabledUI() {
  const id = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : null;
  const strokePane = document.getElementById('bsTabStroke');
  const shadowPane = document.getElementById('bsTabShadow');
  if (!id) {
    if (strokePane) strokePane.classList.add('is-disabled');
    if (shadowPane) shadowPane.classList.add('is-disabled');
    return;
  }
  const base = layerBorderShadow.get(id) || (typeof getLayerBorderShadow === 'function' ? getLayerBorderShadow(id) : null);
  if (!base) return;
  if (strokePane) strokePane.classList.toggle('is-disabled', !base.stroke.enabled);
  if (shadowPane) shadowPane.classList.toggle('is-disabled', !base.shadow.enabled);
}

function recordBorderShadowKeyframe(id, channel, value) {
  // jangan record jika switch untuk channel tersebut sedang OFF
  const base = layerBorderShadow.get(id);
  if (base) {
    const isStrokeChannel = ['strokeColor','strokeSize'].includes(channel);
    const isShadowChannel = ['shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].includes(channel);
    if (isStrokeChannel && !base.stroke.enabled) return;
    if (isShadowChannel && !base.shadow.enabled) return;
  }
  if (!layerKeyframes.has(id)) layerKeyframes.set(id, []);
  const kfs = layerKeyframes.get(id);
  const hasKf = hasKeyframeForChannel(id, elapsed, channel);
  let target = getKeyframeAt(id, elapsed);
  if (hasKf && target) {
    target[channel] = value;
  } else {
    if (!target) { target = { time: Math.round(elapsed * 100) / 100 }; kfs.push(target); }
    target[channel] = value;
    kfs.sort((a,b)=>a.time-b.time);
  }
  renderAllKeyframeMarkers();
  updateBorderShadowKeyframeUI();
  triggerAutoSave();
}

function updateBorderShadowKeyframeUI() {
  if (!selectedTrackRow) return;
  const id = selectedTrackRow.dataset.layerId || 'default';
  const ch = getActiveBorderShadowChannel();
  if (!ch) return;
  const hasKf = hasKeyframeForChannel(id, elapsed, ch);
  const btn = document.getElementById('btnToggleBorderShadowKeyframe');
  if (!btn) return;
  const sym = btn.querySelector('.diamond-icon-symbol');
  if (hasKf) { btn.classList.add('is-on-keyframe'); if(sym) sym.setAttribute('d','M7 12 L17 12'); }
  else { btn.classList.remove('is-on-keyframe'); if(sym) sym.setAttribute('d','M12 7 L12 17 M7 12 L17 12'); }
}

let activeShadowAxis = 'X';
let strokeSizeRulerInstance = null;
let shadowSizeRulerInstance = null;
let shadowAlphaRulerInstance = null;
let shadowPosRulerInstance = null;

function parseHexOrRgbLocal(str) {
  if (!str) return { r: 0, g: 0, b: 0, a: 1 };
  if (typeof parseHexOrRgb === 'function') {
    try { return parseHexOrRgb(str); } catch (_) {}
  }
  const s = String(str).trim();
  if (s.startsWith('#')) {
    let hex = s.slice(1);
    if (hex.length === 3) hex = hex.split('').map(c => c + c).join('');
    const num = parseInt(hex, 16);
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255, a: 1 };
  }
  const m = s.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
  if (m) {
    return { r: parseInt(m[1]), g: parseInt(m[2]), b: parseInt(m[3]), a: m[4] !== undefined ? parseFloat(m[4]) : 1 };
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}

function initBorderShadowController() {
  const btnInspBS = document.getElementById('btnInspBorderShadow');
  const panelBS = document.getElementById('panelBorderShadow');
  const btnBackBS = document.getElementById('btnBackFromBorderShadow');
  const drawer = document.getElementById('layerInspectorDrawer');
  const toolsGrid = document.querySelector('.inspector-tools-grid');
  const quickStrip = document.querySelector('.inspector-quick-strip');

  // 1. Open subpanel button
  if (btnInspBS && panelBS) {
    btnInspBS.addEventListener('click', (e) => {
      e.stopPropagation();
      openInspectorSubpanel(panelBS, 'subpanel-border-shadow', () => {
        syncBorderShadowUI();
        // set default active param biar diamond tidak kosong
        const activeTab = document.querySelector('#borderShadowTabs .controller-switch-btn.active');
        const tab = activeTab ? activeTab.dataset.bsTab : 'stroke';
        if (tab === 'stroke') {
          document.querySelectorAll('#bsTabStroke .bs-param-btn').forEach(b=>b.classList.remove('active'));
          const b = document.getElementById('btnStrokeSizeParam');
          if (b) b.classList.add('active');
        } else {
          document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b=>b.classList.remove('active'));
          const b = document.getElementById('btnShadowSizeParam');
          if (b) b.classList.add('active');
        }
        setTimeout(() => {
          updateBorderShadowKeyframeUI();
          renderAllKeyframeMarkers();
        }, 10);
      });
    });
  }

  // 2. Back button
  if (btnBackBS && panelBS) {
    btnBackBS.addEventListener('click', (e) => {
      e.stopPropagation();
      closeInspectorSubpanel(panelBS);
    });
  }

  // 3. Tab switching (Stroke vs Shadow)
  document.querySelectorAll('#borderShadowTabs button').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const tab = btn.dataset.bsTab || 'stroke';
      document.querySelectorAll('#borderShadowTabs button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const strokePane = document.getElementById('bsTabStroke');
      const shadowPane = document.getElementById('bsTabShadow');
      if (strokePane) strokePane.style.display = tab === 'stroke' ? 'flex' : 'none';
      if (shadowPane) shadowPane.style.display = tab === 'shadow' ? 'flex' : 'none';
      // set default active param untuk tab baru
      if (tab === 'stroke') {
        document.querySelectorAll('#bsTabStroke .bs-param-btn').forEach(b=>b.classList.remove('active'));
        const b = document.getElementById('btnStrokeSizeParam');
        if (b) b.classList.add('active');
      } else {
        document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b=>b.classList.remove('active'));
        const b = document.getElementById('btnShadowSizeParam');
        if (b) b.classList.add('active');
      }
      setTimeout(() => {
        updateBorderShadowKeyframeUI();
        renderAllKeyframeMarkers();
      }, 10);
    });
  });

  // 4. Toggle switches — OFF = reset ke default + kunci param & cleanup keyframe
  const toggleStroke = document.getElementById('toggleStrokeEnabled');
  if (toggleStroke) {
    toggleStroke.addEventListener('change', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      // pastikan base ada
      getLayerBorderShadow(id);
      const base = layerBorderShadow.get(id);
      if (!base) return;
      base.stroke.enabled = toggleStroke.checked;
      if (!toggleStroke.checked) {
        // reset nilai ke default biar UI balik ke default
        base.stroke.size = 4.0;
        base.stroke.color = '#000000';
        base.stroke.cap = 'butt';
        base.stroke.align = 'center';
        cleanupBorderShadowKeyframes(id, ['strokeColor','strokeSize']);
      }
      // sync UI (ruler, color box, cap/align, disabled visual)
      syncBorderShadowUI();
      renderAllKeyframeMarkers();
      updateBorderShadowKeyframeUI();
      applyBorderShadowToMesh(id);
      triggerAutoSave();
    });
  }

  const toggleShadow = document.getElementById('toggleShadowEnabled');
  if (toggleShadow) {
    toggleShadow.addEventListener('change', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      getLayerBorderShadow(id);
      const base = layerBorderShadow.get(id);
      if (!base) return;
      base.shadow.enabled = toggleShadow.checked;
      if (!toggleShadow.checked) {
        // reset nilai shadow ke default
        base.shadow.size = 4;
        base.shadow.alpha = 100;
        base.shadow.posX = 3;
        base.shadow.posY = 3;
        base.shadow.color = '#000000';
        cleanupBorderShadowKeyframes(id, ['shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY']);
      }
      syncBorderShadowUI();
      renderAllKeyframeMarkers();
      updateBorderShadowKeyframeUI();
      applyBorderShadowToMesh(id);
      triggerAutoSave();
    });
  }

  // 5. FishUI Rulers
  if (window.FishUI && window.FishUI.createRuler) {
    // Stroke Size Ruler
    strokeSizeRulerInstance = window.FishUI.createRuler({
      container: '#strokeSizeRuler',
      min: 0,
      max: 100,
      sensitivity: 0.25,
      value: 4.0,
      onChange: (val) => {
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId || 'default';
        const base = layerBorderShadow.get(id) || getLayerBorderShadow(id);
        if (!base.stroke.enabled) {
          // kembalikan ruler ke nilai aktual biar gak bisa diadjust saat OFF
          if (strokeSizeRulerInstance) strokeSizeRulerInstance.setValue(base.stroke.size);
          return;
        }
        const bs = getLayerBorderShadow(id);
        const rounded = Math.max(0, Math.round(val * 2) / 2);
        bs.stroke.size = rounded;
        const lbl = document.getElementById('valStrokeSize');
        if (lbl) lbl.textContent = rounded.toFixed(1);
        // set active param biar diamond sinkron
        document.querySelectorAll('#bsTabStroke .bs-param-btn').forEach(b=>b.classList.remove('active'));
        const sizeBtn = document.getElementById('btnStrokeSizeParam');
        if (sizeBtn) sizeBtn.classList.add('active');
        // auto-keyframe untuk strokeSize
        recordBorderShadowKeyframe(id, 'strokeSize', rounded);
        applyBorderShadowToMesh(id);
        triggerAutoSave();
        updateBorderShadowKeyframeUI();
      }
    });

    // Shadow Size Ruler
    shadowSizeRulerInstance = window.FishUI.createRuler({
      container: '#shadowSizeRuler',
      min: 0,
      max: 100,
      sensitivity: 0.4,
      value: 4,
      onChange: (val) => {
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId || 'default';
        const base = layerBorderShadow.get(id) || getLayerBorderShadow(id);
        if (!base.shadow.enabled) {
          if (shadowSizeRulerInstance) shadowSizeRulerInstance.setValue(base.shadow.size);
          return;
        }
        const bs = getLayerBorderShadow(id);
        const rounded = Math.max(0, Math.round(val));
        bs.shadow.size = rounded;
        const lbl = document.getElementById('valShadowSize');
        if (lbl) lbl.textContent = rounded;
        document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b=>b.classList.remove('active'));
        const btn = document.getElementById('btnShadowSizeParam');
        if (btn) btn.classList.add('active');
        recordBorderShadowKeyframe(id, 'shadowSize', rounded);
        applyBorderShadowToMesh(id);
        triggerAutoSave();
        updateBorderShadowKeyframeUI();
      }
    });

    // Shadow Alpha Ruler
    shadowAlphaRulerInstance = window.FishUI.createRuler({
      container: '#shadowAlphaRuler',
      min: 0,
      max: 100,
      sensitivity: 0.5,
      value: 100,
      onChange: (val) => {
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId || 'default';
        const base = layerBorderShadow.get(id) || getLayerBorderShadow(id);
        if (!base.shadow.enabled) {
          if (shadowAlphaRulerInstance) shadowAlphaRulerInstance.setValue(base.shadow.alpha);
          return;
        }
        const bs = getLayerBorderShadow(id);
        const rounded = Math.max(0, Math.min(100, Math.round(val)));
        bs.shadow.alpha = rounded;
        const lbl = document.getElementById('valShadowAlpha');
        if (lbl) lbl.textContent = `${rounded}%`;
        document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b=>b.classList.remove('active'));
        const btn = document.getElementById('btnShadowAlphaParam');
        if (btn) btn.classList.add('active');
        recordBorderShadowKeyframe(id, 'shadowAlpha', rounded);
        applyBorderShadowToMesh(id);
        triggerAutoSave();
        updateBorderShadowKeyframeUI();
      }
    });

    // Shadow Position Ruler
    shadowPosRulerInstance = window.FishUI.createRuler({
      container: '#shadowPosRuler',
      min: -150,
      max: 150,
      sensitivity: 0.5,
      value: 3,
      onChange: (val) => {
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId || 'default';
        const base = layerBorderShadow.get(id) || getLayerBorderShadow(id);
        if (!base.shadow.enabled) {
          if (shadowPosRulerInstance) shadowPosRulerInstance.setValue(activeShadowAxis === 'X' ? base.shadow.posX : base.shadow.posY);
          return;
        }
        const bs = getLayerBorderShadow(id);
        const rounded = Math.round(val);
        document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b=>b.classList.remove('active'));
        const posBtn = document.getElementById('btnShadowPosParam');
        if (posBtn) posBtn.classList.add('active');
        if (activeShadowAxis === 'X') {
          bs.shadow.posX = rounded;
          const lblX = document.getElementById('valShadowPosX');
          if (lblX) lblX.textContent = rounded;
          recordBorderShadowKeyframe(id, 'shadowPosX', rounded);
        } else {
          bs.shadow.posY = rounded;
          const lblY = document.getElementById('valShadowPosY');
          if (lblY) lblY.textContent = rounded;
          recordBorderShadowKeyframe(id, 'shadowPosY', rounded);
        }
        applyBorderShadowToMesh(id);
        triggerAutoSave();
        updateBorderShadowKeyframeUI();
      }
    });
  }

  // 6. Color Pickers (Stroke & Shadow) — blocked when switch OFF
  const btnStrokeColor = document.getElementById('btnStrokeColorSwatch');
  if (btnStrokeColor) {
    btnStrokeColor.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      const base = layerBorderShadow.get(id) || getLayerBorderShadow(id);
      if (!base.stroke.enabled) return;
      const bs = getLayerBorderShadow(id);
      // set active ke strokeColor (hapus Size)
      document.querySelectorAll('#bsTabStroke .bs-param-btn').forEach(b=>b.classList.remove('active'));
      updateBorderShadowKeyframeUI();
      renderAllKeyframeMarkers();
      if (window.openGlobalColorPicker) {
        window.openGlobalColorPicker({
          color: bs.stroke.color || '#000000',
          alpha: 1,
          anchorElement: btnStrokeColor,
          onChange: (res) => {
            bs.stroke.color = res.hex || '#000000';
            const box = document.getElementById('strokeColorBox');
            if (box) box.style.background = bs.stroke.color;
            // pastikan Color jadi channel aktif untuk diamond
            document.querySelectorAll('#bsTabStroke .bs-param-btn').forEach(b=>b.classList.remove('active'));
            recordBorderShadowKeyframe(id, 'strokeColor', bs.stroke.color);
            applyBorderShadowToMesh(id);
            triggerAutoSave();
            updateBorderShadowKeyframeUI();
            renderAllKeyframeMarkers();
          }
        });
      }
    });
  }

  const btnShadowColorTrigger = document.getElementById('btnShadowColorTrigger');
  const btnShadowColorSwatch = document.getElementById('btnShadowColorSwatch');
  const openShadowColor = (anchor) => {
    if (!selectedTrackRow) return;
    const id = selectedTrackRow.dataset.layerId || 'default';
    const baseChk = layerBorderShadow.get(id) || getLayerBorderShadow(id);
    if (!baseChk.shadow.enabled) return;
    const bs = getLayerBorderShadow(id);
    // set Color param aktif biar diamond sinkron
    document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b=>b.classList.remove('active'));
    const colorBtn = document.getElementById('btnShadowColorTrigger');
    if (colorBtn) colorBtn.classList.add('active');
    updateBorderShadowKeyframeUI();
    renderAllKeyframeMarkers();
    if (window.openGlobalColorPicker) {
      window.openGlobalColorPicker({
        color: bs.shadow.color || '#000000',
        alpha: (bs.shadow.alpha !== undefined ? bs.shadow.alpha / 100 : 1),
        anchorElement: anchor,
        onChange: (res) => {
          bs.shadow.color = res.hex || '#000000';
          if (res.alpha !== undefined) {
            bs.shadow.alpha = Math.round(res.alpha * 100);
            const lblA = document.getElementById('valShadowAlpha');
            if (lblA) lblA.textContent = `${bs.shadow.alpha}%`;
            if (shadowAlphaRulerInstance) shadowAlphaRulerInstance.setValue(bs.shadow.alpha);
            recordBorderShadowKeyframe(id, 'shadowAlpha', bs.shadow.alpha);
          }
          const box = document.getElementById('shadowColorBox');
          if (box) box.style.background = bs.shadow.color;
          const p = parseHexOrRgbLocal(bs.shadow.color);
          const rgbText = document.getElementById('shadowRgbText');
          if (rgbText) rgbText.textContent = `${p.r} ${p.g} ${p.b}`;
          // pastikan Color tetap aktif
          document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b=>b.classList.remove('active'));
          if (colorBtn) colorBtn.classList.add('active');
          recordBorderShadowKeyframe(id, 'shadowColor', bs.shadow.color);
          applyBorderShadowToMesh(id);
          triggerAutoSave();
          updateBorderShadowKeyframeUI();
          renderAllKeyframeMarkers();
        }
      });
    }
  };

  if (btnShadowColorTrigger) {
    btnShadowColorTrigger.addEventListener('click', (e) => {
      e.stopPropagation();
      // hanya select param untuk keyframe, popover hanya dari swatch
      document.querySelectorAll('#bsTabShadow .bs-param-btn').forEach(b => b.classList.remove('active'));
      btnShadowColorTrigger.classList.add('active');
      updateBorderShadowKeyframeUI();
    });
  }
  if (btnShadowColorSwatch) {
    btnShadowColorSwatch.addEventListener('click', (e) => {
      e.stopPropagation();
      // swatch tetap buka popover color picker
      openShadowColor(btnShadowColorSwatch);
    });
  }

  // 7. Cap and Join icon buttons — blocked when stroke OFF
  document.querySelectorAll('#strokeCapGroup button').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      const base = layerBorderShadow.get(id) || getLayerBorderShadow(id);
      if (!base.stroke.enabled) return;
      const bs = getLayerBorderShadow(id);
      bs.stroke.cap = btn.dataset.cap || 'butt';
      document.querySelectorAll('#strokeCapGroup button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      applyBorderShadowToMesh(id);
      triggerAutoSave();
    });
  });

  document.querySelectorAll('#strokeAlignGroup button').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      const base = layerBorderShadow.get(id) || getLayerBorderShadow(id);
      if (!base.stroke.enabled) return;
      const bs = getLayerBorderShadow(id);
      bs.stroke.align = btn.dataset.align || 'center';
      document.querySelectorAll('#strokeAlignGroup button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      applyBorderShadowToMesh(id);
      triggerAutoSave();
    });
  });

  // Param buttons (Size/Color/Alpha/Position) — klik jadi select (fill terang)
  document.querySelectorAll('#bsTabStroke .bs-param-btn, #bsTabShadow .bs-param-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      // jangan override Color picker yang sudah ada handler sendiri, tapi tetap set active
      const pane = btn.closest('.bs-tab-pane');
      if (pane) {
        pane.querySelectorAll('.bs-param-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      }
    });
  });

  // 8. Shadow Axis X / Y selector
  const btnAxisX = document.getElementById('btnShadowAxisX');
  const btnAxisY = document.getElementById('btnShadowAxisY');
  if (btnAxisX && btnAxisY) {
    btnAxisX.addEventListener('click', (e) => {
      e.stopPropagation();
      if (selectedTrackRow) {
        const idAx = selectedTrackRow.dataset.layerId || 'default';
        const baseAx = layerBorderShadow.get(idAx) || getLayerBorderShadow(idAx);
        if (!baseAx.shadow.enabled) return;
      }
      activeShadowAxis = 'X';
      btnAxisX.classList.add('active');
      btnAxisY.classList.remove('active');
      if (selectedTrackRow && shadowPosRulerInstance) {
        const id = selectedTrackRow.dataset.layerId || 'default';
        const bs = getLayerBorderShadow(id);
        shadowPosRulerInstance.setValue(bs.shadow.posX);
      }
      updateBorderShadowKeyframeUI();
    });

    btnAxisY.addEventListener('click', (e) => {
      e.stopPropagation();
      if (selectedTrackRow) {
        const idAy = selectedTrackRow.dataset.layerId || 'default';
        const baseAy = layerBorderShadow.get(idAy) || getLayerBorderShadow(idAy);
        if (!baseAy.shadow.enabled) return;
      }
      activeShadowAxis = 'Y';
      btnAxisY.classList.add('active');
      btnAxisX.classList.remove('active');
      if (selectedTrackRow && shadowPosRulerInstance) {
        const id = selectedTrackRow.dataset.layerId || 'default';
        const bs = getLayerBorderShadow(id);
        shadowPosRulerInstance.setValue(bs.shadow.posY);
      }
      updateBorderShadowKeyframeUI();
    });
  }

  // Param buttons active → update diamond UI + marker highlight modular
  document.querySelectorAll('#bsTabStroke .bs-param-btn, #bsTabShadow .bs-param-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      setTimeout(() => {
        updateBorderShadowKeyframeUI();
        renderAllKeyframeMarkers();
      }, 10);
    });
  });
  document.querySelectorAll('#borderShadowTabs button').forEach(btn => {
    btn.addEventListener('click', () => {
      setTimeout(updateBorderShadowKeyframeUI, 10);
    });
  });

  // Keyframe & Graph API for Border & Shadow (Color/Size/Alpha/Position)
  const btnBSKf = document.getElementById('btnToggleBorderShadowKeyframe');
  const btnBSGraph = document.getElementById('btnBorderShadowGraph');
  if (btnBSKf) {
    if (window.FishUI && window.FishUI.createKeyframeController) {
      window.FishUI.createKeyframeController({
        toggleButton: '#btnToggleBorderShadowKeyframe',
        graphButton: '#btnBorderShadowGraph',
        getChannel: () => getActiveBorderShadowChannel() || 'strokeSize',
        getLayerId: () => selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default',
        getCurrentTime: () => elapsed,
        getKeyframes: (layerId) => layerKeyframes.get(layerId) || [],
        getCurrentValue: (layerId, ch) => {
          const bs = getLayerBorderShadow(layerId);
          if (ch === 'strokeColor') return bs.stroke.color;
          if (ch === 'strokeSize') return bs.stroke.size;
          if (ch === 'shadowColor') return bs.shadow.color;
          if (ch === 'shadowSize') return bs.shadow.size;
          if (ch === 'shadowAlpha') return bs.shadow.alpha;
          if (ch === 'shadowPosX') return bs.shadow.posX;
          if (ch === 'shadowPosY') return bs.shadow.posY;
          return null;
        },
        onToggle: () => {
          const ch = getActiveBorderShadowChannel() || 'strokeSize';
          const id = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default';
          const baseChk = layerBorderShadow.get(id) || getLayerBorderShadow(id);
          const isStrokeCh = ['strokeColor','strokeSize'].includes(ch);
          const isShadowCh = ['shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].includes(ch);
          if (isStrokeCh && !baseChk.stroke.enabled) return;
          if (isShadowCh && !baseChk.shadow.enabled) return;
          const bs = getLayerBorderShadow(id);
          let val;
          if (ch === 'strokeColor') val = bs.stroke.color;
          else if (ch === 'strokeSize') val = bs.stroke.size;
          else if (ch === 'shadowColor') val = bs.shadow.color;
          else if (ch === 'shadowSize') val = bs.shadow.size;
          else if (ch === 'shadowAlpha') val = bs.shadow.alpha;
          else if (ch === 'shadowPosX') val = bs.shadow.posX;
          else if (ch === 'shadowPosY') val = bs.shadow.posY;
          if (hasKeyframeForChannel(id, elapsed, ch)) {
            const ex = getKeyframeAt(id, elapsed);
            if (ex) {
              delete ex[ch];
              const eKey = 'easing_' + ch;
              if (ex[eKey] !== undefined) delete ex[eKey];
              if (ex.easing) {
                const hasAnyEasing = Object.keys(ex).some(k => k.startsWith('easing_'));
                if (!hasAnyEasing) delete ex.easing;
              }
              const hasAny = ['strokeColor','strokeSize','shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY','posX','posY','posZ','rotX','rotY','rotZ','scaleW','scaleH','opacity'].some(p=>ex[p]!==undefined);
              if (!hasAny) {
                const kfs = layerKeyframes.get(id);
                const idx = kfs.indexOf(ex);
                if (idx!==-1) kfs.splice(idx,1);
              }
            }
          } else {
            recordBorderShadowKeyframe(id, ch, val);
            return;
          }
          updateBorderShadowKeyframeUI();
          renderAllKeyframeMarkers();
          triggerAutoSave();
        },
        onOpenGraph: ({ channel }) => {
          const ch = channel || getActiveBorderShadowChannel() || 'strokeSize';
          const id = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default';
          const baseChk = layerBorderShadow.get(id) || getLayerBorderShadow(id);
          const isStrokeCh = ['strokeColor','strokeSize'].includes(ch);
          const isShadowCh = ['shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].includes(ch);
          if (isStrokeCh && !baseChk.stroke.enabled) return;
          if (isShadowCh && !baseChk.shadow.enabled) return;
          const anchor = document.getElementById('btnBorderShadowGraph');
          openGraphEditor(ch, anchor);
        }
      });
    } else {
      btnBSKf.addEventListener('click', (e) => {
        e.stopPropagation();
        const ch = getActiveBorderShadowChannel() || 'strokeSize';
        const id = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default';
        const baseChk = layerBorderShadow.get(id) || getLayerBorderShadow(id);
        const isStrokeCh = ['strokeColor','strokeSize'].includes(ch);
        const isShadowCh = ['shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].includes(ch);
        if (isStrokeCh && !baseChk.stroke.enabled) return;
        if (isShadowCh && !baseChk.shadow.enabled) return;
        const bs = getLayerBorderShadow(id);
        let val;
        if (ch === 'strokeColor') val = bs.stroke.color;
        else if (ch === 'strokeSize') val = bs.stroke.size;
        else if (ch === 'shadowColor') val = bs.shadow.color;
        else if (ch === 'shadowSize') val = bs.shadow.size;
        else if (ch === 'shadowAlpha') val = bs.shadow.alpha;
        else if (ch === 'shadowPosX') val = bs.shadow.posX;
        else if (ch === 'shadowPosY') val = bs.shadow.posY;
        if (hasKeyframeForChannel(id, elapsed, ch)) {
          const ex = getKeyframeAt(id, elapsed);
          if (ex) {
            delete ex[ch];
            const eKey = 'easing_' + ch;
            if (ex[eKey] !== undefined) delete ex[eKey];
          }
        } else {
          recordBorderShadowKeyframe(id, ch, val);
        }
        updateBorderShadowKeyframeUI();
        renderAllKeyframeMarkers();
        triggerAutoSave();
      });
      if (btnBSGraph) {
        btnBSGraph.addEventListener('click', (e) => {
          e.stopPropagation();
          const ch = getActiveBorderShadowChannel() || 'strokeSize';
          const idG = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default';
          const baseChkG = layerBorderShadow.get(idG) || getLayerBorderShadow(idG);
          const isStrokeChG = ['strokeColor','strokeSize'].includes(ch);
          const isShadowChG = ['shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].includes(ch);
          if (isStrokeChG && !baseChkG.stroke.enabled) return;
          if (isShadowChG && !baseChkG.shadow.enabled) return;
          const anchor = document.getElementById('btnBorderShadowGraph');
          openGraphEditor(ch, anchor);
        });
      }
    }
  } else if (btnBSGraph) {
    btnBSGraph.addEventListener('click', (e) => {
      e.stopPropagation();
      const ch = getActiveBorderShadowChannel() || 'strokeSize';
      const idG2 = selectedTrackRow ? (selectedTrackRow.dataset.layerId || 'default') : 'default';
      const baseChkG2 = layerBorderShadow.get(idG2) || getLayerBorderShadow(idG2);
      const isStrokeChG2 = ['strokeColor','strokeSize'].includes(ch);
      const isShadowChG2 = ['shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].includes(ch);
      if (isStrokeChG2 && !baseChkG2.stroke.enabled) return;
      if (isShadowChG2 && !baseChkG2.shadow.enabled) return;
      const anchor = document.getElementById('btnBorderShadowGraph');
      openGraphEditor(ch, anchor);
    });
  }
}

function initEditShapeSubpanel() {
  const btnInspEditShape = document.getElementById('btnInspEditShape');
  const panelShape = document.getElementById('panelEditShape');
  const btnBackShape = document.getElementById('btnBackFromEditShape');
  const titleEl = document.getElementById('shapeSubpanelTitle');
  const contentEl = document.getElementById('shapeEditContent');

  if (!btnInspEditShape || !panelShape) return;

  function renderShapeControls(layerId) {
    if (!contentEl) return;
    contentEl.innerHTML = '';

    const row = document.querySelector(`.track-row[data-layer-id="${layerId}"]`);
    const clipName = row?.querySelector('.track-clip-name')?.textContent || '';
    let shapeType = row ? (row.dataset.shapeType || '') : '';

    if (!shapeType) {
      const lower = (clipName + '_' + (row?.dataset?.category || '')).toLowerCase();
      if (lower.includes('heart') || lower.includes('love')) shapeType = 'heart';
      else if (lower.includes('star-4') || lower.includes('bintang_4') || lower.includes('bintang 4')) shapeType = 'star-4';
      else if (lower.includes('star') || lower.includes('bintang')) shapeType = 'star';
      else if (lower.includes('hexagon') || lower.includes('segi_enam') || lower.includes('segi enam')) shapeType = 'hexagon';
      else if (lower.includes('circle') || lower.includes('bulat') || lower.includes('lingkaran')) shapeType = 'circle';
      else if (lower.includes('triangle') || lower.includes('segitiga')) shapeType = 'triangle';
      else if (lower.includes('round')) shapeType = 'round';
      else if (lower.includes('square') || lower.includes('kotak')) shapeType = 'square';
      else if (lower.includes('line') || lower.includes('garis')) shapeType = 'line';
      else if (lower.includes('arrow') || lower.includes('panah')) shapeType = 'arrow';
      else if (lower.includes('svg') || row?.dataset?.category === 'svg') shapeType = 'svg_path';
      else shapeType = 'square';
    }

    const titles = {
      square: 'Edit Shape: Kotak',
      circle: 'Edit Shape: Bulat',
      round: 'Edit Shape: Round',
      triangle: 'Edit Shape: Segitiga',
      heart: 'Edit Shape: Love',
      love: 'Edit Shape: Love',
      star: 'Edit Shape: Bintang',
      'star-4': 'Edit Shape: Bintang 4',
      hexagon: 'Edit Shape: Segi Enam',
      svg_path: 'Edit Shape: Vector SVG',
      line: 'Edit Shape: Garis',
      arrow: 'Edit Shape: Panah'
    };
    if (titleEl) titleEl.textContent = titles[shapeType] || 'Edit Shape';

    const p = getLayerShapeParams(layerId, shapeType);
    if (!p.renderMode) {
      p.renderMode = (shapeType === 'line' || shapeType === 'arrow') ? 'outline' : 'fill';
    }

    function createRulerRow(label, min, max, val, unit, onValChange) {
      const rowDiv = document.createElement('div');
      rowDiv.className = 'shape-slider-row';

      const lbl = document.createElement('span');
      lbl.className = 'shape-slider-lbl';
      lbl.textContent = label;

      const rulerTrack = document.createElement('div');
      rulerTrack.className = 'shape-ruler-track';

      const centerMark = document.createElement('div');
      centerMark.className = 'controller-center-mark-w';
      rulerTrack.appendChild(centerMark);

      const valLabel = document.createElement('span');
      valLabel.className = 'shape-slider-val';
      valLabel.textContent = val + (unit || '');

      rowDiv.appendChild(lbl);
      rowDiv.appendChild(rulerTrack);
      rowDiv.appendChild(valLabel);

      if (window.FishUI && window.FishUI.createRuler) {
        const minVal = min !== undefined ? min : -Infinity;
        const maxVal = max !== undefined ? max : Infinity;
        const sens = (isFinite(minVal) && isFinite(maxVal)) ? Math.max(0.15, (maxVal - minVal) / 280) : 0.8;
        window.FishUI.createRuler({
          container: rulerTrack,
          min: minVal,
          max: maxVal,
          value: val,
          sensitivity: sens,
          onChange: (v) => {
            const rounded = Math.round(v);
            valLabel.textContent = rounded + (unit || '');
            onValChange(rounded);
            applyFillToMeshGlobal(layerId);
            triggerAutoSave();
          }
        });
      }

      return rowDiv;
    }

    // Top sliders
    const list = document.createElement('div');
    list.className = 'shape-slider-list';

    if (shapeType === 'square') {
      list.appendChild(createRulerRow('Ukuran X', -Infinity, Infinity, p.sizeX !== undefined ? p.sizeX : 100, '%', (v) => { p.sizeX = v; }));
      list.appendChild(createRulerRow('Ukuran Y', -Infinity, Infinity, p.sizeY !== undefined ? p.sizeY : 100, '%', (v) => { p.sizeY = v; }));
      list.appendChild(createRulerRow('Rounded', -Infinity, Infinity, p.rounded !== undefined ? p.rounded : 0, '%', (v) => { p.rounded = v; }));
    } else if (shapeType === 'circle' || shapeType === 'round') {
      list.appendChild(createRulerRow('Ukuran X', -Infinity, Infinity, p.sizeX !== undefined ? p.sizeX : 100, '%', (v) => { p.sizeX = v; }));
      list.appendChild(createRulerRow('Ukuran Y', -Infinity, Infinity, p.sizeY !== undefined ? p.sizeY : 100, '%', (v) => { p.sizeY = v; }));
    } else if (shapeType === 'triangle') {
      list.appendChild(createRulerRow('Ukuran X', -Infinity, Infinity, p.sizeX !== undefined ? p.sizeX : 100, '%', (v) => { p.sizeX = v; }));
      list.appendChild(createRulerRow('Ukuran Y', -Infinity, Infinity, p.sizeY !== undefined ? p.sizeY : 100, '%', (v) => { p.sizeY = v; }));
      list.appendChild(createRulerRow('Curve', -Infinity, Infinity, p.curve !== undefined ? p.curve : 0, '%', (v) => { p.curve = v; }));
      list.appendChild(createRulerRow('Step', 3, Infinity, p.step !== undefined ? p.step : 3, '', (v) => { p.step = Math.max(3, Math.round(v)); }));
    } else if (shapeType === 'heart' || shapeType === 'love') {
      list.appendChild(createRulerRow('Ukuran X', -Infinity, Infinity, p.sizeX !== undefined ? p.sizeX : 100, '%', (v) => { p.sizeX = v; }));
      list.appendChild(createRulerRow('Ukuran Y', -Infinity, Infinity, p.sizeY !== undefined ? p.sizeY : 100, '%', (v) => { p.sizeY = v; }));
    } else if (shapeType === 'star' || shapeType === 'star-4') {
      list.appendChild(createRulerRow('Ukuran X', -Infinity, Infinity, p.sizeX !== undefined ? p.sizeX : 100, '%', (v) => { p.sizeX = v; }));
      list.appendChild(createRulerRow('Ukuran Y', -Infinity, Infinity, p.sizeY !== undefined ? p.sizeY : 100, '%', (v) => { p.sizeY = v; }));
      list.appendChild(createRulerRow('Inner Radius', 10, 90, p.innerRadius !== undefined ? p.innerRadius : (shapeType === 'star-4' ? 30 : 40), '%', (v) => { p.innerRadius = v; }));
    } else if (shapeType === 'hexagon') {
      list.appendChild(createRulerRow('Ukuran X', -Infinity, Infinity, p.sizeX !== undefined ? p.sizeX : 100, '%', (v) => { p.sizeX = v; }));
      list.appendChild(createRulerRow('Ukuran Y', -Infinity, Infinity, p.sizeY !== undefined ? p.sizeY : 100, '%', (v) => { p.sizeY = v; }));
    } else if (shapeType === 'line' || shapeType === 'arrow' || shapeType === 'svg_path') {
      list.appendChild(createRulerRow('Ketebalan', 2, 120, p.thickness !== undefined ? p.thickness : (shapeType === 'arrow' ? 16 : 14), 'px', (v) => { p.thickness = Math.max(2, v); }));
      if (shapeType === 'arrow') {
        list.appendChild(createRulerRow('Kepala Panah', 10, 150, p.headSize !== undefined ? p.headSize : 34, 'px', (v) => { p.headSize = Math.max(10, v); }));
      }
    }

    const isVectorEditable = (shapeType === 'line' || shapeType === 'arrow' || shapeType === 'svg_path');

    if (!isVectorEditable) {
      // Fill vs Outline Toggle Row for Standard Shapes
      const fillToggleRow = document.createElement('div');
      fillToggleRow.className = 'shape-slider-row';
      fillToggleRow.style.justifyContent = 'space-between';
      fillToggleRow.innerHTML = `
        <span class="shape-slider-lbl">Mode Render</span>
        <button type="button" class="am-shape-toggle-fill ${p.renderMode === 'outline' ? 'is-outline' : ''}" style="width: auto; min-width: 90px; flex-direction: row; gap: 6px; padding: 4px 12px; border-radius: 8px; font-size: 0.72rem;">
          <span class="material-symbols-rounded" style="font-size: 16px;">${p.renderMode === 'outline' ? 'crop_square' : 'format_color_fill'}</span>
          <span>${p.renderMode === 'outline' ? 'OUTLINE' : 'FILL'}</span>
        </button>
      `;
      const toggleBtn = fillToggleRow.querySelector('.am-shape-toggle-fill');
      toggleBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        p.renderMode = (p.renderMode === 'outline' ? 'fill' : 'outline');
        toggleBtn.classList.toggle('is-outline', p.renderMode === 'outline');
        toggleBtn.querySelector('span:nth-child(2)').textContent = (p.renderMode === 'outline' ? 'OUTLINE' : 'FILL');
        toggleBtn.querySelector('.material-symbols-rounded').textContent = (p.renderMode === 'outline' ? 'crop_square' : 'format_color_fill');
        applyFillToMeshGlobal(layerId);
        renderCanvasOverlay();
        triggerAutoSave();
      });
      list.appendChild(fillToggleRow);
    }

    contentEl.appendChild(list);

    // ── Alight Motion 3-Column Vector Path Editor (Only for SVG, Line, and Arrow) ──
    if (isVectorEditable) {
      if (!p.points || p.points.length < 2) {
        p.points = [{ x: -50, y: 0 }, { x: 50, y: 0 }];
      }

      let activePointIdx = Math.min(p.points.length - 1, Math.max(0, p.selectedPointIdx || 0));
      let activeEditorMode = 'move'; // 'move' | 'curve' | 'add'

      const editorWrap = document.createElement('div');
      editorWrap.className = 'am-shape-editor-wrap';

      // 1. Left Toolbar
      const leftBar = document.createElement('div');
      leftBar.className = 'am-shape-left-bar';

      const toolGroup = document.createElement('div');
      toolGroup.className = 'am-shape-tool-group';

      // Move Point Tool
      const btnMoveTool = document.createElement('button');
      btnMoveTool.type = 'button';
      btnMoveTool.className = 'am-shape-tool-btn' + (activeEditorMode === 'move' ? ' active' : '');
      btnMoveTool.title = 'Pindah Titik (Select / Move)';
      btnMoveTool.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <circle cx="12" cy="12" r="7" stroke-dasharray="2 2"></circle>
          <circle cx="12" cy="5" r="2" fill="currentColor"></circle>
          <circle cx="19" cy="12" r="2" fill="currentColor"></circle>
          <circle cx="12" cy="19" r="2" fill="currentColor"></circle>
          <circle cx="5" cy="12" r="2" fill="currentColor"></circle>
        </svg>
      `;

      // Curve Tool
      const btnCurveTool = document.createElement('button');
      btnCurveTool.type = 'button';
      btnCurveTool.className = 'am-shape-tool-btn' + (activeEditorMode === 'curve' ? ' active' : '');
      btnCurveTool.title = 'Kurva & Tangent Bezier';
      btnCurveTool.innerHTML = `
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M4 18 C 8 6, 16 6, 20 18"></path>
          <circle cx="12" cy="9" r="2" fill="currentColor"></circle>
          <line x1="6" y1="9" x2="18" y2="9" stroke-width="1.2"></line>
          <circle cx="6" cy="9" r="1.5" fill="currentColor"></circle>
          <circle cx="18" cy="9" r="1.5" fill="currentColor"></circle>
        </svg>
      `;

      // Add Point Tool
      const btnAddTool = document.createElement('button');
      btnAddTool.type = 'button';
      btnAddTool.className = 'am-shape-tool-btn' + (activeEditorMode === 'add' ? ' active' : '');
      btnAddTool.title = 'Tambah Titik Baru (+)';
      btnAddTool.innerHTML = '<span class="material-symbols-rounded" style="font-size:22px;">add_circle</span>';

      function setToolMode(mode) {
        activeEditorMode = mode;
        btnMoveTool.classList.toggle('active', mode === 'move');
        btnCurveTool.classList.toggle('active', mode === 'curve');
        btnAddTool.classList.toggle('active', mode === 'add');
        updatePadHint();
      }

      btnMoveTool.addEventListener('click', (e) => { e.stopPropagation(); setToolMode('move'); });
      btnCurveTool.addEventListener('click', (e) => { e.stopPropagation(); setToolMode('curve'); });
      btnAddTool.addEventListener('click', (e) => { e.stopPropagation(); setToolMode('add'); });

      toolGroup.appendChild(btnMoveTool);
      toolGroup.appendChild(btnCurveTool);
      toolGroup.appendChild(btnAddTool);
      leftBar.appendChild(toolGroup);

      // Bottom Toggle: Fill vs Outline
      const btnToggleFill = document.createElement('button');
      btnToggleFill.type = 'button';
      btnToggleFill.className = 'am-shape-toggle-fill' + (p.renderMode === 'outline' ? ' is-outline' : '');
      btnToggleFill.title = 'Ganti Mode: Fill Solid / Outline Stroke';
      btnToggleFill.innerHTML = `
        <span class="material-symbols-rounded" style="font-size:16px;">${p.renderMode === 'outline' ? 'crop_square' : 'format_color_fill'}</span>
        <span>${p.renderMode === 'outline' ? 'OUTLINE' : 'FILL'}</span>
      `;

      btnToggleFill.addEventListener('click', (e) => {
        e.stopPropagation();
        p.renderMode = (p.renderMode === 'outline' ? 'fill' : 'outline');
        btnToggleFill.classList.toggle('is-outline', p.renderMode === 'outline');
        btnToggleFill.querySelector('span:nth-child(2)').textContent = (p.renderMode === 'outline' ? 'OUTLINE' : 'FILL');
        btnToggleFill.querySelector('.material-symbols-rounded').textContent = (p.renderMode === 'outline' ? 'crop_square' : 'format_color_fill');
        applyFillToMeshGlobal(layerId);
        renderCanvasOverlay();
        triggerAutoSave();
      });

      leftBar.appendChild(btnToggleFill);

      // 2. Center Touch Gesture Pad
      const centerPad = document.createElement('div');
      centerPad.className = 'am-shape-center-pad';

      // 4 Corner Brackets
      const brTL = document.createElement('div'); brTL.className = 'am-corner-bracket am-corner-tl';
      const brTR = document.createElement('div'); brTR.className = 'am-corner-bracket am-corner-tr';
      const brBL = document.createElement('div'); brBL.className = 'am-corner-bracket am-corner-bl';
      const brBR = document.createElement('div'); brBR.className = 'am-corner-bracket am-corner-br';
      centerPad.appendChild(brTL);
      centerPad.appendChild(brTR);
      centerPad.appendChild(brBL);
      centerPad.appendChild(brBR);

      const padHint = document.createElement('div');
      padHint.className = 'am-shape-pad-hint';
      centerPad.appendChild(padHint);

      function updatePadHint() {
        if (activeEditorMode === 'add') {
          padHint.textContent = 'Swipe here to position next point, then tap here to place it';
        } else if (activeEditorMode === 'curve') {
          padHint.textContent = 'Swipe to curve and adjust tangent handles';
        } else {
          padHint.textContent = `Swipe to reposition point #${activePointIdx + 1}`;
        }
      }
      updatePadHint();

      // Center Gesture Drag tracking
      let isDraggingPad = false;
      let startX = 0, startY = 0;

      centerPad.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        centerPad.setPointerCapture(e.pointerId);
        isDraggingPad = true;
        startX = e.clientX;
        startY = e.clientY;
      });

      centerPad.addEventListener('pointermove', (e) => {
        if (!isDraggingPad) return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        startX = e.clientX;
        startY = e.clientY;

        const curPt = p.points[activePointIdx];
        if (curPt) {
          curPt.x = (Number(curPt.x) || 0) + dx * 0.7;
          curPt.y = (Number(curPt.y) || 0) - dy * 0.7;
          applyFillToMeshGlobal(layerId);
          renderCanvasOverlay();
          updateRailNodes();
        }
      });

      const finishPadDrag = (e) => {
        if (!isDraggingPad) return;
        isDraggingPad = false;
        try { centerPad.releasePointerCapture(e.pointerId); } catch(_) {}

        if (activeEditorMode === 'add' && Math.abs(e.clientX - startX) < 5 && Math.abs(e.clientY - startY) < 5) {
          // Tap to add point in add mode
          const lastPt = p.points[p.points.length - 1] || { x: 50, y: 0 };
          p.points.push({ x: (lastPt.x || 0) + 20, y: (lastPt.y || 0) + 20 });
          activePointIdx = p.points.length - 1;
          p.selectedPointIdx = activePointIdx;
          updateRailNodes();
          applyFillToMeshGlobal(layerId);
          renderCanvasOverlay();
        }
        triggerAutoSave();
      };

      centerPad.addEventListener('pointerup', finishPadDrag);
      centerPad.addEventListener('pointercancel', finishPadDrag);

      // 3. Right Vertical Rail
      const rightRail = document.createElement('div');
      rightRail.className = 'am-shape-right-rail';

      const railTrack = document.createElement('div');
      railTrack.className = 'am-rail-track-line';
      rightRail.appendChild(railTrack);

      const railActiveSegment = document.createElement('div');
      railActiveSegment.className = 'am-rail-active-segment';
      rightRail.appendChild(railActiveSegment);

      function updateRailNodes() {
        rightRail.querySelectorAll('.am-rail-node, .am-rail-crosshair-icon').forEach(n => n.remove());

        const num = p.points.length;
        if (num === 0) return;

        const height = rightRail.clientHeight || 180;
        const topPad = 20;
        const bottomPad = 20;
        const usableH = Math.max(40, height - topPad - bottomPad);

        p.points.forEach((pt, idx) => {
          const pct = num > 1 ? (idx / (num - 1)) : 0.5;
          const topY = topPad + pct * usableH;

          const node = document.createElement('div');
          node.className = 'am-rail-node' + (idx === activePointIdx ? ' active' : '');
          node.style.top = `${topY}px`;
          node.title = `Titik #${idx + 1}`;

          node.addEventListener('click', (ev) => {
            ev.stopPropagation();
            activePointIdx = idx;
            p.selectedPointIdx = activePointIdx;
            updateRailNodes();
            updatePadHint();
            renderCanvasOverlay();
          });

          rightRail.appendChild(node);

          if (idx === activePointIdx) {
            const cross = document.createElement('span');
            cross.className = 'material-symbols-rounded am-rail-crosshair-icon';
            cross.style.top = `${topY}px`;
            cross.textContent = 'add';
            rightRail.appendChild(cross);

            // Update active segment bar
            if (idx > 0) {
              const prevPct = (idx - 1) / (num - 1);
              const prevY = topPad + prevPct * usableH;
              railActiveSegment.style.top = `${prevY}px`;
              railActiveSegment.style.height = `${topY - prevY}px`;
              railActiveSegment.style.display = 'block';
            } else {
              railActiveSegment.style.display = 'none';
            }
          }
        });
      }

      // Vertical Drag Scrubber on Rail
      let isDraggingRail = false;
      rightRail.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        rightRail.setPointerCapture(e.pointerId);
        isDraggingRail = true;
        handleRailScrub(e);
      });

      rightRail.addEventListener('pointermove', (e) => {
        if (!isDraggingRail) return;
        handleRailScrub(e);
      });

      const finishRailScrub = (e) => {
        if (!isDraggingRail) return;
        isDraggingRail = false;
        try { rightRail.releasePointerCapture(e.pointerId); } catch(_) {}
        triggerAutoSave();
      };

      rightRail.addEventListener('pointerup', finishRailScrub);
      rightRail.addEventListener('pointercancel', finishRailScrub);

      function handleRailScrub(e) {
        const rect = rightRail.getBoundingClientRect();
        const relY = Math.max(0, Math.min(rect.height, e.clientY - rect.top));
        const pct = relY / rect.height;
        const targetIdx = Math.round(pct * (p.points.length - 1));
        if (targetIdx !== activePointIdx && targetIdx >= 0 && targetIdx < p.points.length) {
          activePointIdx = targetIdx;
          p.selectedPointIdx = activePointIdx;
          updateRailNodes();
          updatePadHint();
          renderCanvasOverlay();
        }
      }

      editorWrap.appendChild(leftBar);
      editorWrap.appendChild(centerPad);
      editorWrap.appendChild(rightRail);
      contentEl.appendChild(editorWrap);

      setTimeout(() => {
        updateRailNodes();
      }, 40);
    }
  }

  btnInspEditShape.addEventListener('click', (e) => {
    e.stopPropagation();
    if (!selectedTrackRow) return;
    const id = selectedTrackRow.dataset.layerId || 'default';
    openInspectorSubpanel(panelShape, 'subpanel-shape', () => {
      renderShapeControls(id);
    });
  });

  if (btnBackShape) {
    btnBackShape.addEventListener('click', (e) => {
      e.stopPropagation();
      closeInspectorSubpanel(panelShape);
    });
  }
}

const layerCameraParams = new Map();

function getLayerCameraParams(layerId) {
  let p = layerCameraParams.get(layerId);
  if (!p) {
    p = {
      zoom: 100,
      bokehEnabled: false,
      focusMode: 'auto',
      focusTargetId: '',
      manualFocusDist: 100,
      bokehBlur: 50,
      bokehRange: 60
    };
    layerCameraParams.set(layerId, p);
  }
  return p;
}

function initCameraControlSubpanel() {
  const btnInspCamera = document.getElementById('btnInspCameraControl');
  const panelCamera = document.getElementById('panelCameraControl');
  const btnBackCamera = document.getElementById('btnBackFromCameraControl');
  const btnReset = document.getElementById('btnResetCameraView');

  // Zoom
  const sliderZoom = document.getElementById('sliderCameraZoom');
  const valZoom = document.getElementById('valCameraZoom');

  // Bokeh
  const toggleBokeh = document.getElementById('toggleCameraBokeh');
  const bokehSettings = document.getElementById('cameraBokehSettings');
  const btnModeAuto = document.getElementById('btnFocusModeAuto');
  const btnModeManual = document.getElementById('btnFocusModeManual');
  const boxTargetLayer = document.getElementById('boxFocusTargetLayer');
  const selectTargetLayer = document.getElementById('selectFocusTargetLayer');
  const boxManualDist = document.getElementById('boxFocusManualDist');
  const sliderManualDist = document.getElementById('sliderFocusDist');
  const valManualDist = document.getElementById('valFocusDist');
  const sliderBokehBlur = document.getElementById('sliderBokehBlur');
  const valBokehBlur = document.getElementById('valBokehBlur');
  const sliderBokehRange = document.getElementById('sliderBokehRange');
  const valBokehRange = document.getElementById('valBokehRange');

  if (btnInspCamera && panelCamera) {
    btnInspCamera.addEventListener('click', (e) => {
      e.stopPropagation();
      openInspectorSubpanel(panelCamera, 'subpanel-camera', () => {
        syncCameraControlUI();
      });
    });
  }

  if (btnBackCamera && panelCamera) {
    btnBackCamera.addEventListener('click', (e) => {
      e.stopPropagation();
      closeInspectorSubpanel(panelCamera);
    });
  }

  if (btnReset) {
    btnReset.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const t = getLayerTransform(id);
      t.posX = 0; t.posY = 0; t.posZ = 0;
      t.rotX = 0; t.rotY = 0; t.rotZ = 0;
      t.scaleW = 100; t.scaleH = 100;

      const cp = getLayerCameraParams(id);
      cp.zoom = 100;
      cp.bokehEnabled = false;
      cp.focusMode = 'auto';
      cp.focusTargetId = '';
      cp.manualFocusDist = 100;
      cp.bokehBlur = 50;
      cp.bokehRange = 60;

      syncCameraControlUI();
      syncControllerUI();
      render3D();
      renderCanvasOverlay();
      triggerAutoSave();
    });
  }

  // 1. Zoom Slider
  if (sliderZoom) {
    sliderZoom.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.zoom = Number(sliderZoom.value) || 100;
      if (valZoom) valZoom.textContent = `${cp.zoom}%`;
      render3D();
      renderCanvasOverlay();
      triggerAutoSave();
    });
  }

  // 2. Bokeh Toggle
  if (toggleBokeh) {
    toggleBokeh.addEventListener('change', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.bokehEnabled = toggleBokeh.checked;
      if (bokehSettings) {
        bokehSettings.style.display = cp.bokehEnabled ? 'flex' : 'none';
      }
      render3D();
      triggerAutoSave();
    });
  }

  // 3. Focus Mode Switch (Auto Focus vs Manual)
  if (btnModeAuto) {
    btnModeAuto.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.focusMode = 'auto';
      btnModeAuto.classList.add('active');
      if (btnModeManual) btnModeManual.classList.remove('active');
      if (boxTargetLayer) boxTargetLayer.style.display = 'flex';
      if (boxManualDist) boxManualDist.style.display = 'none';
      render3D();
      triggerAutoSave();
    });
  }

  if (btnModeManual) {
    btnModeManual.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.focusMode = 'manual';
      btnModeManual.classList.add('active');
      if (btnModeAuto) btnModeAuto.classList.remove('active');
      if (boxTargetLayer) boxTargetLayer.style.display = 'none';
      if (boxManualDist) boxManualDist.style.display = 'flex';
      render3D();
      triggerAutoSave();
    });
  }

  // 4. Target Layer Dropdown
  if (selectTargetLayer) {
    selectTargetLayer.addEventListener('change', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.focusTargetId = selectTargetLayer.value;
      render3D();
      triggerAutoSave();
    });
  }

  // 5. Manual Focus Distance
  if (sliderManualDist) {
    sliderManualDist.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.manualFocusDist = Number(sliderManualDist.value) || 100;
      if (valManualDist) valManualDist.textContent = `${cp.manualFocusDist} px`;
      render3D();
      triggerAutoSave();
    });
  }

  // 6. Bokeh Blur Strength
  if (sliderBokehBlur) {
    sliderBokehBlur.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.bokehBlur = Number(sliderBokehBlur.value) || 50;
      if (valBokehBlur) valBokehBlur.textContent = `${cp.bokehBlur}%`;
      render3D();
      triggerAutoSave();
    });
  }

  // 7. Bokeh Depth Range / Falloff
  if (sliderBokehRange) {
    sliderBokehRange.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cp = getLayerCameraParams(id);
      cp.bokehRange = Number(sliderBokehRange.value) || 60;
      if (valBokehRange) valBokehRange.textContent = `${cp.bokehRange} px`;
      render3D();
      triggerAutoSave();
    });
  }

  function populateFocusTargetLayers(currentCamId, selectedTargetId) {
    if (!selectTargetLayer) return;
    selectTargetLayer.innerHTML = '<option value="">-- Pilih Layer Target --</option>';

    const rows = document.querySelectorAll('.track-row');
    rows.forEach(r => {
      const lid = r.dataset.layerId;
      if (!lid || lid === currentCamId) return;
      const cat = r.dataset.category || 'media';
      if (cat === 'camera') return;

      const name = r.querySelector('.track-clip-name')?.textContent.trim() || `Layer ${lid}`;
      const opt = document.createElement('option');
      opt.value = lid;
      opt.textContent = `${name} (${cat})`;
      if (lid === selectedTargetId) {
        opt.selected = true;
      }
      selectTargetLayer.appendChild(opt);
    });
  }

  function syncCameraControlUI() {
    if (!selectedTrackRow) return;
    const id = selectedTrackRow.dataset.layerId;
    const cp = getLayerCameraParams(id);

    // Zoom
    if (sliderZoom) sliderZoom.value = cp.zoom || 100;
    if (valZoom) valZoom.textContent = `${cp.zoom || 100}%`;

    // Bokeh Toggle
    if (toggleBokeh) toggleBokeh.checked = !!cp.bokehEnabled;
    if (bokehSettings) bokehSettings.style.display = cp.bokehEnabled ? 'flex' : 'none';

    // Focus Mode
    const isAuto = cp.focusMode !== 'manual';
    if (btnModeAuto) btnModeAuto.classList.toggle('active', isAuto);
    if (btnModeManual) btnModeManual.classList.toggle('active', !isAuto);
    if (boxTargetLayer) boxTargetLayer.style.display = isAuto ? 'flex' : 'none';
    if (boxManualDist) boxManualDist.style.display = !isAuto ? 'flex' : 'none';

    // Populate Layers
    populateFocusTargetLayers(id, cp.focusTargetId);

    // Sliders
    if (sliderManualDist) sliderManualDist.value = cp.manualFocusDist || 100;
    if (valManualDist) valManualDist.textContent = `${cp.manualFocusDist || 100} px`;

    if (sliderBokehBlur) sliderBokehBlur.value = cp.bokehBlur !== undefined ? cp.bokehBlur : 50;
    if (valBokehBlur) valBokehBlur.textContent = `${cp.bokehBlur !== undefined ? cp.bokehBlur : 50}%`;

    if (sliderBokehRange) sliderBokehRange.value = cp.bokehRange !== undefined ? cp.bokehRange : 60;
    if (valBokehRange) valBokehRange.textContent = `${cp.bokehRange !== undefined ? cp.bokehRange : 60} px`;
  }
}

// ════════════════════════════════════════════════════════════════
// Dynamic Google Fonts Catalog Loader & Unloader
// ════════════════════════════════════════════════════════════════
let _dynamicGoogleFontsCatalog = null;
let _isFetchingGoogleFontsCatalog = false;

async function getGoogleFontsCatalog() {
  if (_dynamicGoogleFontsCatalog && _dynamicGoogleFontsCatalog.length > 0) {
    return _dynamicGoogleFontsCatalog;
  }
  if (_isFetchingGoogleFontsCatalog) {
    while (_isFetchingGoogleFontsCatalog) {
      await new Promise(r => setTimeout(r, 80));
    }
    return _dynamicGoogleFontsCatalog || [];
  }

  _isFetchingGoogleFontsCatalog = true;
  try {
    const res = await fetch('https://raw.githubusercontent.com/jonathantneal/google-fonts-complete/master/google-fonts.json');
    if (res.ok) {
      const data = await res.json();
      const list = Object.keys(data).map(fontName => {
        const item = data[fontName] || {};
        let cat = item.category || 'sans-serif';
        if (cat !== 'display' && cat !== 'handwriting' && cat !== 'monospace' && cat !== 'serif' && cat !== 'sans-serif') {
          cat = 'sans-serif';
        }
        return {
          name: fontName,
          category: cat,
          preview: fontName
        };
      });
      if (list && list.length > 50) {
        _dynamicGoogleFontsCatalog = list;
        _isFetchingGoogleFontsCatalog = false;
        return _dynamicGoogleFontsCatalog;
      }
    }
  } catch (err) {
    console.warn('Online Google Fonts catalog fetch failed, loading comprehensive built-in catalog', err);
  }

  // Fallback comprehensive catalog (100+ Google Fonts)
  _dynamicGoogleFontsCatalog = [
    // Sans-Serif
    { name: 'Poppins', category: 'sans-serif', preview: 'Poppins' },
    { name: 'Montserrat', category: 'sans-serif', preview: 'Montserrat' },
    { name: 'Plus Jakarta Sans', category: 'sans-serif', preview: 'Plus Jakarta Sans' },
    { name: 'Inter', category: 'sans-serif', preview: 'Inter' },
    { name: 'Roboto', category: 'sans-serif', preview: 'Roboto' },
    { name: 'Open Sans', category: 'sans-serif', preview: 'Open Sans' },
    { name: 'Lato', category: 'sans-serif', preview: 'Lato' },
    { name: 'Oswald', category: 'sans-serif', preview: 'Oswald' },
    { name: 'Raleway', category: 'sans-serif', preview: 'Raleway' },
    { name: 'Nunito', category: 'sans-serif', preview: 'Nunito' },
    { name: 'Rubik', category: 'sans-serif', preview: 'Rubik' },
    { name: 'Work Sans', category: 'sans-serif', preview: 'Work Sans' },
    { name: 'DM Sans', category: 'sans-serif', preview: 'DM Sans' },
    { name: 'Outfit', category: 'sans-serif', preview: 'Outfit' },
    { name: 'Ubuntu', category: 'sans-serif', preview: 'Ubuntu' },
    { name: 'Quicksand', category: 'sans-serif', preview: 'Quicksand' },
    { name: 'Manrope', category: 'sans-serif', preview: 'Manrope' },
    { name: 'Barlow', category: 'sans-serif', preview: 'Barlow' },
    { name: 'Josefin Sans', category: 'sans-serif', preview: 'Josefin Sans' },
    { name: 'Kanit', category: 'sans-serif', preview: 'Kanit' },
    { name: 'Space Grotesk', category: 'sans-serif', preview: 'Space Grotesk' },
    { name: 'Sora', category: 'sans-serif', preview: 'Sora' },

    // Serif
    { name: 'Playfair Display', category: 'serif', preview: 'Playfair Display' },
    { name: 'Merriweather', category: 'serif', preview: 'Merriweather' },
    { name: 'Lora', category: 'serif', preview: 'Lora' },
    { name: 'PT Serif', category: 'serif', preview: 'PT Serif' },
    { name: 'Cinzel', category: 'serif', preview: 'Cinzel' },
    { name: 'Cormorant Garamond', category: 'serif', preview: 'Cormorant Garamond' },
    { name: 'EB Garamond', category: 'serif', preview: 'EB Garamond' },
    { name: 'Bitter', category: 'serif', preview: 'Bitter' },
    { name: 'Spectral', category: 'serif', preview: 'Spectral' },
    { name: 'Bodoni Moda', category: 'serif', preview: 'Bodoni Moda' },
    { name: 'Libre Baskerville', category: 'serif', preview: 'Libre Baskerville' },
    { name: 'DM Serif Display', category: 'serif', preview: 'DM Serif Display' },
    { name: 'Fraunces', category: 'serif', preview: 'Fraunces' },

    // Display
    { name: 'Bebas Neue', category: 'display', preview: 'Bebas Neue' },
    { name: 'Anton', category: 'display', preview: 'Anton' },
    { name: 'Bangers', category: 'display', preview: 'Bangers' },
    { name: 'Righteous', category: 'display', preview: 'Righteous' },
    { name: 'Alfa Slab One', category: 'display', preview: 'Alfa Slab One' },
    { name: 'Lobster', category: 'display', preview: 'Lobster' },
    { name: 'Abril Fatface', category: 'display', preview: 'Abril Fatface' },
    { name: 'Permanent Marker', category: 'display', preview: 'Permanent Marker' },
    { name: 'Shrikhand', category: 'display', preview: 'Shrikhand' },
    { name: 'Russo One', category: 'display', preview: 'Russo One' },
    { name: 'Fredoka One', category: 'display', preview: 'Fredoka One' },
    { name: 'Audiowide', category: 'display', preview: 'Audiowide' },
    { name: 'Press Start 2P', category: 'display', preview: 'Press Start 2P' },
    { name: 'Luckiest Guy', category: 'display', preview: 'Luckiest Guy' },
    { name: 'Staatliches', category: 'display', preview: 'Staatliches' },
    { name: 'Chango', category: 'display', preview: 'Chango' },

    // Handwriting
    { name: 'Caveat', category: 'handwriting', preview: 'Caveat' },
    { name: 'Dancing Script', category: 'handwriting', preview: 'Dancing Script' },
    { name: 'Pacifico', category: 'handwriting', preview: 'Pacifico' },
    { name: 'Great Vibes', category: 'handwriting', preview: 'Great Vibes' },
    { name: 'Sacramento', category: 'handwriting', preview: 'Sacramento' },
    { name: 'Satisfy', category: 'handwriting', preview: 'Satisfy' },
    { name: 'Indie Flower', category: 'handwriting', preview: 'Indie Flower' },
    { name: 'Shadows Into Light', category: 'handwriting', preview: 'Shadows Into Light' },
    { name: 'Kaushan Script', category: 'handwriting', preview: 'Kaushan Script' },
    { name: 'Alex Brush', category: 'handwriting', preview: 'Alex Brush' },
    { name: 'Rock Salt', category: 'handwriting', preview: 'Rock Salt' },
    { name: 'Allura', category: 'handwriting', preview: 'Allura' },
    { name: 'Parisienne', category: 'handwriting', preview: 'Parisienne' },

    // Monospace
    { name: 'JetBrains Mono', category: 'monospace', preview: 'JetBrains Mono' },
    { name: 'Fira Code', category: 'monospace', preview: 'Fira Code' },
    { name: 'Roboto Mono', category: 'monospace', preview: 'Roboto Mono' },
    { name: 'Source Code Pro', category: 'monospace', preview: 'Source Code Pro' },
    { name: 'Space Mono', category: 'monospace', preview: 'Space Mono' },
    { name: 'Inconsolata', category: 'monospace', preview: 'Inconsolata' },
    { name: 'IBM Plex Mono', category: 'monospace', preview: 'IBM Plex Mono' },
    { name: 'VT323', category: 'monospace', preview: 'VT323' },
    { name: 'Share Tech Mono', category: 'monospace', preview: 'Share Tech Mono' }
  ];

  _isFetchingGoogleFontsCatalog = false;
  return _dynamicGoogleFontsCatalog;
}

function openFontGalleryPopover(anchorEl, currentFont, onSelectFont) {
  let card = document.createElement('div');
  card.className = 'fish-font-gallery-popover-card';

  card.innerHTML = `
    <div class="font-gallery-search-row">
      <span class="material-symbols-rounded" style="font-size:18px; color:var(--col-yellow); opacity:0.7;">search</span>
      <input type="text" class="font-gallery-search-input" id="fontSearchInput" placeholder="Cari seluruh font Google...">
    </div>
    <div class="font-gallery-cats-row" id="fontCategoryTabs">
      <button type="button" class="font-cat-pill active" data-cat="all">Semua</button>
      <button type="button" class="font-cat-pill" data-cat="sans-serif">Sans-Serif</button>
      <button type="button" class="font-cat-pill" data-cat="serif">Serif</button>
      <button type="button" class="font-cat-pill" data-cat="display">Display</button>
      <button type="button" class="font-cat-pill" data-cat="handwriting">Handwriting</button>
      <button type="button" class="font-cat-pill" data-cat="monospace">Monospace</button>
    </div>
    <div class="font-gallery-list" id="fontGalleryList">
      <div style="color:rgba(255,242,194,0.6); font-size:0.78rem; text-align:center; padding:24px; font-weight:600;">
        <span class="material-symbols-rounded" style="font-size:24px; animation:spin 1s linear infinite; display:block; margin:0 auto 6px auto;">progress_activity</span>
        Memuat katalog Google Fonts...
      </div>
    </div>
  `;

  const listEl = card.querySelector('#fontGalleryList');
  const searchInput = card.querySelector('#fontSearchInput');
  const catTabs = card.querySelector('#fontCategoryTabs');

  let activeCat = 'all';
  let searchQuery = '';
  let fullCatalog = [];
  let pageLimit = 40;
  let isUnloaded = false;

  function renderList() {
    if (isUnloaded || !listEl) return;
    listEl.innerHTML = '';

    const filtered = fullCatalog.filter(f => {
      const matchCat = (activeCat === 'all' || f.category === activeCat);
      const matchQuery = !searchQuery || f.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchQuery;
    });

    if (filtered.length === 0) {
      listEl.innerHTML = `<div style="color:rgba(255,242,194,0.5); font-size:0.75rem; text-align:center; padding:20px;">Tidak ada font "${searchQuery}" ditemukan</div>`;
      return;
    }

    const itemsToRender = filtered.slice(0, pageLimit);
    itemsToRender.forEach(font => {
      const item = document.createElement('div');
      const isCur = (font.name.toLowerCase() === (currentFont || '').toLowerCase());
      item.className = 'font-gallery-item' + (isCur ? ' active' : '');

      item.innerHTML = `
        <div class="font-item-meta">
          <span class="font-item-name">${font.name}</span>
          <span class="font-item-sample">${font.preview || font.name}</span>
        </div>
        ${isCur ? '<span class="material-symbols-rounded" style="font-size:18px; color:var(--col-yellow);">check</span>' : ''}
      `;

      item.addEventListener('mouseenter', () => {
        if (typeof loadGoogleFont === 'function') {
          loadGoogleFont(font.name).then(() => {
            const nameSpan = item.querySelector('.font-item-name');
            const sampleSpan = item.querySelector('.font-item-sample');
            if (nameSpan) nameSpan.style.fontFamily = `'${font.name}', sans-serif`;
            if (sampleSpan) sampleSpan.style.fontFamily = `'${font.name}', sans-serif`;
          });
        }
      });

      item.addEventListener('click', (e) => {
        e.stopPropagation();
        if (typeof loadGoogleFont === 'function') {
          loadGoogleFont(font.name).then(() => {
            if (onSelectFont) onSelectFont(font.name);
            if (window.FishPopover) window.FishPopover.close();
          });
        } else {
          if (onSelectFont) onSelectFont(font.name);
          if (window.FishPopover) window.FishPopover.close();
        }
      });

      listEl.appendChild(item);
    });

    if (filtered.length > pageLimit) {
      const loadMoreBtn = document.createElement('button');
      loadMoreBtn.type = 'button';
      loadMoreBtn.style.cssText = 'background:rgba(255,242,194,0.12); border:1px solid rgba(255,242,194,0.2); color:#FFF2C2; border-radius:8px; padding:6px; font-size:0.75rem; font-weight:700; cursor:pointer; margin:4px 0;';
      loadMoreBtn.textContent = `Muat lebih banyak (${filtered.length - pageLimit} font tersisa)`;
      loadMoreBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        pageLimit += 40;
        renderList();
      });
      listEl.appendChild(loadMoreBtn);
    }
  }

  // Load catalog on popover open
  getGoogleFontsCatalog().then(cat => {
    if (isUnloaded) return;
    fullCatalog = cat || [];
    renderList();
  });

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      searchQuery = e.target.value.trim();
      pageLimit = 40;
      renderList();
    });
  }

  if (catTabs) {
    catTabs.querySelectorAll('.font-cat-pill').forEach(pill => {
      pill.addEventListener('click', (e) => {
        e.stopPropagation();
        catTabs.querySelectorAll('.font-cat-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        activeCat = pill.dataset.cat;
        pageLimit = 40;
        renderList();
      });
    });
  }

  if (window.FishPopover) {
    window.FishPopover.show({
      anchorElement: anchorEl,
      content: card,
      className: 'fish-font-popover-wrapper',
      onClose: () => {
        // Unload list from DOM on popover close to free memory
        isUnloaded = true;
        fullCatalog = [];
        if (card) {
          card.innerHTML = '';
          card = null;
        }
      }
    });
  }
}

function initEditTextSubpanel() {
  const btnInspEditText = document.getElementById('btnInspEditText');
  const panelText = document.getElementById('panelEditText');
  const btnBackText = document.getElementById('btnBackFromEditText');
  const btnBrowseFont = document.getElementById('btnBrowseFontGallery');
  const fontLabel = document.getElementById('currentFontNameLabel');

  const textInput = document.getElementById('textInputArea');
  const sliderSize = document.getElementById('sliderTextSize');
  const valSize = document.getElementById('valTextSize');

  const alignSegmented = document.getElementById('textAlignSegmented');
  const btnBold = document.getElementById('btnToggleBold');
  const btnItalic = document.getElementById('btnToggleItalic');
  const btnUnderline = document.getElementById('btnToggleUnderline');
  const btnUppercase = document.getElementById('btnToggleUppercase');

  const sliderSpacing = document.getElementById('sliderTextLetterSpacing');
  const sliderLineHeight = document.getElementById('sliderTextLineHeight');
  const valSpacingLeading = document.getElementById('valTextSpacingLeading');

  function syncTextUI(layerId) {
    if (!layerId) return;
    const tData = (typeof getLayerText === 'function') ? getLayerText(layerId) : { content: 'Heading Title', font: 'Poppins', size: 48, align: 'center', bold: true, italic: false, underline: false, uppercase: false, letterSpacing: 0, lineHeight: 1.2 };

    if (fontLabel) fontLabel.textContent = tData.font || 'Poppins';
    if (textInput) textInput.value = tData.content || '';

    if (sliderSize) sliderSize.value = tData.size || 48;
    if (valSize) valSize.textContent = `${tData.size || 48} px`;

    if (alignSegmented) {
      alignSegmented.querySelectorAll('.text-format-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.align === (tData.align || 'center'));
      });
    }

    if (btnBold) btnBold.classList.toggle('active', !!tData.bold);
    if (btnItalic) btnItalic.classList.toggle('active', !!tData.italic);
    if (btnUnderline) btnUnderline.classList.toggle('active', !!tData.underline);
    if (btnUppercase) btnUppercase.classList.toggle('active', !!tData.uppercase);

    if (sliderSpacing) sliderSpacing.value = tData.letterSpacing || 0;
    if (sliderLineHeight) sliderLineHeight.value = tData.lineHeight !== undefined ? tData.lineHeight : 1.2;
    if (valSpacingLeading) {
      valSpacingLeading.textContent = `${tData.letterSpacing || 0}px \u2022 ${(tData.lineHeight !== undefined ? tData.lineHeight : 1.2)}x`;
    }
  }

  function applyTextChange(layerId) {
    if (!layerId) return;
    applyFillToMeshGlobal(layerId);
    if (typeof renderCanvasOverlay === 'function') renderCanvasOverlay();
    render3D();
    triggerAutoSave();
  }

  if (btnInspEditText && panelText) {
    btnInspEditText.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId || 'default';
      openInspectorSubpanel(panelText, 'subpanel-text', () => {
        syncTextUI(id);
      });
    });
  }

  if (btnBackText && panelText) {
    btnBackText.addEventListener('click', (e) => {
      e.stopPropagation();
      closeInspectorSubpanel(panelText);
    });
  }

  if (btnBrowseFont) {
    btnBrowseFont.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const tData = getLayerText(id);
      openFontGalleryPopover(btnBrowseFont, tData.font, (newFont) => {
        tData.font = newFont;
        if (fontLabel) fontLabel.textContent = newFont;
        applyTextChange(id);
      });
    });
  }

  if (textInput) {
    textInput.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const tData = getLayerText(id);
      tData.content = textInput.value;

      const clipName = selectedTrackRow.querySelector('.track-clip-name');
      if (clipName) {
        const firstLine = textInput.value.trim().split('\n')[0] || 'Text Layer';
        clipName.textContent = firstLine.length > 22 ? firstLine.slice(0, 20) + '...' : firstLine;
      }

      applyTextChange(id);
    });
  }

  if (sliderSize) {
    sliderSize.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const tData = getLayerText(id);
      tData.size = parseFloat(sliderSize.value) || 48;
      if (valSize) valSize.textContent = `${tData.size} px`;
      applyTextChange(id);
    });
  }

  if (alignSegmented) {
    alignSegmented.querySelectorAll('.text-format-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!selectedTrackRow) return;
        const id = selectedTrackRow.dataset.layerId;
        const tData = getLayerText(id);
        alignSegmented.querySelectorAll('.text-format-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        tData.align = btn.dataset.align;
        applyTextChange(id);
      });
    });
  }

  const bindToggle = (btn, prop) => {
    if (!btn) return;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const tData = getLayerText(id);
      tData[prop] = !tData[prop];
      btn.classList.toggle('active', tData[prop]);
      applyTextChange(id);
    });
  };

  bindToggle(btnBold, 'bold');
  bindToggle(btnItalic, 'italic');
  bindToggle(btnUnderline, 'underline');
  bindToggle(btnUppercase, 'uppercase');

  if (sliderSpacing) {
    sliderSpacing.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const tData = getLayerText(id);
      tData.letterSpacing = parseInt(sliderSpacing.value) || 0;
      if (valSpacingLeading) valSpacingLeading.textContent = `${tData.letterSpacing}px \u2022 ${(tData.lineHeight !== undefined ? tData.lineHeight : 1.2)}x`;
      applyTextChange(id);
    });
  }

  if (sliderLineHeight) {
    sliderLineHeight.addEventListener('input', () => {
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const tData = getLayerText(id);
      tData.lineHeight = parseFloat(sliderLineHeight.value) || 1.2;
      if (valSpacingLeading) valSpacingLeading.textContent = `${tData.letterSpacing || 0}px \u2022 ${(tData.lineHeight)}x`;
      applyTextChange(id);
    });
  }
}

function syncBorderShadowUI() {
  if (!selectedTrackRow) return;
  const id = selectedTrackRow.dataset.layerId || 'default';
  const bs = getLayerBorderShadow(id);
  const base = layerBorderShadow.get(id) || bs;

  // Stroke UI
  const toggleStroke = document.getElementById('toggleStrokeEnabled');
  if (toggleStroke) toggleStroke.checked = !!base.stroke.enabled;

  const strokeBox = document.getElementById('strokeColorBox');
  if (strokeBox) strokeBox.style.background = bs.stroke.color || '#000000';

  const valStrokeSize = document.getElementById('valStrokeSize');
  if (valStrokeSize) valStrokeSize.textContent = Number(bs.stroke.size || 4).toFixed(1);
  if (strokeSizeRulerInstance) strokeSizeRulerInstance.setValue(bs.stroke.size || 4);

  document.querySelectorAll('#strokeCapGroup button').forEach(b => {
    b.classList.toggle('active', b.dataset.cap === (bs.stroke.cap || 'butt'));
  });
  document.querySelectorAll('#strokeAlignGroup button').forEach(b => {
    b.classList.toggle('active', b.dataset.align === (bs.stroke.align || 'center'));
  });

  // Shadow UI
  const toggleShadow = document.getElementById('toggleShadowEnabled');
  if (toggleShadow) toggleShadow.checked = !!base.shadow.enabled;

  const shadowBox = document.getElementById('shadowColorBox');
  if (shadowBox) shadowBox.style.background = bs.shadow.color || '#000000';

  const p = parseHexOrRgbLocal(bs.shadow.color || '#000000');
  const rgbText = document.getElementById('shadowRgbText');
  if (rgbText) rgbText.textContent = `${p.r} ${p.g} ${p.b}`;

  const valShadowSize = document.getElementById('valShadowSize');
  if (valShadowSize) valShadowSize.textContent = bs.shadow.size !== undefined ? bs.shadow.size : 4;
  if (shadowSizeRulerInstance) shadowSizeRulerInstance.setValue(bs.shadow.size !== undefined ? bs.shadow.size : 4);

  const valShadowAlpha = document.getElementById('valShadowAlpha');
  if (valShadowAlpha) valShadowAlpha.textContent = `${bs.shadow.alpha !== undefined ? bs.shadow.alpha : 100}%`;
  if (shadowAlphaRulerInstance) shadowAlphaRulerInstance.setValue(bs.shadow.alpha !== undefined ? bs.shadow.alpha : 100);

  const valPosX = document.getElementById('valShadowPosX');
  const valPosY = document.getElementById('valShadowPosY');
  if (valPosX) valPosX.textContent = bs.shadow.posX !== undefined ? bs.shadow.posX : 3;
  if (valPosY) valPosY.textContent = bs.shadow.posY !== undefined ? bs.shadow.posY : 3;

  if (shadowPosRulerInstance) {
    shadowPosRulerInstance.setValue(activeShadowAxis === 'X' ? (bs.shadow.posX || 3) : (bs.shadow.posY || 3));
  }

  // update disabled visual state
  syncBorderShadowDisabledUI();
}

function applyBorderShadowToMesh(id) {
  applyFillToMeshGlobal(id);
}

let projectRatio = '9:16';
let projectResolution = '1080p';
let projectBgColor = '#000000';
let projectCustomWidth = 1080;
let projectCustomHeight = 1080;
