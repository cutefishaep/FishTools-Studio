CATEGORY_ITEMS = {
  shape: [],
  media: [],
  camera: [
    { icon: 'videocam', name: 'Camera', filename: 'Camera_1', sub: 'Camera Layer', cat: 'camera' },
    { icon: 'crop_free', name: 'Null', filename: 'Null_1', sub: 'Null Object', cat: 'null' }
  ],
  text: [
    { icon: 'title', name: 'Judul Utama', filename: 'Heading_Title.txt', content: 'Judul Utama', font: 'Poppins', size: 52, bold: true },
    { icon: 'subtitles', name: 'Subtitle Caption', filename: 'Subtitle_Text.txt', content: 'Keterangan subtitle di sini...', font: 'Montserrat', size: 36, bold: false },
    { icon: 'label', name: 'Badge Callout', filename: 'Badge_Callout.txt', content: 'BADGE CALLOUT', font: 'Bebas Neue', size: 44, bold: true, uppercase: true }
  ]
};

function renderCategoryItems(catKey) {
  const grid = document.getElementById('popoverItemsGrid') || document.getElementById('popoverItemsShelf');
  if (!grid) return;

  const popover = document.getElementById('addTrackPopover');
  if (popover) {
    popover.classList.remove('cat-shape', 'cat-media', 'cat-camera', 'cat-text');
    popover.classList.add('cat-' + catKey);
  }

  grid.innerHTML = '';
  grid.className = 'popover-items-grid';

  if (catKey === 'shape') {
    grid.className = 'popover-items-grid shape-tile-grid';
    SHAPE_PICKER_ITEMS.forEach(shape => {
      const tile = document.createElement('button');
      tile.type = 'button';
      tile.className = 'shape-shelf-tile';
      tile.title = `Tambah ${shape.title || 'Bentuk'}`;
      tile.innerHTML = `
        <div class="shape-tile-preview">
          <span class="material-symbols-rounded">${shape.icon}</span>
        </div>
        <span class="shape-tile-title">${shape.title}</span>
      `;
      tile.addEventListener('click', (e) => {
        e.stopPropagation();
        addTrackWithType('shape', `${shape.title || 'Shape'}.svg`, null, shape.type || 'square');
        const popover = document.getElementById('addTrackPopover');
        const fab = document.getElementById('fabAddTrack');
        if (popover) popover.classList.remove('active');
        if (fab) fab.classList.remove('active');
      });
      grid.appendChild(tile);
    });

    const btnImportSvg = document.createElement('button');
    btnImportSvg.type = 'button';
    btnImportSvg.className = 'shape-shelf-tile import-svg-tile-btn';
    btnImportSvg.title = 'Import File SVG (.svg)';
    btnImportSvg.innerHTML = `
      <div class="shape-tile-preview">
        <span class="material-symbols-rounded" style="color:var(--col-cream, #FAB778);">upload_file</span>
      </div>
      <span class="shape-tile-title">Import SVG</span>
    `;
    const svgInput = document.createElement('input');
    svgInput.type = 'file';
    svgInput.accept = '.svg,image/svg+xml';
    svgInput.style.display = 'none';
    svgInput.addEventListener('change', () => {
      if (svgInput.files && svgInput.files.length > 0) {
        handleImportedFiles(svgInput.files, 'svg');
        const popover = document.getElementById('addTrackPopover');
        const fab = document.getElementById('fabAddTrack');
        if (popover) popover.classList.remove('active');
        if (fab) fab.classList.remove('active');
      }
    });
    btnImportSvg.appendChild(svgInput);
    btnImportSvg.addEventListener('click', (e) => {
      e.stopPropagation();
      svgInput.click();
    });
    grid.appendChild(btnImportSvg);

    return;
  }

  if (catKey === 'media') {
    grid.className = 'popover-items-grid media-shelf-grid';

    const allMedia = getGlobalMediaLibrary();
    let filteredList = [];
    let acceptTypes = 'image/*,video/*,audio/*';
    let emptyTitle = 'Media Masih Kosong';
    let emptySub = 'Klik Import atau drag & drop file ke sini untuk mengumpulkan media Anda';
    let emptyIcon = 'cloud_upload';

    if (currentMediaTabFilter === 'video') {
      filteredList = allMedia.filter(m => (m.type && m.type.startsWith('video')) || (m.name && /\.(mp4|webm|mov|mkv)$/i.test(m.name)));
      acceptTypes = 'video/*,.mp4,.webm,.mov,.mkv';
      emptyTitle = 'Media Video Masih Kosong';
      emptySub = 'Klik Import atau drag & drop file video (.mp4, .webm) ke sini';
      emptyIcon = 'movie';
    } else if (currentMediaTabFilter === 'audio') {
      filteredList = allMedia.filter(m => (m.type && m.type.startsWith('audio')) || (m.name && /\.(mp3|wav|aac|m4a|ogg|flac)$/i.test(m.name)));
      acceptTypes = 'audio/*,.mp3,.wav,.aac,.m4a,.ogg,.flac';
      emptyTitle = 'Media Audio Masih Kosong';
      emptySub = 'Klik Import atau drag & drop file musik (.mp3, .wav) ke sini';
      emptyIcon = 'audiotrack';
    } else {
      // 'foto'
      filteredList = allMedia.filter(m => !(m.type && m.type.startsWith('audio')) && !(m.name && /\.(mp3|wav|aac|m4a|ogg|flac)$/i.test(m.name)) && !(m.type && m.type.startsWith('video')) && !(m.name && /\.(mp4|webm|mov|mkv)$/i.test(m.name)));
      acceptTypes = 'image/*,.png,.jpg,.jpeg,.svg,.gif,.webp';
      emptyTitle = 'Media Foto Masih Kosong';
      emptySub = 'Klik Import atau drag & drop file foto ke sini';
      emptyIcon = 'add_photo_alternate';
    }

    // 1. Top Media Pool Header Strip: "Import" button + [Foto, Video, Audio] filter pills
    const headerStrip = document.createElement('div');
    headerStrip.className = 'media-pool-header-strip';
    headerStrip.innerHTML = `
      <input type="file" id="mediaPoolFileInput" accept="image/*,video/*,audio/*,.png,.jpg,.jpeg,.svg,.gif,.webp,.mp4,.webm,.mov,.mkv,.mp3,.wav,.aac,.m4a,.ogg,.flac" multiple style="display:none;">
      <button type="button" class="media-pool-import-btn" id="btnMediaPoolImport" title="Import Foto, Video, atau Audio">
        <span class="material-symbols-rounded" style="font-size:18px;">add</span>
        Import
      </button>
      <div class="media-filter-pills">
        <button type="button" class="media-filter-pill ${currentMediaTabFilter === 'foto' ? 'active' : ''}" data-filter="foto">Foto</button>
        <button type="button" class="media-filter-pill ${currentMediaTabFilter === 'video' ? 'active' : ''}" data-filter="video">Video</button>
        <button type="button" class="media-filter-pill ${currentMediaTabFilter === 'audio' ? 'active' : ''}" data-filter="audio">Audio</button>
      </div>
    `;

    const poolFileInput = headerStrip.querySelector('#mediaPoolFileInput');
    const btnImport = headerStrip.querySelector('#btnMediaPoolImport');
    const filterPills = headerStrip.querySelectorAll('.media-filter-pill');

    if (btnImport && poolFileInput) {
      btnImport.addEventListener('click', (e) => {
        e.stopPropagation();
        poolFileInput.click();
      });
      poolFileInput.addEventListener('change', () => {
        if (poolFileInput.files && poolFileInput.files.length > 0) {
          handleImportedFiles(poolFileInput.files);
        }
      });
    }

    filterPills.forEach(pill => {
      pill.addEventListener('click', (e) => {
        e.stopPropagation();
        currentMediaTabFilter = pill.dataset.filter || 'foto';
        renderCategoryItems('media');
      });
    });

    grid.appendChild(headerStrip);

    // 2. Main Gallery
    if (currentMediaTabFilter === 'audio') {
      const listCol = document.createElement('div');
      listCol.style.display = 'flex';
      listCol.style.flexDirection = 'column';
      listCol.style.gap = '8px';
      listCol.style.width = '100%';
      listCol.style.overflowY = 'auto';
      listCol.style.maxHeight = '180px';
      listCol.style.padding = '4px 0';

      if (!filteredList || filteredList.length === 0) {
        const emptyHint = document.createElement('div');
        emptyHint.style.cssText = 'color: var(--col-cream, #FAB778); font-size: 0.8rem; padding: 20px 10px; text-align: center; opacity: 0.75; font-weight: 600;';
        emptyHint.textContent = 'Belum ada file audio. Klik "Import" di atas untuk menambahkan musik.';
        listCol.appendChild(emptyHint);
      } else {
        filteredList.forEach(item => {
          const card = document.createElement('div');
          card.className = 'audio-shelf-card';
          card.innerHTML = `
            <div class="audio-shelf-icon">
              <span class="material-symbols-rounded">audiotrack</span>
            </div>
            <div class="audio-shelf-info">
              <span class="audio-shelf-title">${item.name}</span>
              <span class="audio-shelf-sub">Audio Clip \u2022 Klik untuk menambahkan ke timeline</span>
            </div>
          `;
          card.addEventListener('click', (e) => {
            e.stopPropagation();
            addTrackWithType('audio', item.name, item.url);
            const popover = document.getElementById('addTrackPopover');
            const fab = document.getElementById('fabAddTrack');
            if (popover) popover.classList.remove('active');
            if (fab) fab.classList.remove('active');
          });
          listCol.appendChild(card);
        });
      }

      grid.appendChild(listCol);
    } else {
      const itemsRow = document.createElement('div');
      itemsRow.className = 'media-shelf-items-row';

      if (!filteredList || filteredList.length === 0) {
        const emptyHint = document.createElement('div');
        emptyHint.style.cssText = 'color: var(--col-cream, #FAB778); font-size: 0.8rem; padding: 20px 10px; text-align: center; opacity: 0.75; font-weight: 600; width: 100%;';
        emptyHint.textContent = (currentMediaTabFilter === 'video')
          ? 'Belum ada file video. Klik "Import" di atas untuk menambahkan video.'
          : 'Belum ada file foto. Klik "Import" di atas untuk menambahkan foto.';
        itemsRow.appendChild(emptyHint);
      } else {
        filteredList.forEach(item => {
          const thumb = createMediaThumbnailElement(item, (mediaItem) => {
            const isVideoItem = (mediaItem.type && mediaItem.type.startsWith('video')) || (mediaItem.name && /\.(mp4|webm|mov|mkv)$/i.test(mediaItem.name));
            let finalMediaUrl = mediaItem.url;
            if (!isVideoItem && !finalMediaUrl && mediaItem.blob) {
              finalMediaUrl = URL.createObjectURL(mediaItem.blob);
              mediaItem.url = finalMediaUrl;
            }
            const trackUrl = isVideoItem ? (mediaItem.id || mediaItem.url) : (finalMediaUrl || mediaItem.id);
            addTrackWithType(isVideoItem ? 'video' : 'media', mediaItem.name, trackUrl);
            const popover = document.getElementById('addTrackPopover');
            const fab = document.getElementById('fabAddTrack');
            if (popover) popover.classList.remove('active');
            if (fab) fab.classList.remove('active');
          });
          itemsRow.appendChild(thumb);
        });
      }

      grid.appendChild(itemsRow);
    }
    return;
  }

  const items = CATEGORY_ITEMS[catKey] || CATEGORY_ITEMS.text;
  items.forEach(item => {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'shelf-item-card';
    card.innerHTML = `
      <span class="material-symbols-rounded insp-tile-icon">${item.icon}</span>
      <span class="insp-tile-label">${item.name}</span>
    `;

    card.addEventListener('click', (e) => {
      e.stopPropagation();
      addTrackWithType(item.cat || catKey, item.filename, null, (item.cat === 'null' || item.name.toLowerCase().includes('null')) ? 'null' : null);
      const popover = document.getElementById('addTrackPopover');
      const fab = document.getElementById('fabAddTrack');
      if (popover) popover.classList.remove('active');
      if (fab) fab.classList.remove('active');
    });

    grid.appendChild(card);
  });
}

function ensureVideoConvertModal() {
  let modal = document.getElementById('videoConvertModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'videoConvertModal';
    modal.className = 'video-convert-modal';
    modal.innerHTML = `
      <div class="video-convert-box">
        <div class="convert-icon-wrap">
          <span class="material-symbols-rounded">autorenew</span>
        </div>
        <div class="convert-title">Mengonversi Video ke Frame Sequence</div>
        <div class="convert-sub" id="convertProgressText">Mempersiapkan ekstraksi frame...</div>
        <div class="convert-progress-track">
          <div class="convert-progress-fill" id="convertProgressFill" style="width: 0%;"></div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }
  return modal;
}

function showVideoConvertProgress(pct, text) {
  const modal = ensureVideoConvertModal();
  modal.classList.add('active');
  const fill = document.getElementById('convertProgressFill');
  const txt = document.getElementById('convertProgressText');
  if (fill) fill.style.width = `${Math.max(0, Math.min(100, pct))}%`;
  if (txt) txt.textContent = text || `Mengekstrak frame... (${Math.round(pct)}%)`;
}

function hideVideoConvertProgress() {
  const modal = document.getElementById('videoConvertModal');
  if (modal) modal.classList.remove('active');
}

async function convertVideoToFrameSequence(file, onProgress) {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.src = objectUrl;
    video.crossOrigin = 'anonymous';
    video.muted = true;
    video.playsInline = true;
    video.preload = 'auto';

    video.onloadedmetadata = async () => {
      const duration = (video.duration && isFinite(video.duration)) ? video.duration : 5;
      const targetFps = 30;
      const totalFrames = Math.max(1, Math.round(duration * targetFps));
      const stepSec = 1 / targetFps;

      const rawW = video.videoWidth || 1280;
      const rawH = video.videoHeight || 720;
      const aspect = (rawW && rawH) ? (rawW / rawH) : 1.7778;

      const maxDim = 1280;
      let drawW = rawW;
      let drawH = rawH;
      if (drawW > maxDim || drawH > maxDim) {
        if (drawW >= drawH) {
          drawW = maxDim;
          drawH = Math.round(maxDim / aspect);
        } else {
          drawH = maxDim;
          drawW = Math.round(maxDim * aspect);
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = drawW;
      canvas.height = drawH;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      const bitmaps = [];
      const frameBlobs = [];

      for (let i = 0; i < totalFrames; i++) {
        const time = i * stepSec;
        await new Promise((seekDone) => {
          const onSeek = () => {
            video.removeEventListener('seeked', onSeek);
            seekDone();
          };
          video.addEventListener('seeked', onSeek);
          video.currentTime = Math.min(duration, Math.max(0, time));
        });

        ctx.drawImage(video, 0, 0, drawW, drawH);

        const fCanvas = document.createElement('canvas');
        fCanvas.width = drawW;
        fCanvas.height = drawH;
        fCanvas.getContext('2d').drawImage(canvas, 0, 0);
        bitmaps.push(fCanvas);

        await new Promise(r => {
          canvas.toBlob(blob => {
            if (blob) frameBlobs.push(blob);
            r();
          }, 'image/jpeg', 0.85);
        });

        const pct = Math.round(((i + 1) / totalFrames) * 100);
        if (onProgress) {
          onProgress(pct, i + 1, totalFrames);
        }
      }

      const thumbDataUrl = canvas.toDataURL('image/jpeg', 0.85);

      resolve({
        fps: targetFps,
        duration: duration,
        aspectRatio: aspect,
        frames: bitmaps,
        frameBlobs: frameBlobs,
        width: drawW,
        height: drawH,
        totalFrames: totalFrames,
        thumbnailUrl: thumbDataUrl,
        audioBlob: file,
        audioUrl: objectUrl,
        isReady: true
      });
    };

    video.onerror = (err) => {
      reject(err);
    };

    video.load();
  });
}

async function handleImportedFiles(fileList, forceCat) {
  if (!fileList || fileList.length === 0) return;

  let lastDetectedTab = null;

  for (const file of Array.from(fileList)) {
    const mime = file.type ? file.type.toLowerCase() : '';
    const name = file.name ? file.name.toLowerCase() : '';

    let cat = 'media';
    let fileMime = file.type;

    if (mime === 'image/svg+xml' || /\.svg$/i.test(name) || forceCat === 'svg') {
      cat = 'svg';
      fileMime = 'image/svg+xml';
      lastDetectedTab = 'foto';
    } else if (mime.startsWith('video/') || /\.(mp4|webm|mov|mkv|avi|m4v|3gp)$/i.test(name)) {
      cat = 'video';
      fileMime = fileMime || 'video/mp4';
      lastDetectedTab = 'video';
    } else if (mime.startsWith('audio/') || /\.(mp3|wav|aac|m4a|ogg|flac|wma|opus)$/i.test(name)) {
      cat = 'audio';
      fileMime = fileMime || 'audio/mp3';
      lastDetectedTab = 'audio';
    } else {
      cat = 'media';
      fileMime = fileMime || 'image/png';
      if (!lastDetectedTab) lastDetectedTab = 'foto';
    }

    if (cat === 'svg') {
      const reader = new FileReader();
      reader.onload = () => {
        const svgText = reader.result;
        const mediaId = 'media_svg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
        const dataUrl = 'data:image/svg+xml;utf8,' + encodeURIComponent(svgText);

        let parsedPoints = [];
        try {
          const parser = new DOMParser();
          const doc = parser.parseFromString(svgText, 'image/svg+xml');
          const poly = doc.querySelector('polygon, polyline');
          if (poly) {
            const rawPts = (poly.getAttribute('points') || '').trim().split(/[\s,]+/);
            for (let i = 0; i < rawPts.length - 1; i += 2) {
              const px = (parseFloat(rawPts[i]) || 0) - 50;
              const py = 50 - (parseFloat(rawPts[i + 1]) || 0);
              parsedPoints.push({ x: px, y: py });
            }
          }
        } catch (_) {}

        if (parsedPoints.length < 2) {
          parsedPoints = [{ x: -50, y: -50 }, { x: 50, y: -50 }, { x: 50, y: 50 }, { x: -50, y: 50 }];
        }

        const newRow = addTrackWithType('shape', file.name, null, 'svg_path');
        if (newRow) {
          const layerId = newRow.dataset.layerId;
          const p = getLayerShapeParams(layerId, 'svg_path');
          p.points = parsedPoints;
          p.svgContent = svgText;
          p.renderMode = 'fill';
          applyFillToMeshGlobal(layerId);
        }

        if (typeof addGlobalMedia === 'function') {
          addGlobalMedia(dataUrl, file.name, 'image/svg+xml', file);
        }
      };
      reader.readAsText(file);
      continue;
    }

    if (cat === 'video') {
      const mediaId = 'media_vid_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
      const liveUrl = URL.createObjectURL(file);

      const tempVid = document.createElement('video');
      tempVid.src = liveUrl;
      tempVid.crossOrigin = 'anonymous';
      tempVid.muted = true;
      tempVid.playsInline = true;
      tempVid.preload = 'auto';

      tempVid.onloadeddata = () => {
        const rawW = tempVid.videoWidth || 1280;
        const rawH = tempVid.videoHeight || 720;
        const aspect = (rawW && rawH) ? (rawW / rawH) : 1.7778;

        let thumbUrl = '';
        try {
          const thumbCanvas = document.createElement('canvas');
          thumbCanvas.width = 240;
          thumbCanvas.height = Math.max(60, Math.round(240 / aspect));
          const ctx = thumbCanvas.getContext('2d');
          ctx.drawImage(tempVid, 0, 0, thumbCanvas.width, thumbCanvas.height);
          thumbUrl = thumbCanvas.toDataURL('image/jpeg', 0.8);
        } catch(_) {}

        const mediaItem = {
          id: mediaId,
          name: file.name,
          type: fileMime || 'video/mp4',
          url: liveUrl,
          thumbnailUrl: thumbUrl,
          blob: file,
          duration: (tempVid.duration && isFinite(tempVid.duration)) ? tempVid.duration : 5,
          aspectRatio: aspect,
          width: rawW,
          height: rawH,
          createdAt: Date.now()
        };

        const list = getGlobalMediaLibrary();
        list.unshift(mediaItem);
        saveGlobalMediaLibrary(list);
        if (typeof saveMediaBinaryToIDB === 'function') saveMediaBinaryToIDB(mediaItem);

        mediaNaturalRatioMap.set(mediaId, aspect);
        mediaNaturalRatioMap.set(liveUrl, aspect);
        mediaNaturalRatioMap.set(file.name, aspect);

        currentMediaTabFilter = 'video';
        if (typeof syncAllMediaGrids === 'function') syncAllMediaGrids();
        if (typeof renderCategoryItems === 'function') renderCategoryItems('media');
      };
      continue;
    }

    if (cat === 'audio') {
      const objectUrl = URL.createObjectURL(file);
      if (typeof addGlobalMedia === 'function') {
        addGlobalMedia(objectUrl, file.name, fileMime, file);
      }
      continue;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const img = new Image();
      img.onload = () => {
        const aspect = (img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : 1.0;
        mediaNaturalRatioMap.set(dataUrl, aspect);
      };
      img.src = dataUrl;
      if (typeof addGlobalMedia === 'function') {
        addGlobalMedia(dataUrl, file.name, fileMime, file);
      }
    };
    reader.readAsDataURL(file);
  }

  if (lastDetectedTab) {
    currentMediaTabFilter = lastDetectedTab;
    setTimeout(() => {
      renderCategoryItems('media');
    }, 120);
  }
}

function addTrackWithType(category, customName, mediaUrl, shapeType, extraData) {
  const container = document.getElementById('trackRowsContainer');
  const viewport = document.getElementById('tracksViewport');
  if (!container) return null;

  let trackName = customName;
  if (!trackName) {
    if (category === 'shape') trackName = 'Shape_Kotak.svg';
    else if (category === 'null' || shapeType === 'null') trackName = 'Null_1';
    else if (category === 'media') trackName = 'Media_Photo.png';
    else if (category === 'video') trackName = 'Video_Clip.mp4';
    else if (category === 'audio') trackName = 'Audio_Track.mp3';
    else if (category === 'camera') trackName = 'Camera_1';
    else if (category === 'text') trackName = (extraData && extraData.content) ? extraData.content : 'Heading_Title.txt';
    else trackName = 'New_Layer.png';
  }

  const widths = [360, 440, 520, 300, 480];
  const w = widths[Math.floor(Math.random() * widths.length)];
  const m = Math.max(0, timelineOffset);

  const isAudio = (category === 'audio');
  const defaultEyeIcon = isAudio ? 'volume_up' : 'visibility';

  const row = document.createElement('div');
  row.className = 'track-row adding';
  row.dataset.category = category || 'custom';
  if (shapeType) {
    row.dataset.shapeType = shapeType;
  }
  row.innerHTML = `
    <button class="track-eye" title="${isAudio ? 'Mute / Unmute Audio' : 'Toggle Visibility'} / Tahan untuk Multi-Select">
      <span class="material-symbols-rounded">${isMultiSelectMode ? 'radio_button_unchecked' : defaultEyeIcon}</span>
    </button>
    <div class="track-trackway" style="transform: translateX(-${timelineOffset}px);">
      <div class="track-clip" style="width: ${w}px; margin-left: ${m}px;" title="Klik untuk pilih / buka menu layer">
        <div class="clip-extend-handle handle-left" title="Tarik untuk memanjangkan awal layer">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </div>
        <span class="track-clip-name">${trackName}</span>
        <div class="clip-extend-handle handle-right" title="Tarik untuk memanjangkan akhir layer">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
      </div>
    </div>
    <button class="track-reorder-handle" title="Tahan & geser untuk atur urutan layer (Reorder)">
      <span class="material-symbols-rounded">menu</span>
    </button>
  `;

  bindTrackEvents(row);
  setTimeout(() => row.classList.remove('adding'), 300);

  const id = row.dataset.layerId;

  if (category === 'text' && id) {
    const tData = (typeof getLayerText === 'function') ? getLayerText(id) : null;
    if (tData) {
      if (extraData && extraData.content) {
        tData.content = extraData.content;
        tData.font = extraData.font || 'Poppins';
        tData.size = extraData.size || 48;
        tData.bold = extraData.bold !== undefined ? extraData.bold : true;
        tData.uppercase = !!extraData.uppercase;
      }
      if (tData.font && typeof loadGoogleFont === 'function') {
        loadGoogleFont(tData.font);
      }
    }
  }

  if (mediaUrl && id) {
    const fill = getLayerFill(id);
    fill.type = 'media';
    fill.mediaUrl = mediaUrl;
    fill.color = null;
    fill.gradientType = null;

    if (mediaUrl && (mediaUrl.startsWith('video_pkg_') || mediaUrl.startsWith('pkg_') || videoFrameSequenceMap.has(mediaUrl))) {
      const seq = videoFrameSequenceMap.get(mediaUrl);
      const isStillConverting = !seq || !seq.isReady;
      if (isStillConverting) {
        const clipEl = row.querySelector('.track-clip');
        if (clipEl) {
          const pFill = document.createElement('div');
          pFill.className = 'track-clip-progress-fill';
          pFill.setAttribute('data-clip-progress-for', mediaUrl);
          const curPct = seq && seq.progress ? seq.progress : 0;
          pFill.style.width = `${curPct}%`;
          clipEl.appendChild(pFill);

          const pText = document.createElement('span');
          pText.className = 'track-clip-status-text';
          pText.setAttribute('data-clip-text-for', mediaUrl);
          pText.textContent = `${curPct}%`;
          clipEl.appendChild(pText);
        }
      }
      if (seq) {
        if (seq.aspectRatio) {
          mediaNaturalRatioMap.set(id, seq.aspectRatio);
          mediaNaturalRatioMap.set(mediaUrl, seq.aspectRatio);
          fill.aspectRatio = seq.aspectRatio;
        }
        if (seq.duration && isFinite(seq.duration)) {
          const targetWidth = Math.max(80, Math.round(seq.duration * PX_PER_SEC));
          const clipEl = row.querySelector('.track-clip');
          if (clipEl) clipEl.style.width = `${targetWidth}px`;
          calculateMaxDuration();
          rebuildTimeRuler(totalDuration);
        }
      }
      applyFillToMeshGlobal(id);
      applyTransformToThreeMesh(id, getLayerTransform(id));
      renderCanvasOverlay();
    } else if (isAudio) {
      const audio = new Audio(mediaUrl);
      audio.preload = 'auto';
      layerAudioMap.set(id, audio);
      audio.onloadedmetadata = () => {
        if (audio.duration && isFinite(audio.duration)) {
          const targetWidth = Math.max(80, Math.round(audio.duration * PX_PER_SEC));
          const clipEl = row.querySelector('.track-clip');
          if (clipEl) clipEl.style.width = `${targetWidth}px`;
          calculateMaxDuration();
          rebuildTimeRuler(totalDuration);
        }
      };
    } else if (category === 'video' || /\.(mp4|webm|mov|mkv|ogg|avi)$/i.test(mediaUrl) || mediaUrl.startsWith('data:video/')) {
      const vid = document.createElement('video');
      vid.src = mediaUrl;
      vid.crossOrigin = 'anonymous';
      vid.preload = 'auto';
      layerVideoMap.set(id, vid);
      vid.onloadedmetadata = () => {
        const aspect = (vid.videoWidth && vid.videoHeight) ? (vid.videoWidth / vid.videoHeight) : 1.0;
        mediaNaturalRatioMap.set(id, aspect);
        mediaNaturalRatioMap.set(mediaUrl, aspect);
        fill.aspectRatio = aspect;
        if (vid.duration && isFinite(vid.duration)) {
          const targetWidth = Math.max(80, Math.round(vid.duration * PX_PER_SEC));
          const clipEl = row.querySelector('.track-clip');
          if (clipEl) clipEl.style.width = `${targetWidth}px`;
          calculateMaxDuration();
          rebuildTimeRuler(totalDuration);
        }
        renderCanvasOverlay();
      };
    } else {
      const img = new Image();
      img.onload = () => {
        const aspect = (img.naturalWidth && img.naturalHeight) ? (img.naturalWidth / img.naturalHeight) : 1.0;
        mediaNaturalRatioMap.set(id, aspect);
        mediaNaturalRatioMap.set(mediaUrl, aspect);
        fill.aspectRatio = aspect;
        applyFillToMeshGlobal(id);
        applyTransformToThreeMesh(id, getLayerTransform(id));
        renderCanvasOverlay();
        render3D();
      };
      img.src = mediaUrl;
      applyFillToMeshGlobal(id);
    }
  }

  container.prepend(row);
  if (viewport) viewport.scrollTop = 0;

  setTimeout(() => {
    row.classList.remove('adding');
  }, 340);

  calculateMaxDuration();

  recordAction({
    type: 'ADD_TRACK',
    element: row
  });

  syncThreeLayers();
  renderCanvasOverlay();

  return row;
}

function addTrack() {
  return addTrackWithType('media', 'Media_Clip.mp4');
}

// ══════════════════════════════════════════════════════════════
// ══════════════════════════════════════════════════════════════
// DETERMINISTIC OFFLINE HD VIDEO MUXER (ZERO LAG & 100% SMOOTH FPS)
// ══════════════════════════════════════════════════════════════

const WhammyVideo = (function() {
  function numToBytes(num, bytesCount) {
    const bytes = [];
    for (let i = bytesCount - 1; i >= 0; i--) {
      bytes.push((num >> (i * 8)) & 0xff);
    }
    return new Uint8Array(bytes);
  }

  function numToVarInt(num) {
    let len = 1;
    while (num >= (1 << (7 * len)) - 1 && len < 8) len++;
    const res = new Uint8Array(len);
    let val = num | (1 << (7 * len));
    for (let i = len - 1; i >= 0; i--) {
      res[i] = val & 0xff;
      val >>= 8;
    }
    return res;
  }

  function ebmlElement(id, data) {
    let idBytes;
    if (typeof id === 'number') {
      if (id <= 0xff) idBytes = new Uint8Array([id]);
      else if (id <= 0xffff) idBytes = new Uint8Array([id >> 8, id & 0xff]);
      else if (id <= 0xffffff) idBytes = new Uint8Array([id >> 16, (id >> 8) & 0xff, id & 0xff]);
      else idBytes = new Uint8Array([id >> 24, (id >> 16) & 0xff, (id >> 8) & 0xff, id & 0xff]);
    } else {
      idBytes = id;
    }

    let payload;
    if (typeof data === 'string') {
      payload = new TextEncoder().encode(data);
    } else if (data instanceof Uint8Array) {
      payload = data;
    } else if (Array.isArray(data)) {
      let totalLen = 0;
      for (let i = 0; i < data.length; i++) totalLen += data[i].length;
      payload = new Uint8Array(totalLen);
      let off = 0;
      for (let i = 0; i < data.length; i++) {
        payload.set(data[i], off);
        off += data[i].length;
      }
    } else {
      payload = new Uint8Array(0);
    }

    const sizeBytes = numToVarInt(payload.length);
    const res = new Uint8Array(idBytes.length + sizeBytes.length + payload.length);
    res.set(idBytes, 0);
    res.set(sizeBytes, idBytes.length);
    res.set(payload, idBytes.length + sizeBytes.length);
    return res;
  }

  function parseWebPToVP8(dataUrl) {
    try {
      const binStr = atob(dataUrl.split(',')[1]);
      const len = binStr.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) bytes[i] = binStr.charCodeAt(i);

      if (bytes[0] === 82 && bytes[1] === 73 && bytes[2] === 70 && bytes[3] === 70) {
        let offset = 12;
        while (offset < len - 8) {
          const fourCC = String.fromCharCode(bytes[offset], bytes[offset+1], bytes[offset+2], bytes[offset+3]);
          const chunkSize = bytes[offset+4] | (bytes[offset+5] << 8) | (bytes[offset+6] << 16) | (bytes[offset+7] << 24);
          if (fourCC === 'VP8 ') {
            return bytes.subarray(offset + 8, offset + 8 + chunkSize);
          }
          offset += 8 + chunkSize + (chunkSize % 2);
        }
      }
    } catch(e) {}
    return null;
  }

  function toWebM(frames, width, height, fps) {
    const frameDurationMs = 1000 / fps;
    const totalDurationMs = frames.length * frameDurationMs;

    const ebmlHeader = ebmlElement(0x1a45dfa3, [
      ebmlElement(0x4286, new Uint8Array([1])),
      ebmlElement(0x42f7, new Uint8Array([1])),
      ebmlElement(0x42f2, new Uint8Array([4])),
      ebmlElement(0x42f3, new Uint8Array([8])),
      ebmlElement(0x4282, "webm"),
      ebmlElement(0x4287, new Uint8Array([2])),
      ebmlElement(0x4285, new Uint8Array([2]))
    ]);

    const timecodeScale = 1000000;
    const segmentInfo = ebmlElement(0x1549a966, [
      ebmlElement(0x2ad7b1, numToBytes(timecodeScale, 4)),
      ebmlElement(0x4d80, "FishToolStudio"),
      ebmlElement(0x5741, "FishToolStudio"),
      (function() {
        const buf = new ArrayBuffer(8);
        new DataView(buf).setFloat64(0, totalDurationMs, false);
        return ebmlElement(0x4489, new Uint8Array(buf));
      })()
    ]);

    const videoTrack = ebmlElement(0xae, [
      ebmlElement(0xd7, new Uint8Array([1])),
      ebmlElement(0x73c5, new Uint8Array([1])),
      ebmlElement(0x83, new Uint8Array([1])),
      ebmlElement(0x86, "V_VP8"),
      ebmlElement(0xe0, [
        ebmlElement(0xb0, numToBytes(width, 2)),
        ebmlElement(0xba, numToBytes(height, 2))
      ])
    ]);
    const tracks = ebmlElement(0x1654ae6b, [videoTrack]);

    const clusters = [];
    const framesPerCluster = Math.max(1, Math.round(fps * 2));

    for (let c = 0; c < frames.length; c += framesPerCluster) {
      const clusterTimecode = Math.round(c * frameDurationMs);
      const clusterElements = [
        ebmlElement(0xe7, numToBytes(clusterTimecode, 4))
      ];

      const end = Math.min(frames.length, c + framesPerCluster);
      for (let f = c; f < end; f++) {
        const frameData = frames[f];
        const relTimecode = Math.round((f * frameDurationMs) - clusterTimecode);

        const blockHeader = new Uint8Array([
          0x81,
          (relTimecode >> 8) & 0xff,
          relTimecode & 0xff,
          0x80
        ]);

        const block = new Uint8Array(blockHeader.length + frameData.length);
        block.set(blockHeader, 0);
        block.set(frameData, blockHeader.length);

        clusterElements.push(ebmlElement(0xa3, block));
      }

      clusters.push(ebmlElement(0x1f43b675, clusterElements));
    }

    const segment = ebmlElement(0x18538067, [segmentInfo, tracks, ...clusters]);
    return new Blob([ebmlHeader, segment], { type: 'video/webm' });
  }

  return {
    parseWebPToVP8: parseWebPToVP8,
    toWebM: toWebM
  };
})();

// Fast Three.js Scene Evaluator for Offline Render (Runs in <0.2ms per frame, avoids all DOM lag)
function updateThreeSceneForExport(time) {
  const curTime = time !== undefined ? time : elapsed;
  applyActiveCameraPerspective(curTime);
  const rows = document.querySelectorAll('.track-row');
  rows.forEach((row, idx) => {
    const id = row.dataset.layerId;
    if (!id) return;

    const clip = row.querySelector('.track-clip');
    const eye = row.querySelector('.track-eye');
    const isHidden = eye && eye.querySelector('.material-symbols-rounded') && eye.querySelector('.material-symbols-rounded').textContent.trim() === 'visibility_off';

    const cat = row.dataset.category || 'media';
    const clipName = row.querySelector('.track-clip-name')?.textContent || '';
    const isVirtual = (cat === 'camera' || cat === 'null' || clipName.toLowerCase().startsWith('camera') || clipName.toLowerCase().startsWith('null'));

    const startSec = clip ? (parseFloat(clip.style.marginLeft) || 0) / PX_PER_SEC : 0;
    const durSec = clip ? (parseFloat(clip.style.width) || 300) / PX_PER_SEC : 5;
    const endSec = startSec + durSec;
    const isVisibleNow = !isVirtual && !isHidden && curTime >= startSec && curTime <= endSec;

    let mesh = meshLayerMap.get(id);
    if (mesh) {
      mesh.visible = isVisibleNow;
      if (isVisibleNow) {
        const wt = getLayerWorldTransform(id, new Set(), curTime);
        const order = rows.length - idx;
        const zEpsilon = order * 0.0001;

        applyTransformToThreeMesh(id, wt);

        if (mesh.material) {
          const fill = layerFills.get(id);
          let fillAlpha = 1;
          if (fill && fill.type === 'color') {
            const parsed = parseHexOrRgb(fill.color || '#FAB778');
            fillAlpha = (fill.alpha !== undefined) ? fill.alpha : (parsed.a !== undefined ? parsed.a : 1);
          }
          mesh.material.opacity = Math.max(0, Math.min(1, (wt.opacity / 100) * fillAlpha));
          mesh.material.needsUpdate = true;
        }
      }
    }
  });
}

// ══════════════════════════════════════════════════════════════
// IN-EDITOR LIVE PREVIEW HD FRAME-BY-FRAME VIDEO EXPORT ENGINE
// ══════════════════════════════════════════════════════════════
let exportFormat = 'h264';
let exportRes = 'source';
let exportFps = 'source';
let exportBitrate = 16;
let isExportRendering = false;
let exportCancelRequested = false;
let exportVideoBlob = null;
let exportVideoUrl = null;

function openMediaEncoder() {
  pausePlayback();
  saveCurrentProject();

  const modal = document.getElementById('exportModal');
  if (!modal) return;

  const durSec = calculateMaxDuration();
  const nameEl = document.getElementById('exportProjName');
  const durEl = document.getElementById('exportProjDuration');
  const titleInput = document.getElementById('activeTitle');
  if (nameEl && titleInput) nameEl.textContent = titleInput.textContent.trim() || 'My Project';
  if (durEl) {
    const m = Math.floor(durSec / 60);
    const s = Math.floor(durSec % 60);
    durEl.textContent = '00:' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }

  const progressBox = document.getElementById('exportProgressBox');
  const fill = document.getElementById('exportProgressFill');
  const pct = document.getElementById('lblExportPct');
  const status = document.getElementById('lblExportStatus');
  const btnRender = document.getElementById('btnStartExportRender');
  const btnDownload = document.getElementById('btnDownloadExportVideo');

  if (progressBox) progressBox.style.display = 'none';
  if (fill) fill.style.width = '0%';
  if (pct) pct.textContent = '0%';
  if (status) status.textContent = 'Ready to render';
  if (btnRender) {
    btnRender.textContent = 'RENDER VIDEO';
    btnRender.style.background = '#D06423';
  }
  if (btnDownload) btnDownload.style.display = 'none';

  modal.classList.add('active');
}

function closeExportModal() {
  const modal = document.getElementById('exportModal');
  if (modal) modal.classList.remove('active');
  if (isExportRendering) {
    exportCancelRequested = true;
  }
}

async function startLivePreviewRender() {
  if (!renderer3D || !scene3D || !camera3D) {
    alert('3D Canvas renderer belum siap.');
    return;
  }

  isExportRendering = true;
  exportCancelRequested = false;

  const btnRender = document.getElementById('btnStartExportRender');
  const btnDownload = document.getElementById('btnDownloadExportVideo');
  const progressBox = document.getElementById('exportProgressBox');
  const fill = document.getElementById('exportProgressFill');
  const pct = document.getElementById('lblExportPct');
  const status = document.getElementById('lblExportStatus');

  if (progressBox) progressBox.style.display = 'flex';
  if (btnRender) {
    btnRender.textContent = 'CANCEL';
    btnRender.style.background = '#B71C1C';
  }
  if (btnDownload) btnDownload.style.display = 'none';

  // 1. Calculate Exact HD Export Resolution (1080p / 4K / 720p)
  let exportW = 1920, exportH = 1080;
  const resKey = exportRes === 'source' ? (projectResolution || '1080p') : exportRes;
  const ratioKey = projectRatio || '16:9';

  if (resKey.toLowerCase().includes('4k')) {
    exportW = 3840; exportH = 2160;
  } else if (resKey.toLowerCase().includes('720')) {
    exportW = 1280; exportH = 720;
  } else {
    exportW = 1920; exportH = 1080;
  }

  if (ratioKey === '9:16') {
    const tmp = exportW; exportW = exportH; exportH = tmp;
  } else if (ratioKey === '1:1') {
    const minDim = Math.min(exportW, exportH);
    exportW = minDim; exportH = minDim;
  } else if (ratioKey === '4:5') {
    exportW = 1080; exportH = 1350;
  } else if (ratioKey === '4:3') {
    exportW = 1440; exportH = 1080;
  }

  // 2. Determine Duration & FPS
  const durSec = calculateMaxDuration();
  const fps = exportFps === 'source' ? (Number(projectFps) || 30) : Number(exportFps);
  const totalFrames = Math.max(1, Math.ceil(durSec * fps));

  const originalOffset = timelineOffset;

  // Save current preview container dimensions
  const container = document.getElementById('canvasVideo');
  const previewW = container ? (container.clientWidth || 360) : 360;
  const previewH = container ? (container.clientHeight || 640) : 640;

  // Temporarily scale WebGL renderer to FULL HD / 4K resolution
  renderer3D.setSize(exportW, exportH, false);
  renderer3D.setPixelRatio(1);
  camera3D.aspect = exportW / exportH;
  camera3D.updateProjectionMatrix();

  // Create 2D Canvas for High-Quality Frame Capture
  const captureCanvas = document.createElement('canvas');
  captureCanvas.width = exportW;
  captureCanvas.height = exportH;
  const captureCtx = captureCanvas.getContext('2d');

  // 3. Fast Deterministic Frame-By-Frame Render Loop with MP4 Muxer
  let isMp4Supported = typeof VideoEncoder !== 'undefined' && typeof Mp4Muxer !== 'undefined';
  let mp4Muxer = null;
  let videoEncoder = null;
  const frameDurationUs = Math.round(1_000_000 / fps);

  if (isMp4Supported && exportFormat !== 'vp9') {
    try {
      mp4Muxer = new Mp4Muxer.Muxer({
        target: new Mp4Muxer.ArrayBufferTarget(),
        video: {
          codec: 'avc',
          width: exportW,
          height: exportH
        },
        firstTimestampBehavior: 'offset',
        fastStart: 'in-memory'
      });

      let isFirstChunk = true;
      let lastTimestampUs = 0;

      videoEncoder = new VideoEncoder({
        output: (chunk, meta) => {
          let ts;
          if (isFirstChunk) {
            isFirstChunk = false;
            ts = 0;
            lastTimestampUs = 0;
          } else {
            ts = (typeof chunk.timestamp === 'number' && !isNaN(chunk.timestamp) && chunk.timestamp >= 0)
              ? chunk.timestamp
              : (lastTimestampUs + frameDurationUs);
            if (ts <= lastTimestampUs) {
              ts = lastTimestampUs + frameDurationUs;
            }
            lastTimestampUs = ts;
          }

          const dur = (chunk.duration !== null && chunk.duration !== undefined && !isNaN(chunk.duration) && chunk.duration > 0)
            ? chunk.duration
            : frameDurationUs;

          mp4Muxer.addVideoChunk(chunk, meta, ts, dur);
        },
        error: (e) => console.error('VideoEncoder error:', e)
      });

      // avc1.42001f = H.264 Baseline Profile Level 3.1 (Strictly monotonic timestamps, no B-frame reordering)
      videoEncoder.configure({
        codec: 'avc1.42001f',
        width: exportW,
        height: exportH,
        bitrate: Math.max(12_000_000, exportBitrate * 1_000_000),
        framerate: fps,
        latencyMode: 'realtime',
        avc: { format: 'avc' }
      });
    } catch(e) {
      console.warn('Native VideoEncoder init failed, falling back to WebM:', e);
      isMp4Supported = false;
      mp4Muxer = null;
      videoEncoder = null;
    }
  }

  const vp8Frames = [];

  for (let frame = 0; frame < totalFrames; frame++) {
    if (exportCancelRequested) {
      if (status) status.textContent = 'Render dibatalkan';
      if (btnRender) {
        btnRender.textContent = 'RENDER VIDEO';
        btnRender.style.background = '#D06423';
      }
      isExportRendering = false;

      // Restore preview dimensions
      camera3D.aspect = previewW / previewH;
      camera3D.updateProjectionMatrix();
      renderer3D.setSize(previewW, previewH);
      renderer3D.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      setTimelineOffset(originalOffset);
      return;
    }

    const frameTime = frame / fps;
    const hasAnyMotionBlur = isGlobalMotionBlurEnabled && Array.from(layerMotionBlur.values()).some(v => v === true);

    if (hasAnyMotionBlur) {
      captureCtx.clearRect(0, 0, exportW, exportH);
      if (projectBgColor !== 'transparent') {
        captureCtx.fillStyle = projectBgColor;
        captureCtx.fillRect(0, 0, exportW, exportH);
      }
      const samples = projectMotionBlurSamples || 6;
      const tune = projectMotionBlurTune || 0.5;
      const shutterDt = (tune / fps);

      for (let s = 0; s < samples; s++) {
        const sNorm = (samples > 1) ? (s / (samples - 1)) - 0.5 : 0;
        const subTime = Math.max(0, Math.min(totalDuration, frameTime + sNorm * shutterDt));
        updateThreeSceneForExport(subTime);
        renderer3D.setClearColor(0x000000, 0.0);
        renderer3D.render(scene3D, camera3D);
        captureCtx.globalAlpha = 1.0 / (s + 1);
        captureCtx.drawImage(renderer3D.domElement, 0, 0, exportW, exportH);
      }
      captureCtx.globalAlpha = 1.0;
    } else {
      // Fast scene update without DOM overhead
      updateThreeSceneForExport(frameTime);

      // Render WebGL frame
      renderer3D.render(scene3D, camera3D);

      // Blit to capture canvas
      captureCtx.drawImage(renderer3D.domElement, 0, 0, exportW, exportH);
    }

    if (isMp4Supported && videoEncoder) {
      // Direct WebCodecs GPU encoding for real MP4 with explicit duration
      const videoFrame = new VideoFrame(captureCanvas, {
        timestamp: Math.round((frame / fps) * 1_000_000),
        duration: frameDurationUs
      });
      videoEncoder.encode(videoFrame, { keyFrame: frame % Math.max(1, Math.round(fps * 2)) === 0 });
      videoFrame.close();
    } else {
      // Deterministic WebM fallback
      const dataUrl = captureCanvas.toDataURL('image/webp', 0.95);
      const vp8Chunk = WhammyVideo.parseWebPToVP8(dataUrl);
      if (vp8Chunk) vp8Frames.push(vp8Chunk);
    }

    // Update Progress UI every frame smoothly
    const curPct = Math.round(((frame + 1) / totalFrames) * 100);
    if (fill) fill.style.width = curPct + '%';
    if (pct) pct.textContent = curPct + '%';
    if (status) status.textContent = `Rendering frame ${frame + 1} / ${totalFrames} (${exportW}x${exportH} @ ${fps}fps)`;

    // Yield to browser event loop so UI stays completely fluid & responsive
    await new Promise(r => requestAnimationFrame(r));
  }

  if (status) status.textContent = 'Compiling smooth 60fps MP4 video...';

  if (isMp4Supported && videoEncoder && mp4Muxer) {
    await videoEncoder.flush();
    mp4Muxer.finalize();
    exportVideoBlob = new Blob([mp4Muxer.target.buffer], { type: 'video/mp4' });
    exportVideoUrl = URL.createObjectURL(exportVideoBlob);
  } else if (vp8Frames.length === totalFrames) {
    exportVideoBlob = WhammyVideo.toWebM(vp8Frames, exportW, exportH, fps);
    exportVideoUrl = URL.createObjectURL(exportVideoBlob);
  } else {
    // MediaRecorder Fallback
    const stream = captureCanvas.captureStream(0);
    const videoTrack = stream.getVideoTracks()[0];
    const chunks = [];
    const mime = MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : 'video/webm;codecs=vp9';
    const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 30000000 });
    recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.start();
    for (let f = 0; f < totalFrames; f++) {
      updateThreeSceneForExport(f / fps);
      renderer3D.render(scene3D, camera3D);
      captureCtx.drawImage(renderer3D.domElement, 0, 0, exportW, exportH);
      if (videoTrack) videoTrack.requestFrame();
      await new Promise(r => setTimeout(r, 1000 / fps));
    }
    await new Promise(r => {
      recorder.onstop = () => {
        exportVideoBlob = new Blob(chunks, { type: mime });
        exportVideoUrl = URL.createObjectURL(exportVideoBlob);
        r();
      };
      recorder.stop();
    });
  }

  isExportRendering = false;
  if (btnRender) {
    btnRender.textContent = 'RE-RENDER';
    btnRender.style.background = '#D06423';
  }
  const isMp4 = exportVideoBlob && exportVideoBlob.type.includes('mp4');
  if (status) status.textContent = `HD ${isMp4 ? 'MP4' : 'WebM'} Video Siap! (${exportW}x${exportH}, ${durSec}s, ${fps}fps)`;
  if (btnDownload) {
    btnDownload.style.display = 'inline-flex';
  }

  // Restore preview dimensions and aspect ratio
  camera3D.aspect = previewW / previewH;
  camera3D.updateProjectionMatrix();
  renderer3D.setSize(previewW, previewH);
  renderer3D.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  setTimelineOffset(originalOffset);
}
