function initExportModalEvents() {
  const btnClose = document.getElementById('btnCloseExportModal');
  if (btnClose) btnClose.addEventListener('click', closeExportModal);

  const modal = document.getElementById('exportModal');
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeExportModal();
    });
  }

  function initModalDropdown(triggerId, menuId, onSelect) {
    const trigger = document.getElementById(triggerId);
    const menu = document.getElementById(menuId);
    const wrap = trigger ? trigger.closest('.am-custom-select') : null;
    if (!trigger || !menu) return;

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      document.querySelectorAll('#exportModal .am-custom-select').forEach(w => {
        if (w !== wrap) w.classList.remove('is-open');
      });
      document.querySelectorAll('#exportModal .am-custom-dropdown-menu').forEach(m => {
        if (m !== menu) m.classList.remove('active');
      });
      if (wrap) wrap.classList.toggle('is-open');
      menu.classList.toggle('active');
    });

    menu.querySelectorAll('.am-dropdown-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.querySelectorAll('.am-dropdown-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        const valSpan = trigger.querySelector('.am-trigger-val');
        if (valSpan) valSpan.textContent = item.textContent.trim();
        if (wrap) wrap.classList.remove('is-open');
        menu.classList.remove('active');
        onSelect(item.dataset.value || item.textContent.trim());
      });
    });
  }

  initModalDropdown('triggerExportFormat', 'menuExportFormat', (val) => { exportFormat = val; });
  initModalDropdown('triggerExportRes', 'menuExportRes', (val) => { exportRes = val; });
  initModalDropdown('triggerExportFps', 'menuExportFps', (val) => { exportFps = val; });

  const sliderBitrate = document.getElementById('sliderExportBitrate');
  const lblBitrate = document.getElementById('lblExportBitrateVal');
  if (sliderBitrate && lblBitrate) {
    sliderBitrate.addEventListener('input', () => {
      exportBitrate = Number(sliderBitrate.value) || 16;
      lblBitrate.textContent = exportBitrate + ' Mbps';
    });
  }

  const btnStartRender = document.getElementById('btnStartExportRender');
  if (btnStartRender) {
    btnStartRender.addEventListener('click', () => {
      if (isExportRendering) {
        exportCancelRequested = true;
      } else {
        startLivePreviewRender();
      }
    });
  }

  const btnDownload = document.getElementById('btnDownloadExportVideo');
  if (btnDownload) {
    btnDownload.addEventListener('click', () => {
      if (!exportVideoUrl || !exportVideoBlob) return;
      const titleInput = document.getElementById('activeTitle');
      const projName = (titleInput && titleInput.textContent.trim()) || 'My_Project';
      const cleanName = projName.replace(/[^a-zA-Z0-9_-]/g, '_');
      const isMp4 = exportVideoBlob.type.includes('mp4');
      const ext = isMp4 ? 'mp4' : 'webm';
      const a = document.createElement('a');
      a.href = exportVideoUrl;
      a.download = cleanName + '_HD.' + ext;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });
  }
}

function initProjectSettingsModal() {
  const btnSettings = document.getElementById('btnProjectSettings');
  const modal = document.getElementById('projectSettingsModal');
  const btnClose = document.getElementById('btnProjSettingsClose');
  const btnSave = document.getElementById('btnProjSettingsSave');
  const lblDim = document.getElementById('lblEditCompositionSize');

  const resDropdownWrap = document.getElementById('wrapEditSelectResolution');
  const resCustomWrap = document.getElementById('editResCustomWrap');
  const customResW = document.getElementById('editCustomResW');
  const customResH = document.getElementById('editCustomResH');
  const btnLinkAspect = document.getElementById('editBtnLinkAspect');
  const bgSwatchBox = document.getElementById('editBgSwatchBox');

  let selectedResValue = projectResolution || '1080p';
  let selectedFpsValue = String(projectFps) || '30';
  let selectedBgValue = projectBgColor || '#000000';
  let selectedMotionBlurTune = projectMotionBlurTune || 1.0;
  let selectedMotionBlurSamples = projectMotionBlurSamples || 6;

  function closeAllDropdowns() {
    document.querySelectorAll('.am-custom-select').forEach(cs => cs.classList.remove('is-open'));
  }

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.am-custom-select')) {
      closeAllDropdowns();
    }
  });

  function setupCustomDropdown(wrapId, triggerId, valId, menuId, onSelect) {
    const wrap = document.getElementById(wrapId);
    const trigger = document.getElementById(triggerId);
    const valSpan = document.getElementById(valId);
    const menu = document.getElementById(menuId);
    if (!wrap || !trigger || !menu) return;

    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = wrap.classList.contains('is-open');
      closeAllDropdowns();
      if (!isOpen) wrap.classList.add('is-open');
    });

    menu.querySelectorAll('.am-dropdown-item').forEach(item => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.querySelectorAll('.am-dropdown-item').forEach(i => i.classList.remove('selected'));
        item.classList.add('selected');
        if (valSpan) {
          const textSpan = item.querySelector('span:not(.am-item-swatch)') || item;
          valSpan.textContent = textSpan.textContent.trim();
        }
        wrap.classList.remove('is-open');
        if (onSelect) onSelect(item.dataset.value, item);
      });
    });
  }

  setupCustomDropdown('wrapEditSelectResolution', 'triggerEditResolution', 'valEditResolution', 'menuEditResolution', (val) => {
    selectedResValue = val;
    updateDimensionLabel();
  });

  setupCustomDropdown('wrapEditSelectFps', 'triggerEditFps', 'valEditFps', 'menuEditFps', (val) => {
    selectedFpsValue = val;
  });

  setupCustomDropdown('wrapEditSelectBackground', 'triggerEditBackground', 'valEditBackground', 'menuEditBackground', (val) => {
    selectedBgValue = val;
    if (bgSwatchBox) {
      bgSwatchBox.style.background = val === 'transparent' ? '#ffffff' : val;
    }
  });

  setupCustomDropdown('wrapEditSelectMotionBlur', 'triggerEditMotionBlur', 'valEditMotionBlur', 'menuEditMotionBlur', (val, item) => {
    selectedMotionBlurTune = parseFloat(item.dataset.tune || val) || 1.0;
    selectedMotionBlurSamples = parseInt(item.dataset.samples) || 10;
  });

  setupCustomDropdown('wrapCodecFormat', 'triggerCodecFormat', 'valCodecFormat', 'menuCodecFormat');
  setupCustomDropdown('wrapCodecRes', 'triggerCodecRes', 'valCodecRes', 'menuCodecRes');
  setupCustomDropdown('wrapCodecFrameRate', 'triggerCodecFrameRate', 'valCodecFrameRate', 'menuCodecFrameRate');

  function updateDimensionLabel() {
    if (!lblDim) return;
    const selectedBox = document.querySelector('#editRatioSelector .am-ratio-box.selected');
    const ratio = selectedBox ? selectedBox.dataset.ratio : projectRatio;
    
    if (ratio === 'custom') {
      const w = parseInt(customResW?.value) || projectCustomWidth || 1080;
      const h = parseInt(customResH?.value) || projectCustomHeight || 1080;
      lblDim.innerHTML = `${w} &times; ${h}`;
      return;
    }

    let baseW = 1080, baseH = 1920;
    if (ratio === '16:9') { baseW = 1920; baseH = 1080; }
    else if (ratio === '9:16') { baseW = 1080; baseH = 1920; }
    else if (ratio === '4:5') { baseW = 1080; baseH = 1350; }
    else if (ratio === '1:1') { baseW = 1080; baseH = 1080; }
    else if (ratio === '4:3') { baseW = 1440; baseH = 1080; }

    if (selectedResValue === '720p') {
      baseW = Math.round(baseW * (720 / 1080));
      baseH = Math.round(baseH * (720 / 1080));
    } else if (selectedResValue === '4K') {
      baseW = Math.round(baseW * 2);
      baseH = Math.round(baseH * 2);
    }
    lblDim.innerHTML = `${baseW} &times; ${baseH}`;
  }

  if (btnSettings && modal) {
    btnSettings.addEventListener('click', () => {
      document.querySelectorAll('#editRatioSelector .am-ratio-box').forEach(box => {
        box.classList.toggle('selected', box.dataset.ratio === projectRatio);
      });

      if (customResW) customResW.value = projectCustomWidth || 1080;
      if (customResH) customResH.value = projectCustomHeight || 1080;

      if (projectRatio === 'custom') {
        if (resDropdownWrap) resDropdownWrap.style.display = 'none';
        if (resCustomWrap) resCustomWrap.style.display = 'flex';
      } else {
        if (resDropdownWrap) resDropdownWrap.style.display = 'flex';
        if (resCustomWrap) resCustomWrap.style.display = 'none';
      }

      selectedResValue = projectResolution || '1080p';
      selectedFpsValue = String(projectFps) || '30';
      selectedBgValue = projectBgColor || '#000000';

      const resItem = document.querySelector(`#menuEditResolution .am-dropdown-item[data-value="${selectedResValue}"]`);
      if (resItem) {
        document.querySelectorAll('#menuEditResolution .am-dropdown-item').forEach(i => i.classList.remove('selected'));
        resItem.classList.add('selected');
        const valSpan = document.getElementById('valEditResolution');
        if (valSpan) valSpan.textContent = resItem.textContent.trim();
      }

      const fpsItem = document.querySelector(`#menuEditFps .am-dropdown-item[data-value="${selectedFpsValue}"]`);
      if (fpsItem) {
        document.querySelectorAll('#menuEditFps .am-dropdown-item').forEach(i => i.classList.remove('selected'));
        fpsItem.classList.add('selected');
        const valSpan = document.getElementById('valEditFps');
        if (valSpan) valSpan.textContent = fpsItem.textContent.trim();
      }

      const bgItem = document.querySelector(`#menuEditBackground .am-dropdown-item[data-value="${selectedBgValue}"]`);
      if (bgItem) {
        document.querySelectorAll('#menuEditBackground .am-dropdown-item').forEach(i => i.classList.remove('selected'));
        bgItem.classList.add('selected');
        const valSpan = document.getElementById('valEditBackground');
        if (valSpan) {
          const textSpan = bgItem.querySelector('span:not(.am-item-swatch)') || bgItem;
          valSpan.textContent = textSpan.textContent.trim();
        }
      }

      if (bgSwatchBox) {
        bgSwatchBox.style.background = selectedBgValue === 'transparent' ? '#ffffff' : selectedBgValue;
      }

      selectedMotionBlurTune = projectMotionBlurTune !== undefined ? projectMotionBlurTune : 1.0;
      selectedMotionBlurSamples = projectMotionBlurSamples || 10;
      let mbItem = document.querySelector(`#menuEditMotionBlur .am-dropdown-item[data-tune="${selectedMotionBlurTune}"]`) || document.querySelector(`#menuEditMotionBlur .am-dropdown-item[data-value="${selectedMotionBlurTune}"]`);
      if (!mbItem) {
        mbItem = document.querySelector('#menuEditMotionBlur .am-dropdown-item[data-value="1.0"]') || document.querySelector('#menuEditMotionBlur .am-dropdown-item');
      }
      if (mbItem) {
        document.querySelectorAll('#menuEditMotionBlur .am-dropdown-item').forEach(i => i.classList.remove('selected'));
        mbItem.classList.add('selected');
        const valSpan = document.getElementById('valEditMotionBlur');
        if (valSpan) valSpan.textContent = mbItem.textContent.trim();
      }

      updateDimensionLabel();
      modal.classList.add('active');
    });
  }

  function closeModal() {
    if (modal) modal.classList.remove('active');
    closeAllDropdowns();
  }

  if (btnClose) btnClose.addEventListener('click', closeModal);
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });
  }

  document.querySelectorAll('#editRatioSelector .am-ratio-box').forEach(box => {
    box.addEventListener('click', () => {
      document.querySelectorAll('#editRatioSelector .am-ratio-box').forEach(b => b.classList.remove('selected'));
      box.classList.add('selected');
      
      const ratio = box.dataset.ratio;
      if (ratio === 'custom') {
        if (resDropdownWrap) resDropdownWrap.style.display = 'none';
        if (resCustomWrap) resCustomWrap.style.display = 'flex';
      } else {
        if (resDropdownWrap) resDropdownWrap.style.display = 'flex';
        if (resCustomWrap) resCustomWrap.style.display = 'none';
      }
      updateDimensionLabel();
    });
  });

  if (btnLinkAspect) {
    btnLinkAspect.addEventListener('click', () => {
      btnLinkAspect.classList.toggle('active');
    });
  }

  if (customResW && customResH) {
    let prevW = parseInt(customResW.value) || 1080;
    let prevH = parseInt(customResH.value) || 1080;

    customResW.addEventListener('input', () => {
      const curW = parseInt(customResW.value) || 1080;
      if (btnLinkAspect && btnLinkAspect.classList.contains('active') && prevW > 0) {
        const aspect = prevH / prevW;
        customResH.value = Math.round(curW * aspect);
      }
      prevW = curW;
      prevH = parseInt(customResH.value) || 1080;
      updateDimensionLabel();
    });

    customResH.addEventListener('input', () => {
      const curH = parseInt(customResH.value) || 1080;
      if (btnLinkAspect && btnLinkAspect.classList.contains('active') && prevH > 0) {
        const aspect = prevW / prevH;
        customResW.value = Math.round(curH * aspect);
      }
      prevH = curH;
      prevW = parseInt(customResW.value) || 1080;
      updateDimensionLabel();
    });
  }

  if (btnSave) {
    btnSave.addEventListener('click', () => {
      const titleSpan = document.getElementById('activeTitle');
      const activeName = (titleSpan && titleSpan.textContent.trim()) || sessionStorage.getItem('activeProject') || 'Proyek Baru';

      const selectedRatio = document.querySelector('#editRatioSelector .am-ratio-box.selected')?.dataset.ratio || projectRatio;
      const customW = parseInt(customResW?.value) || 1080;
      const customH = parseInt(customResH?.value) || 1080;

      applyProjectConfig({
        name: activeName,
        ratio: selectedRatio,
        resolution: selectedRatio === 'custom' ? `${customW}x${customH}` : selectedResValue,
        customWidth: customW,
        customHeight: customH,
        fps: selectedFpsValue,
        backgroundColor: selectedBgValue,
        motionBlurTune: selectedMotionBlurTune,
        motionBlurSamples: selectedMotionBlurSamples
      });

      saveCurrentProject();
      closeModal();
    });
  }
}
