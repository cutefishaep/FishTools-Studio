function initTimelineZoomAndPreventWebZoom() {
  // A. Disable browser / webpage zoom via Ctrl + Wheel and Touchpad Pinch
  window.addEventListener('wheel', (e) => {
    if (e.ctrlKey) {
      e.preventDefault();
      // If the cursor is inside timeline area, zoom timeline instead
      const isOverTimeline = e.target.closest('#timelineRuler, #timeRulerMarks, .timeline-panel, .timeline-track-area, #timelineTracks, .track-row');
      if (isOverTimeline) {
        const zoomFactor = e.deltaY < 0 ? 1.12 : (1 / 1.12);
        zoomTimeline(zoomFactor);
      }
    }
  }, { passive: false });

  window.addEventListener('gesturestart', (e) => e.preventDefault(), { passive: false });
  window.addEventListener('gesturechange', (e) => e.preventDefault(), { passive: false });
  window.addEventListener('gestureend', (e) => e.preventDefault(), { passive: false });

  // B. PC Scroll on Timeline Top Ruler to Stretch / Zoom Timeline
  const ruler = document.getElementById('timelineRuler') || document.getElementById('timeRulerMarks');
  if (ruler) {
    ruler.addEventListener('wheel', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const zoomFactor = e.deltaY < 0 ? 1.15 : (1 / 1.15);
      zoomTimeline(zoomFactor);
    }, { passive: false });
  }

  // C. Touchpad / Touch Pinch on Timeline Track Container
  const timelinePanel = document.querySelector('.timeline-panel') || document.querySelector('.timeline-track-area') || document.getElementById('timelineTracks');
  if (timelinePanel) {
    let initialTouchDistance = null;

    timelinePanel.addEventListener('touchstart', (e) => {
      if (e.touches && e.touches.length === 2) {
        initialTouchDistance = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
      }
    }, { passive: true });

    timelinePanel.addEventListener('touchmove', (e) => {
      if (e.touches && e.touches.length === 2 && initialTouchDistance !== null) {
        e.preventDefault();
        const currentDist = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        const ratio = currentDist / initialTouchDistance;
        if (Math.abs(ratio - 1.0) > 0.04) {
          zoomTimeline(ratio > 1 ? 1.06 : 0.94);
          initialTouchDistance = currentDist;
        }
      }
    }, { passive: false });

    timelinePanel.addEventListener('touchend', (e) => {
      if (!e.touches || e.touches.length < 2) {
        initialTouchDistance = null;
      }
    }, { passive: true });
  }
}


document.addEventListener('DOMContentLoaded', () => {
  initTimelineZoomAndPreventWebZoom();
  // Disable default browser contextmenu across app so custom right click works seamlessly
  window.addEventListener('contextmenu', (e) => {
    e.preventDefault();
  });

  document.addEventListener('dragstart', (e) => e.preventDefault());
  document.addEventListener('selectstart', (e) => {
    if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
      e.preventDefault();
    }
  });

  const title = sessionStorage.getItem('activeProject') || 'My Project';
  const titleEl = document.getElementById('activeTitle');
  if (titleEl) {
    titleEl.textContent = title;
    
    titleEl.addEventListener('input', () => {
      const newTitle = titleEl.textContent.trim() || 'My Project';
      sessionStorage.setItem('activeProject', newTitle);
      triggerAutoSave();
    });

    titleEl.addEventListener('blur', () => {
      if (!titleEl.textContent.trim()) {
        titleEl.textContent = 'My Project';
        sessionStorage.setItem('activeProject', 'My Project');
      }
      triggerAutoSave();
    });

    titleEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        titleEl.blur();
      }
    });
  }

  const topLayerNameEl = document.getElementById('topInspLayerName');
  if (topLayerNameEl) {
    topLayerNameEl.addEventListener('input', () => {
      if (selectedTrackRow) {
        const clipName = selectedTrackRow.querySelector('.track-clip-name');
        const newName = topLayerNameEl.textContent.trim() || 'Layer';
        if (clipName) {
          clipName.textContent = newName;
        }
        triggerAutoSave();
      }
    });

    topLayerNameEl.addEventListener('blur', () => {
      if (selectedTrackRow) {
        const clipName = selectedTrackRow.querySelector('.track-clip-name');
        if (!topLayerNameEl.textContent.trim()) {
          const fallback = selectedTrackRow.dataset.category ? (selectedTrackRow.dataset.category.charAt(0).toUpperCase() + selectedTrackRow.dataset.category.slice(1) + ' Layer') : 'Layer';
          topLayerNameEl.textContent = fallback;
          if (clipName) clipName.textContent = fallback;
        }
        triggerAutoSave();
      }
    });

    topLayerNameEl.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        topLayerNameEl.blur();
      }
    });
  }

  try {
    const rawCfg = sessionStorage.getItem('projectConfig');
    if (rawCfg) {
      const cfg = JSON.parse(rawCfg);
      applyProjectConfig(cfg);
    }
  } catch (e) {
    console.warn('Could not parse project config', e);
  }

  const btnBack = document.querySelector('.btn-back');
  if (btnBack) btnBack.addEventListener('click', goBack);

  document.querySelectorAll('.btn-play-main').forEach(btn => {
    btn.addEventListener('click', togglePlayPause);
  });

  document.querySelectorAll('[title="Skip ke awal"], [title="Skip Previous"]').forEach(btn => {
    btn.addEventListener('click', skipPrevious);
  });

  document.querySelectorAll('[title="Skip ke akhir"], [title="Skip Next"]').forEach(btn => {
    btn.addEventListener('click', skipNext);
  });

  document.querySelectorAll('[title="Bookmark"]').forEach(btn => {
    btn.addEventListener('click', toggleMarkerAtCurrent);
  });

  document.querySelectorAll('[title="Undo"]').forEach(btn => {
    btn.addEventListener('click', undo);
  });

  document.querySelectorAll('[title="Redo"]').forEach(btn => {
    btn.addEventListener('click', redo);
  });

  const btnExport = document.querySelector('.btn-export');
  if (btnExport) btnExport.addEventListener('click', openMediaEncoder);

  const fabAdd = document.getElementById('fabAddTrack') || document.querySelector('.fab-add');
  const addTrackPopover = document.getElementById('addTrackPopover');
  const btnAddTrackClose = document.getElementById('btnAddTrackClose');

  if (fabAdd && addTrackPopover) {
    renderCategoryItems('shape');

    fabAdd.addEventListener('click', (e) => {
      e.stopPropagation();
      const isActive = addTrackPopover.classList.toggle('active');
      fabAdd.classList.toggle('active', isActive);
    });

    if (btnAddTrackClose) {
      btnAddTrackClose.addEventListener('click', (e) => {
        e.stopPropagation();
        addTrackPopover.classList.remove('active');
        fabAdd.classList.remove('active');
      });
    }

    document.querySelectorAll('.cat-tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        document.querySelectorAll('.cat-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const cat = btn.getAttribute('data-cat') || 'shape';
        renderCategoryItems(cat);
      });
    });

    document.addEventListener('click', (e) => {
      if (!addTrackPopover.contains(e.target) && !fabAdd.contains(e.target)) {
        addTrackPopover.classList.remove('active');
        fabAdd.classList.remove('active');
      }
    });
  }

  // Layer Link Popover (topBtnInspLink)
  const btnTopLink = document.getElementById('topBtnInspLink');
  if (btnTopLink) {
    btnTopLink.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const currentTrackId = selectedTrackRow.dataset.layerId;
      if (!currentTrackId) return;

      const project = getProjectFromDOM();
      const currentTrack = project.tracks.find(t => t.id === currentTrackId) || {
        id: currentTrackId,
        linkedTo: selectedTrackRow.dataset.linkedTo ? JSON.parse(selectedTrackRow.dataset.linkedTo) : []
      };

      const linkedParentId = (currentTrack.linkedTo && currentTrack.linkedTo[0]) || (selectedTrackRow.dataset.linkedTo ? JSON.parse(selectedTrackRow.dataset.linkedTo)[0] : null);

      // Render Popover DOM
      const card = document.createElement('div');
      card.className = 'fish-link-popover-card';

      const list = document.createElement('div');
      list.className = 'fish-link-list';

      // List all layers in exact timeline order
      const rows = document.querySelectorAll('.track-row');
      rows.forEach(r => {
        const trId = r.dataset.layerId;
        if (!trId) return;

        const isCurrent = (trId === currentTrackId);
        const isLinked = (linkedParentId === trId);

        const clip = r.querySelector('.track-clip');
        const trName = clip?.querySelector('.track-clip-name')?.textContent || r.dataset.category || `Layer ${trId}`;

        const item = document.createElement('div');
        item.className = 'fish-link-item' + (isCurrent ? ' disabled' : '') + (isLinked ? ' active' : '');

        item.innerHTML = `
          <span class="fish-link-name">${trName}</span>
          ${isLinked ? '<span class="material-symbols-rounded fish-link-check">check</span>' : ''}
        `;

        if (!isCurrent) {
          item.addEventListener('click', (ev) => {
            ev.stopPropagation();
            if (isLinked) {
              // Toggle off / Unlink
              const childWorld = getLayerWorldTransform(currentTrackId);
              const childT = getLayerTransform(currentTrackId);
              childT.posX = Math.round(childWorld.posX * 100) / 100;
              childT.posY = Math.round(childWorld.posY * 100) / 100;
              childT.posZ = Math.round(childWorld.posZ * 100) / 100;
              childT.rotX = Math.round(childWorld.rotX * 100) / 100;
              childT.rotY = Math.round(childWorld.rotY * 100) / 100;
              childT.rotZ = Math.round(childWorld.rotZ * 100) / 100;
              childT.scaleW = Math.round(childWorld.scaleW * 100) / 100;
              childT.scaleH = Math.round(childWorld.scaleH * 100) / 100;

              currentTrack.linkedTo = [];
              delete selectedTrackRow.dataset.linkedTo;
              delete selectedTrackRow.dataset.parentBind;
              saveProjectToDOM(project);
              triggerAutoSave();

              btnTopLink.classList.remove('active');
              applyTransformToThreeMesh(currentTrackId, getLayerTransform(currentTrackId));
              syncControllerUI();
              render3D();
              requestCanvasOverlayRender();
            } else {
              // Link to target layer with bind pose
              const parentWorld = getLayerWorldTransform(trId);
              const childWorld = getLayerWorldTransform(currentTrackId);

              const childT = getLayerTransform(currentTrackId);
              childT.posX = Math.round(childWorld.posX * 100) / 100;
              childT.posY = Math.round(childWorld.posY * 100) / 100;
              childT.posZ = Math.round(childWorld.posZ * 100) / 100;
              childT.rotX = Math.round(childWorld.rotX * 100) / 100;
              childT.rotY = Math.round(childWorld.rotY * 100) / 100;
              childT.rotZ = Math.round(childWorld.rotZ * 100) / 100;
              childT.scaleW = Math.round(childWorld.scaleW * 100) / 100;
              childT.scaleH = Math.round(childWorld.scaleH * 100) / 100;

              const bindPose = {
                posX: Math.round(parentWorld.posX * 100) / 100,
                posY: Math.round(parentWorld.posY * 100) / 100,
                posZ: Math.round(parentWorld.posZ * 100) / 100,
                rotX: Math.round(parentWorld.rotX * 100) / 100,
                rotY: Math.round(parentWorld.rotY * 100) / 100,
                rotZ: Math.round(parentWorld.rotZ * 100) / 100,
                scaleW: Math.round(parentWorld.scaleW * 100) / 100,
                scaleH: Math.round(parentWorld.scaleH * 100) / 100
              };

              currentTrack.linkedTo = [trId];
              selectedTrackRow.dataset.linkedTo = JSON.stringify([trId]);
              selectedTrackRow.dataset.parentBind = JSON.stringify(bindPose);
              saveProjectToDOM(project);
              triggerAutoSave();

              btnTopLink.classList.add('active');
              applyTransformToThreeMesh(currentTrackId, childT);
              syncControllerUI();
              render3D();
              requestCanvasOverlayRender();
            }
            if (window.FishPopover) window.FishPopover.close();
          });
        }

        list.appendChild(item);
      });

      card.appendChild(list);

      // Show via Universal FishPopover
      if (window.FishPopover) {
        window.FishPopover.show({
          anchorElement: btnTopLink,
          content: card,
          className: 'fish-link-popover-wrapper',
          onClose: null
        });
      }
    });
  }

// Top Context Bar Buttons
  const btnTopBack = document.getElementById('topBtnInspBack');
  if (btnTopBack) {
    btnTopBack.addEventListener('click', (e) => {
      e.stopPropagation();
      deselectTrack();
    });
  }

  const btnTopDelete = document.getElementById('topBtnInspDelete');
  if (btnTopDelete) {
    btnTopDelete.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteSelectedTrack();
    });
  }

  const btnTopMotionBlur = document.getElementById('topBtnInspMotionBlur');
  if (btnTopMotionBlur) {
    btnTopMotionBlur.addEventListener('click', (e) => {
      e.stopPropagation();
      if (!selectedTrackRow) return;
      const id = selectedTrackRow.dataset.layerId;
      const cur = !!layerMotionBlur.get(id);
      layerMotionBlur.set(id, !cur);
      btnTopMotionBlur.classList.toggle('active', !cur);
      btnTopMotionBlur.title = !cur ? 'Motion Blur: ON' : 'Motion Blur: OFF';
      render3D();
      triggerAutoSave();
    });
  }

  const btnGlobalMbD = document.getElementById('btnToggleGlobalMotionBlurDesktop');
  if (btnGlobalMbD) {
    btnGlobalMbD.addEventListener('click', (e) => {
      e.stopPropagation();
      isGlobalMotionBlurEnabled = !isGlobalMotionBlurEnabled;
      btnGlobalMbD.classList.toggle('active', isGlobalMotionBlurEnabled);
      const btnM = document.getElementById('btnToggleGlobalMotionBlurMobile');
      if (btnM) btnM.classList.toggle('active', isGlobalMotionBlurEnabled);
      render3D();
      triggerAutoSave();
    });
  }

  const btnGlobalMbM = document.getElementById('btnToggleGlobalMotionBlurMobile');
  if (btnGlobalMbM) {
    btnGlobalMbM.addEventListener('click', (e) => {
      e.stopPropagation();
      isGlobalMotionBlurEnabled = !isGlobalMotionBlurEnabled;
      btnGlobalMbM.classList.toggle('active', isGlobalMotionBlurEnabled);
      const btnD = document.getElementById('btnToggleGlobalMotionBlurDesktop');
      if (btnD) btnD.classList.toggle('active', isGlobalMotionBlurEnabled);
      render3D();
      triggerAutoSave();
    });
  }

  const btnTopMore = document.getElementById('topBtnInspMore');
  const layerOptionsPopup = document.getElementById('layerOptionsPopup');
  if (btnTopMore && layerOptionsPopup) {
    btnTopMore.addEventListener('click', (e) => {
      e.stopPropagation();
      if (layerOptionsPopup.classList.contains('active')) {
        layerOptionsPopup.classList.remove('active');
        return;
      }

      // Reset all items to visible
      layerOptionsPopup.querySelectorAll('.pop-menu-item').forEach(item => {
        item.style.display = 'block';
        item.style.opacity = '1';
        item.style.pointerEvents = 'auto';
      });
      layerOptionsPopup.querySelectorAll('.pop-menu-divider').forEach(div => div.style.display = 'block');
      const colorSection = document.getElementById('popMenuColorSection');
      if (colorSection) {
        colorSection.style.display = 'flex';
        colorSection.classList.remove('hidden');
      }

      const pasteBtn = document.getElementById('popMenuPasteBtn');
      if (pasteBtn) {
        pasteBtn.style.opacity = clipboardLayerData ? '1' : '0.45';
        pasteBtn.style.pointerEvents = clipboardLayerData ? 'auto' : 'none';
      }

      const rect = btnTopMore.getBoundingClientRect();
      const popupW = 195;
      const left = Math.max(10, Math.min(window.innerWidth - popupW - 12, rect.right - popupW));
      const top = rect.bottom + 8;
      layerOptionsPopup.style.left = left + 'px';
      layerOptionsPopup.style.top = top + 'px';

      layerOptionsPopup.classList.add('active');
    });
  }

  document.addEventListener('click', (e) => {
    if (layerOptionsPopup && !layerOptionsPopup.contains(e.target) && e.target !== btnTopMore) {
      layerOptionsPopup.classList.remove('active');
    }
  });

  const timelinePanel = document.getElementById('timelinePanel');
  if (timelinePanel) {
    timelinePanel.addEventListener('contextmenu', (e) => {
      const r = e.target.closest('.track-row');
      openLayerContextMenu(e, r || null);
    });

    timelinePanel.addEventListener('dragover', (e) => {
      e.preventDefault();
      timelinePanel.classList.add('drag-over');
    });
    timelinePanel.addEventListener('dragleave', (e) => {
      e.preventDefault();
      timelinePanel.classList.remove('drag-over');
    });
    timelinePanel.addEventListener('drop', (e) => {
      e.preventDefault();
      timelinePanel.classList.remove('drag-over');
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        handleImportedFiles(e.dataTransfer.files);
      }
    });
  }

  const tracksViewport = document.getElementById('tracksViewport');
  if (tracksViewport) {
    tracksViewport.addEventListener('contextmenu', (e) => {
      const r = e.target.closest('.track-row');
      openLayerContextMenu(e, r || null);
    });
  }

  const previewStage = document.getElementById('previewStage');
  if (previewStage) {
    previewStage.addEventListener('contextmenu', (e) => {
      openLayerContextMenu(e, selectedTrackRow || null);
    });

    let prevDownPos = { x: 0, y: 0 };
    let prevDownTime = 0;
    previewStage.addEventListener('mousedown', (e) => {
      if (e.button !== 0) return;
      if (e.target.closest('button, .top-nav, .mobile-editor-controls, #layerInspectorDrawer, #layerTopContextBar, #layerOptionsPopup')) return;
      prevDownPos = { x: e.pageX, y: e.pageY };
      prevDownTime = performance.now();
    });

    previewStage.addEventListener('mouseup', (e) => {
      if (e.button !== 0) return;
      if (e.target.closest('button, .top-nav, .mobile-editor-controls, #layerInspectorDrawer, #layerTopContextBar, #layerOptionsPopup')) return;
      const dx = Math.abs(e.pageX - prevDownPos.x);
      const dy = Math.abs(e.pageY - prevDownPos.y);

      // Single tap on preview background to deselect
      if (dx < 6 && dy < 6) {
        if (selectedTrackRow && !e.target.closest('.transform-handle, .rot-handle, .corner-handle, .edge-handle')) {
          deselectTrack();
        }
      }
    });
  }

  initLayerOptionsPopup();

  initMultiSelectControls();

  initPreviewControls();
  initProjectSettingsModal();

  initTrackRows();

  initTimelineScrollAndScrub();

  initThreeEngine();
  calculateMaxDuration();
  setTimelineOffset(0);
  updateUndoRedoUI();
  initMoveTransformController();
  initBorderShadowController();
  initEditShapeSubpanel();
  initEditTextSubpanel();
  initCameraControlSubpanel();
  initExportModalEvents();
});

function handleLayerOptionAction(action) {
  if (action === 'paste') {
    pasteLayerFromClipboard();
    return;
  }
  if (action === 'select-all') {
    if (typeof selectAllLayers === 'function') selectAllLayers();
    return;
  }
  if (action === 'select-other') {
    if (typeof selectOtherLayers === 'function') selectOtherLayers();
    return;
  }

  if (!selectedTrackRow) return;
  const id = selectedTrackRow.dataset.layerId;
  if (!id) return;

  const t = getLayerTransform(id);

  // Compute composition aspect ratio & world screen bounds
  let aspect = 9 / 16;
  if (projectRatio === '16:9') aspect = 16 / 9;
  else if (projectRatio === '1:1') aspect = 1.0;
  else if (projectRatio === '4:5') aspect = 4 / 5;
  else if (projectRatio === '4:3') aspect = 4 / 3;
  else if (projectRatio === 'custom') {
    const cw = projectCustomWidth || 1080;
    const ch = projectCustomHeight || 1080;
    aspect = cw / ch;
  }

  // Three.js Camera distance 5.0, FOV 45 deg -> world screen height = 4.1421356
  const worldH = 4.1421356;
  const worldW = worldH * aspect;

  // Determine Layer Shape & Local Base Dimensions (same base as renderCanvasOverlay / renderLayerTexture)
  const cat = selectedTrackRow.dataset.category || 'media';
  let shapeType = selectedTrackRow.dataset.shapeType || '';
  if (!shapeType) {
    const clipName = selectedTrackRow.querySelector('.track-clip-name')?.textContent || '';
    const lower = (clipName + '_' + cat).toLowerCase();
    if (lower.includes('circle') || lower.includes('bulat')) shapeType = 'circle';
    else if (lower.includes('triangle') || lower.includes('segitiga')) shapeType = 'triangle';
    else if (lower.includes('round')) shapeType = 'round';
    else if (lower.includes('square') || lower.includes('kotak')) shapeType = 'square';
    else if (lower.includes('star') || lower.includes('bintang')) shapeType = 'star';
    else if (cat === 'shape') shapeType = 'square';
    else shapeType = 'media';
  }

  let sizeX = 100, sizeY = 100;
  if (typeof getLayerShapeParams === 'function') {
    const sp = getLayerShapeParams(id, shapeType === 'media' ? 'square' : shapeType);
    if (sp.sizeX !== undefined) sizeX = sp.sizeX;
    if (sp.sizeY !== undefined) sizeY = sp.sizeY;
  }

  const baseDim = 1.6;
  let baseW = baseDim;
  let baseH = baseDim;

  if (shapeType === 'media' || cat === 'media' || cat === 'video') {
    const aspect = getMediaAspectRatio(id);
    if (aspect >= 1) {
      baseW = baseDim;
      baseH = baseDim / aspect;
    } else {
      baseW = baseDim * aspect;
      baseH = baseDim;
    }
  }

  const shapeBaseW = baseW * (Math.abs(sizeX) / 100);
  const shapeBaseH = baseH * (Math.abs(sizeY) / 100);

  // Exact scale percentages to make this shape touch the composition boundaries 100%
  const stretchW = (worldW / shapeBaseW) * 100;
  const stretchH = (worldH / shapeBaseH) * 100;

  switch (action) {
    case 'copy': {
      copySelectedLayer();
      break;
    }
    case 'paste': {
      pasteLayerFromClipboard();
      break;
    }
    case 'duplicate': {
      duplicateSelectedLayer();
      break;
    }
    case 'delete': {
      deleteSelectedTrack();
      break;
    }
    case 'flip-h': {
      // Flip Horizontal: misal scale 100 jadi -100, -100 jadi 100
      const curW = (t.scaleW !== undefined && t.scaleW !== 0) ? t.scaleW : 100;
      t.scaleW = -curW;
      recordTransformChange(id, t);
      applyTransformToThreeMesh(id, t);
      syncControllerUI();
      render3D();
      break;
    }
    case 'flip-v': {
      // Flip Vertical: misal scale 100 jadi -100, -100 jadi 100
      const curH = (t.scaleH !== undefined && t.scaleH !== 0) ? t.scaleH : 100;
      t.scaleH = -curH;
      recordTransformChange(id, t);
      applyTransformToThreeMesh(id, t);
      syncControllerUI();
      render3D();
      break;
    }
    case 'fit-comp': {
      // FIT: Full Screen tapi keliatan semuanya, ga ke-crop apalagi ke-stretch (Uniform Scale)
      const fitScale = Math.min(stretchW, stretchH);
      const signW = (t.scaleW && t.scaleW < 0) ? -1 : 1;
      const signH = (t.scaleH && t.scaleH < 0) ? -1 : 1;
      t.posX = 0;
      t.posY = 0;
      t.posZ = 0;
      t.rotZ = 0;
      t.scaleW = Math.round(fitScale * signW * 10) / 10;
      t.scaleH = Math.round(fitScale * signH * 10) / 10;
      recordTransformChange(id, t);
      applyTransformToThreeMesh(id, t);
      syncControllerUI();
      render3D();
      break;
    }
    case 'fill-comp': {
      // FILL: Full Screen no stretch tapi ada yang ke-crop / keluar zona (Uniform Scale)
      const fillScale = Math.max(stretchW, stretchH);
      const signW = (t.scaleW && t.scaleW < 0) ? -1 : 1;
      const signH = (t.scaleH && t.scaleH < 0) ? -1 : 1;
      t.posX = 0;
      t.posY = 0;
      t.posZ = 0;
      t.rotZ = 0;
      t.scaleW = Math.round(fillScale * signW * 10) / 10;
      t.scaleH = Math.round(fillScale * signH * 10) / 10;
      recordTransformChange(id, t);
      applyTransformToThreeMesh(id, t);
      syncControllerUI();
      render3D();
      break;
    }
    case 'stretch-comp': {
      // STRETCH: Full Screen stretched, mengubah scale W dan H memenuhi 100% batas layar
      const signW = (t.scaleW && t.scaleW < 0) ? -1 : 1;
      const signH = (t.scaleH && t.scaleH < 0) ? -1 : 1;
      t.posX = 0;
      t.posY = 0;
      t.posZ = 0;
      t.rotZ = 0;
      t.scaleW = Math.round(stretchW * signW * 10) / 10;
      t.scaleH = Math.round(stretchH * signH * 10) / 10;
      recordTransformChange(id, t);
      applyTransformToThreeMesh(id, t);
      syncControllerUI();
      render3D();
      break;
    }
  }
}

let clipboardLayerData = null;

function copySelectedLayer(row) {
  const targetRow = row || selectedTrackRow;
  if (!targetRow) return;
  const id = targetRow.dataset.layerId;
  if (!id) return;

  const cat = targetRow.dataset.category || 'media';
  const shapeType = targetRow.dataset.shapeType || '';
  const clip = targetRow.querySelector('.track-clip');
  const clipName = targetRow.querySelector('.track-clip-name')?.textContent.trim() || 'Layer';
  const tagColor = targetRow.dataset.tagColor || 'none';

  const w = clip ? parseFloat(clip.style.width) || 300 : 300;
  const m = clip ? parseFloat(clip.style.marginLeft) || 0 : 0;

  clipboardLayerData = {
    category: cat,
    shapeType: shapeType,
    name: clipName,
    tagColor: tagColor,
    width: w,
    marginLeft: m,
    transform: JSON.parse(JSON.stringify(getLayerTransform(id))),
    keyframes: JSON.parse(JSON.stringify(layerKeyframes.get(id) || [])),
    fill: JSON.parse(JSON.stringify(getLayerFill(id) || { type: 'color', color: '#FAB778' })),
    borderShadow: JSON.parse(JSON.stringify(getLayerBorderShadow(id) || {})),
    shapeParams: JSON.parse(JSON.stringify(layerShapeParams.get(id) || {})),
    cameraParams: JSON.parse(JSON.stringify(layerCameraParams.get(id) || {})),
    motionBlur: !!layerMotionBlur.get(id)
  };
}

function duplicateSelectedLayer(row) {
  const targetRow = row || selectedTrackRow;
  if (!targetRow) return;
  copySelectedLayer(targetRow);
  pasteLayerFromClipboard(true, targetRow);
}

function pasteLayerFromClipboard(isDuplicate = false, insertAfterRow = null) {
  if (!clipboardLayerData) return;

  const data = clipboardLayerData;
  const newId = 'layer_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);

  const container = document.getElementById('trackRowsContainer');
  if (!container) return;

  const baseName = data.name || 'Layer';
  const newName = isDuplicate ? `${baseName} Copy` : `${baseName}`;

  const row = document.createElement('div');
  row.className = 'track-row adding';
  row.dataset.category = data.category || 'media';
  row.dataset.layerId = newId;
  if (data.shapeType) row.dataset.shapeType = data.shapeType;
  if (data.tagColor && data.tagColor !== 'none') row.dataset.tagColor = data.tagColor;

  const isAudio = (data.category === 'audio');
  const defaultEyeIcon = isAudio ? 'volume_up' : 'visibility';

  let m = data.marginLeft;
  if (!isDuplicate) {
    m = Math.max(0, Math.round(elapsed * PX_PER_SEC));
  }
  const w = data.width || 300;

  const tagStyle = (data.tagColor && data.tagColor !== 'none') ? `border-left: 5px solid ${data.tagColor};` : '';

  row.innerHTML = `
    <button class="track-eye" title="${isAudio ? 'Mute / Unmute Audio' : 'Toggle Visibility'} / Tahan untuk Multi-Select">
      <span class="material-symbols-rounded">${isMultiSelectMode ? 'radio_button_unchecked' : defaultEyeIcon}</span>
    </button>
    <div class="track-trackway" style="transform: translateX(-${timelineOffset}px);">
      <div class="track-clip" style="width: ${w}px; margin-left: ${m}px; ${tagStyle}" title="Klik untuk pilih / buka menu layer">
        <div class="clip-extend-handle handle-left" title="Tarik untuk memanjangkan awal layer">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </div>
        <span class="track-clip-name">${newName}</span>
        <div class="clip-extend-handle handle-right" title="Tarik untuk memanjangkan akhir layer">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
      </div>
    </div>
    <button class="track-reorder-handle" title="Tahan & geser untuk atur urutan layer (Reorder)">
      <span class="material-symbols-rounded">menu</span>
    </button>
  `;

  if (insertAfterRow && insertAfterRow.parentNode === container) {
    container.insertBefore(row, insertAfterRow.nextSibling);
  } else {
    container.insertBefore(row, container.firstChild);
  }

  // Clone data stores
  layerTransforms.set(newId, JSON.parse(JSON.stringify(data.transform)));
  layerKeyframes.set(newId, JSON.parse(JSON.stringify(data.keyframes)));
  layerFills.set(newId, JSON.parse(JSON.stringify(data.fill)));
  layerBorderShadow.set(newId, JSON.parse(JSON.stringify(data.borderShadow)));
  layerShapeParams.set(newId, JSON.parse(JSON.stringify(data.shapeParams)));
  layerCameraParams.set(newId, JSON.parse(JSON.stringify(data.cameraParams)));
  layerMotionBlur.set(newId, data.motionBlur);

  bindTrackEvents(row);
  setTimeout(() => row.classList.remove('adding'), 300);
  syncThreeLayers();
  applyFillToMeshGlobal(newId);
  selectTrack(row);
  calculateMaxDuration();
  triggerAutoSave();
}

function openLayerContextMenu(e, targetRow) {
  e.preventDefault();
  e.stopPropagation();

  const popup = document.getElementById('layerOptionsPopup');
  if (!popup) return;

  const allItems = popup.querySelectorAll('.pop-menu-item');
  const allDividers = popup.querySelectorAll('.pop-menu-divider');
  const colorSection = document.getElementById('popMenuColorSection');

  if (targetRow) {
    selectTrack(targetRow);

    allItems.forEach(item => {
      item.style.display = 'block';
      item.style.opacity = '1';
      item.style.pointerEvents = 'auto';
    });
    allDividers.forEach(div => div.style.display = 'block');
    if (colorSection) {
      colorSection.style.display = 'flex';
      colorSection.classList.remove('hidden');
    }

    const pasteBtn = document.getElementById('popMenuPasteBtn');
    if (pasteBtn) {
      pasteBtn.style.opacity = clipboardLayerData ? '1' : '0.45';
      pasteBtn.style.pointerEvents = clipboardLayerData ? 'auto' : 'none';
    }
  } else {
    // Empty area right-click: Show Copy, Paste, Duplicate (HIDE color section)
    allItems.forEach(item => {
      const act = item.dataset.action;
      if (act === 'copy' || act === 'duplicate') {
        item.style.display = 'block';
        item.style.opacity = selectedTrackRow ? '1' : '0.45';
        item.style.pointerEvents = selectedTrackRow ? 'auto' : 'none';
      } else if (act === 'paste') {
        item.style.display = 'block';
        item.style.opacity = clipboardLayerData ? '1' : '0.45';
        item.style.pointerEvents = clipboardLayerData ? 'auto' : 'none';
      } else {
        item.style.display = 'none';
      }
    });
    allDividers.forEach(div => div.style.display = 'none');
    if (colorSection) {
      colorSection.style.display = 'none';
      colorSection.classList.add('hidden');
    }
  }

  popup.classList.add('active');

  const mouseX = e.clientX || 100;
  const mouseY = e.clientY || 100;

  const popupW = 195;
  const popupH = targetRow ? 295 : 105;

  const left = Math.max(10, Math.min(window.innerWidth - popupW - 12, mouseX));
  const top = Math.max(10, Math.min(window.innerHeight - popupH - 12, mouseY));

  popup.style.left = left + 'px';
  popup.style.top = top + 'px';
}

function handleLayerColorTag(color) {
  if (!selectedTrackRow) return;
  if (typeof pushUndoState === 'function') {
    pushUndoState();
  }
  const row = selectedTrackRow;
  row.dataset.tagColor = color;

  const clip = row.querySelector('.track-clip');
  if (clip) {
    if (color === 'none' || !color) {
      clip.style.borderLeft = '';
    } else {
      clip.style.borderLeft = `5px solid ${color}`;
    }
  }

  document.querySelectorAll('.color-tag-btn').forEach(btn => {
    btn.classList.toggle('selected', btn.dataset.color === color);
  });

  triggerAutoSave();
}

function initLayerOptionsPopup() {
  const popup = document.getElementById('layerOptionsPopup');
  if (!popup) return;

  popup.addEventListener('click', (e) => {
    const item = e.target.closest('.pop-menu-item');
    const colorBtn = e.target.closest('.color-tag-btn');

    if (item) {
      const action = item.dataset.action;
      handleLayerOptionAction(action);
      popup.classList.remove('active');
    } else if (colorBtn) {
      const color = colorBtn.dataset.color;
      handleLayerColorTag(color);
      popup.classList.remove('active');
    }
  });

  window.addEventListener('keydown', (e) => {
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || document.activeElement?.isContentEditable) {
      return;
    }
    if (e.key === 'Escape') {
      if (isMultiSelectMode) {
        exitMultiSelectMode();
      } else if (selectedTrackRow) {
        deselectTrack();
      }
    } else if (e.key === 'Delete' || e.key === 'Backspace') {
      if (isMultiSelectMode && selectedMultiRows.size > 0) {
        const btnDeleteBatch = document.getElementById('btnDeleteSelectedBatch');
        if (btnDeleteBatch) btnDeleteBatch.click();
      } else if (selectedTrackRow) {
        deleteSelectedTrack();
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') {
      if (selectedTrackRow) {
        e.preventDefault();
        copySelectedLayer();
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') {
      if (clipboardLayerData) {
        e.preventDefault();
        pasteLayerFromClipboard();
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') {
      if (selectedTrackRow) {
        e.preventDefault();
        duplicateSelectedLayer();
      }
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') {
      e.preventDefault();
      if (typeof selectAllLayers === 'function') {
        selectAllLayers();
      }
    }
  });
}

function calculateMaxDuration() {
  let maxPx = 0;
  document.querySelectorAll('.track-row').forEach(row => {
    const clip = row.querySelector('.track-clip');
    if (clip) {
      const margin = parseFloat(clip.style.marginLeft) || 0;
      let width    = parseFloat(clip.style.width);
      if (!width || isNaN(width)) {
        width = clip.offsetWidth || 300;
      }
      const endPx  = margin + width;
      if (endPx > maxPx) maxPx = endPx;
    }
  });

  maxPx = Math.max(200, maxPx);
  totalDuration = Math.ceil(maxPx / PX_PER_SEC);
  rebuildTimeRuler(totalDuration);
  renderTimecode();
  return totalDuration;
}

function rebuildTimeRuler(maxSecs) {
  const rulerMarks = document.getElementById('timeRulerMarks');
  if (!rulerMarks) return;

  rulerMarks.innerHTML = '';
  rulerMarks.style.minWidth = `${maxSecs * PX_PER_SEC + 600}px`;

  const wrapper = document.createElement('div');
  wrapper.className = 'ruler-marks-wrapper';
  wrapper.id = 'rulerMarksWrapper';

  // Determine dynamic time step interval based on current zoom level
  let stepSec = 1.0;
  if (PX_PER_SEC >= 220) {
    stepSec = 0.25;
  } else if (PX_PER_SEC >= 115) {
    stepSec = 0.5;
  } else if (PX_PER_SEC >= 55) {
    stepSec = 1.0;
  } else if (PX_PER_SEC >= 28) {
    stepSec = 2.0;
  } else {
    stepSec = 5.0;
  }

  const stepPx = stepSec * PX_PER_SEC;

  for (let s = 0; s <= maxSecs; s = Math.round((s + stepSec) * 100) / 100) {
    const timeText = (typeof formatTime === 'function') ? formatTime(s) : `${s}`;
    const span = document.createElement('span');
    span.className = 'ruler-mark';
    span.style.width = `${stepPx}px`;
    span.innerHTML = `<span class="ruler-mark-text">${timeText}</span>`;
    wrapper.appendChild(span);
  }

  markers.forEach(sec => {
    if (sec <= maxSecs) {
      renderMarkerPin(sec, wrapper);
    }
  });

  rulerMarks.appendChild(wrapper);
}

function renderMarkerPin(sec, container) {
  const targetContainer = container || document.getElementById('rulerMarksWrapper') || document.getElementById('timeRulerMarks');
  if (!targetContainer) return;

  const pin = document.createElement('div');
  pin.className = 'timeline-marker-pin';
  pin.dataset.second = sec;
  pin.style.left = `${sec * PX_PER_SEC}px`;
  pin.title = `Marker: ${formatTime(sec)} (Klik untuk melompat ke titik ini)`;
  pin.innerHTML = `
    <div class="marker-diamond"></div>
    <div class="marker-line"></div>
  `;

  pin.addEventListener('click', (e) => {
    e.stopPropagation();
    setTimelineOffset(sec * PX_PER_SEC);
  });

  targetContainer.appendChild(pin);
}

function toggleMarkerAtCurrent() {
  const curSec = Math.round((timelineOffset / PX_PER_SEC) * 10) / 10;
  const existingIdx = markers.findIndex(m => Math.abs(m - curSec) <= 0.25);

  if (existingIdx >= 0) {
    const removedSec = markers[existingIdx];
    markers.splice(existingIdx, 1);
    rebuildTimeRuler(totalDuration);
    updateMarkerButtonsUI(false);
    recordAction({
      type: 'REMOVE_MARKER',
      second: removedSec
    });
  } else {
    markers.push(curSec);
    markers.sort((a, b) => a - b);
    rebuildTimeRuler(totalDuration);
    updateMarkerButtonsUI(true);
    recordAction({
      type: 'ADD_MARKER',
      second: curSec
    });
  }
}

function removeMarker(sec) {
  const idx = markers.findIndex(m => Math.abs(m - sec) <= 0.25);
  if (idx >= 0) {
    const removedSec = markers[idx];
    markers.splice(idx, 1);
    rebuildTimeRuler(totalDuration);
    updateMarkerButtonsUI(false);
    recordAction({
      type: 'REMOVE_MARKER',
      second: removedSec
    });
  }
}

function updateMarkerButtonsUI(isActive) {
  document.querySelectorAll('[title="Bookmark"]').forEach(btn => {
    btn.classList.toggle('btn-marker-active', isActive);
  });
}

function skipPrevious() {
  const cur = elapsed;
  const stops = new Set([0]);
  markers.forEach(m => stops.add(m));

  if (selectedTrackRow) {
    const id = selectedTrackRow.dataset.layerId;
    if (id) {
      const kfs = layerKeyframes.get(id) || [];
      kfs.forEach(k => stops.add(k.time));
      const clip = selectedTrackRow.querySelector('.track-clip');
      if (clip) {
        const startSec = (parseFloat(clip.style.marginLeft) || 0) / PX_PER_SEC;
        const durSec = (parseFloat(clip.style.width) || 300) / PX_PER_SEC;
        stops.add(startSec);
        stops.add(startSec + durSec);
      }
    }
  }

  const prevStops = Array.from(stops).filter(s => s < cur - 0.05).sort((a, b) => a - b);
  if (prevStops.length > 0) {
    const target = prevStops[prevStops.length - 1];
    setTimelineOffset(target * PX_PER_SEC);
  } else {
    setTimelineOffset(0);
  }
}

function skipNext() {
  const cur = elapsed;
  const maxSec = calculateMaxDuration();
  const stops = new Set([maxSec]);
  markers.forEach(m => stops.add(m));

  if (selectedTrackRow) {
    const id = selectedTrackRow.dataset.layerId;
    if (id) {
      const kfs = layerKeyframes.get(id) || [];
      kfs.forEach(k => stops.add(k.time));
      const clip = selectedTrackRow.querySelector('.track-clip');
      if (clip) {
        const startSec = (parseFloat(clip.style.marginLeft) || 0) / PX_PER_SEC;
        const durSec = (parseFloat(clip.style.width) || 300) / PX_PER_SEC;
        stops.add(startSec);
        stops.add(startSec + durSec);
      }
    }
  }

  const nextStops = Array.from(stops).filter(s => s > cur + 0.05).sort((a, b) => a - b);
  if (nextStops.length > 0) {
    const target = nextStops[0];
    setTimelineOffset(target * PX_PER_SEC);
  } else {
    setTimelineOffset(maxSec * PX_PER_SEC);
  }
}

const videoSeekStates = new Map(); // layerId -> { pendingTime: number|null, isSeeking: boolean }

function requestVideoSeek(layerId, video, targetTime) {
  let state = videoSeekStates.get(layerId);
  if (!state) {
    state = { pendingTime: null, isSeeking: false };
    videoSeekStates.set(layerId, state);

    const onFrameDecoded = () => {
      state.isSeeking = false;
      const vTex = layerVideoTextureMap.get(layerId);
      if (vTex) vTex.needsUpdate = true;
      render3D();

      if (state.pendingTime !== null) {
        const next = state.pendingTime;
        state.pendingTime = null;
        seek(next);
      }
    };

    video.addEventListener('seeked', onFrameDecoded);
    if ('requestVideoFrameCallback' in HTMLVideoElement.prototype) {
      try {
        const hookVfc = () => {
          video.requestVideoFrameCallback(() => {
            onFrameDecoded();
            if (state.isSeeking) hookVfc();
          });
        };
        video.addEventListener('seeking', hookVfc);
      } catch(e) {}
    }
  }

  function seek(t) {
    state.isSeeking = true;
    if (typeof video.fastSeek === 'function') {
      try {
        video.fastSeek(t);
        return;
      } catch(e) {}
    }
    video.currentTime = t;
  }

  if (state.isSeeking || video.seeking) {
    state.pendingTime = targetTime;
  } else {
    if (Math.abs(video.currentTime - targetTime) > 0.033) {
      seek(targetTime);
    }
  }
}

function setTimelineOffset(newOffset, isScrubbing = false) {
  const maxOffset = totalDuration * PX_PER_SEC;
  timelineOffset = Math.max(0, Math.min(maxOffset, newOffset));
  const fps = Number(projectFps) || 30;
  const rawElapsed = timelineOffset / PX_PER_SEC;
  elapsed = Math.round(rawElapsed * fps) / fps;
  renderTimecode();

  const rulerMarks = document.getElementById('timeRulerMarks');
  if (rulerMarks) {
    rulerMarks.style.transform = `translateX(-${timelineOffset}px)`;
  }

  document.querySelectorAll('.track-trackway').forEach(tw => {
    tw.style.transform = `translateX(-${timelineOffset}px)`;
  });

  if (!playing) {
    const isAtMarker = markers.some(m => Math.abs(m - elapsed) <= 0.25);
    updateMarkerButtonsUI(isAtMarker);
  }

  document.querySelectorAll('.track-row').forEach(row => {
    const id = row.dataset.layerId;
    if (id) {
      applyTransformToThreeMesh(id, getLayerTransform(id));
      const fill = getLayerFill(id);
      const cat = row.dataset.category;
      const clipName = row.querySelector('.track-clip-name')?.textContent.trim() || '';
      if (cat === 'video' || (fill && fill.type === 'media' && (videoFrameSequenceMap.has(fill.mediaUrl) || videoFrameSequenceMap.has(id) || (clipName && videoFrameSequenceMap.has(clipName))))) {
        applyFillToMeshGlobal(id);
      }
    }
  });

  if (selectedTrackRow && !playing) {
    updateInspectorQuickButtons();
    syncControllerUI();
  }

  if (!isScrubbing) {
    try {
      document.querySelectorAll('.track-row').forEach(row => {
        const id = row.dataset.layerId;
        if (!id) return;
        const skfs = layerKeyframes.get(id);
        if (skfs && skfs.some(k=>k.strokeSize!==undefined||k.strokeColor!==undefined||k.shadowSize!==undefined||k.shadowAlpha!==undefined||k.shadowPosX!==undefined||k.shadowPosY!==undefined||k.shadowColor!==undefined)) {
          applyFillToMeshGlobal(id);
        }
      });
    } catch(e) {}

    if (isMultiSelectMode && !playing) {
      updateMultiSelectQuickButtons();
    }

    if (!playing) {
      renderAllKeyframeMarkers();
    }
  }

  const pg = document.getElementById('panelGraphEditor');
  if (pg && pg.style.display !== 'none') {
    renderGraphCanvas();
  }

  syncThreeLayers();
  render3D();
  if (selectedTrackRow && typeof renderCanvasOverlay === 'function') {
    renderCanvasOverlay();
  }
  syncAudioPlayback();
  syncVideoPlayback(isScrubbing);
}

const layerAudioMap = new Map(); // layerId -> HTMLAudioElement
const layerVideoMap = new Map(); // layerId -> HTMLVideoElement

function syncAudioPlayback() {
  const rows = document.querySelectorAll('.track-row');
  rows.forEach(row => {
    const layerId = row.dataset.layerId;
    const cat = row.dataset.category;
    const clip = row.querySelector('.track-clip');
    if (!clip || !layerId) return;

    const fill = getLayerFill(layerId);
    const clipName = row.querySelector('.track-clip-name')?.textContent.trim() || '';

    let audioUrl = null;
    const isVideoTrack = (cat === 'video') || (clipName && /\.(mp4|webm|mov|mkv|avi)$/i.test(clipName));
    if (cat === 'audio') {
      audioUrl = fill ? fill.mediaUrl : null;
    } else if (isVideoTrack) {
      const seq = (fill && fill.mediaUrl && videoFrameSequenceMap.get(fill.mediaUrl)) || videoFrameSequenceMap.get(layerId) || (clipName && videoFrameSequenceMap.get(clipName));
      if (seq && seq.audioUrl) {
        audioUrl = seq.audioUrl;
      } else if (fill && fill.mediaUrl && !fill.mediaUrl.startsWith('video_pkg_') && !fill.mediaUrl.startsWith('pkg_') && (fill.mediaUrl.startsWith('data:video/') || /\.(mp4|webm|mov|mkv)$/i.test(fill.mediaUrl))) {
        audioUrl = fill.mediaUrl;
      }
    }

    const isValidAudioUri = typeof audioUrl === 'string' && audioUrl.length > 5 && !audioUrl.startsWith('video_pkg_') && !audioUrl.startsWith('pkg_') && !audioUrl.startsWith('[') && (audioUrl.startsWith('http://') || audioUrl.startsWith('https://') || audioUrl.startsWith('blob:') || audioUrl.startsWith('data:audio/') || audioUrl.startsWith('data:video/'));

    if (!isValidAudioUri) {
      const existingAudio = layerAudioMap.get(layerId);
      if (existingAudio && !existingAudio.paused) {
        existingAudio.pause();
      }
      return;
    }

    let audio = layerAudioMap.get(layerId);
    if (!audio || audio.src !== audioUrl) {
      if (audio) {
        audio.pause();
        audio.removeAttribute("src"); try { audio.load(); } catch(_) {}
      }
      audio = new Audio(audioUrl);
      audio.preload = 'auto';
      layerAudioMap.set(layerId, audio);
    }

    const eye = row.querySelector('.track-eye .material-symbols-rounded');
    const isMuted = eye && (eye.textContent.trim() === 'volume_off' || eye.textContent.trim() === 'visibility_off');

    const marginLeft = parseFloat(clip.style.marginLeft) || 0;
    const width = parseFloat(clip.style.width) || clip.offsetWidth || 300;
    const startTime = marginLeft / PX_PER_SEC;
    const clipDuration = width / PX_PER_SEC;

    audio.muted = !!isMuted;

    const inRange = (elapsed >= startTime && elapsed < startTime + clipDuration);
    const currentAudioTime = Math.max(0, elapsed - startTime);

    if (playing && inRange && !isMuted) {
      if (Math.abs(audio.currentTime - currentAudioTime) > 0.25) {
        audio.currentTime = currentAudioTime;
      }
      if (audio.paused) {
        audio.play().catch(() => {});
      }
    } else {
      if (!audio.paused) {
        audio.pause();
      }
      if (!playing && Math.abs(audio.currentTime - currentAudioTime) > 0.05) {
        audio.currentTime = currentAudioTime;
      }
    }
  });
}

function syncVideoPlayback(isScrubbing = false) {
  const rows = document.querySelectorAll('.track-row');
  rows.forEach(row => {
    const layerId = row.dataset.layerId;
    const cat = row.dataset.category || 'media';
    const clip = row.querySelector('.track-clip');
    if (!clip || !layerId) return;

    const fill = getLayerFill(layerId);
    if (!fill || fill.type !== 'media' || !fill.mediaUrl) return;

    const clipName = row.querySelector('.track-clip-name')?.textContent.trim() || '';
    const seq = videoFrameSequenceMap.get(fill.mediaUrl) || videoFrameSequenceMap.get(layerId) || (clipName && videoFrameSequenceMap.get(clipName));
    if (seq && seq.frames && seq.frames.length > 0) {
      applyFillToMeshGlobal(layerId);
      return;
    }

    const isVideo = (cat === 'video') || (clipName && /\.(mp4|webm|mov|mkv|ogg|avi)$/i.test(clipName)) || (fill.mediaType && fill.mediaType.startsWith('video')) || (fill.mediaUrl && fill.mediaUrl.startsWith('data:video/'));
    if (!isVideo) return;

    let video = layerVideoMap.get(layerId);
    if (!video || video.src !== fill.mediaUrl) {
      if (video) {
        video.pause();
        video.removeAttribute("src"); try { video.load(); } catch(_) {}
      }
      video = document.createElement('video');
      video.src = fill.mediaUrl;
      video.crossOrigin = 'anonymous';
      video.playsInline = true;
      video.muted = false;
      video.preload = 'auto';
      layerVideoMap.set(layerId, video);
    }

    const eye = row.querySelector('.track-eye .material-symbols-rounded');
    const isHiddenOrMuted = eye && (eye.textContent.trim() === 'visibility_off' || eye.textContent.trim() === 'volume_off');

    const marginLeft = parseFloat(clip.style.marginLeft) || 0;
    const width = parseFloat(clip.style.width) || clip.offsetWidth || 300;
    const startTime = marginLeft / PX_PER_SEC;
    const clipDuration = width / PX_PER_SEC;

    video.muted = !!isHiddenOrMuted;

    const inRange = (elapsed >= startTime && elapsed < startTime + clipDuration);
    const currentVideoTime = Math.max(0, elapsed - startTime);

    if (playing && inRange && !isHiddenOrMuted) {
      if (Math.abs(video.currentTime - currentVideoTime) > 0.15) {
        video.currentTime = currentVideoTime;
      }
      if (video.paused) {
        video.play().catch(() => {});
      }
      applyFillToMeshGlobal(layerId);
    } else {
      if (!video.paused) {
        video.pause();
      }
      if (isScrubbing) {
        requestVideoSeek(layerId, video, currentVideoTime);
      } else {
        if (Math.abs(video.currentTime - currentVideoTime) > 0.04) {
          requestVideoSeek(layerId, video, currentVideoTime);
        }
      }
    }
  });
}

function togglePlayPause() {
  playing ? pausePlayback() : startPlayback();
}

function startPlayback() {
  const maxSec = calculateMaxDuration();
  if (elapsed >= maxSec) {
    setTimelineOffset(0);
  }

  playing = true;
  setPlayIcons('pause');

  const video = document.getElementById('canvasVideo');
  if (video && typeof video.play === 'function') {
    video.play().catch(() => {});
  }

  syncAudioPlayback();
  syncVideoPlayback();

  let lastNow = performance.now();
  let frameAccumulator = 0;

  function tick(now) {
    if (!playing) return;
    const dt = (now - lastNow) / 1000;
    lastNow = now;

    frameAccumulator += dt;
    const targetFps = projectFps || 30;
    const frameDuration = 1 / targetFps;

    if (frameAccumulator >= frameDuration) {
      const framesToAdvance = Math.floor(frameAccumulator / frameDuration);
      frameAccumulator -= framesToAdvance * frameDuration;

      const currentFrame = Math.round(elapsed * targetFps);
      const nextFrame = currentFrame + framesToAdvance;
      const maxFrames = Math.ceil(totalDuration * targetFps);

      if (nextFrame >= maxFrames) {
        setTimelineOffset(totalDuration * PX_PER_SEC);
        pausePlayback();
        return;
      }

      const nextSec = nextFrame / targetFps;
      setTimelineOffset(nextSec * PX_PER_SEC);
    }

    animFrameId = requestAnimationFrame(tick);
  }

  animFrameId = requestAnimationFrame(tick);
}

function pausePlayback() {
  playing = false;
  setPlayIcons('play_arrow');
  if (animFrameId) cancelAnimationFrame(animFrameId);
  const video = document.getElementById('canvasVideo');
  if (video && typeof video.pause === 'function') {
    video.pause();
  }
  layerAudioMap.forEach(audio => {
    if (!audio.paused) audio.pause();
  });
  if (selectedTrackRow && typeof renderCanvasOverlay === 'function') {
    renderCanvasOverlay();
  }
}

function setPlayIcons(iconName) {
  document.querySelectorAll('.play-icon').forEach(icon => {
    icon.textContent = iconName;
  });
}

function formatTime(s) {
  const totalFrames = Math.floor((s || 0) * projectFps);
  const frame = totalFrames % projectFps;
  const totalSecs = Math.floor(s || 0);
  const m = String(Math.floor(totalSecs / 60)).padStart(2, '0');
  const sec = String(totalSecs % 60).padStart(2, '0');
  const f = String(frame).padStart(2, '0');
  return `${m}:${sec}:${f}`;
}

function renderTimecode() {
  const display = document.getElementById('timecodeDisplay');
  if (display) {
    display.textContent = formatTime(elapsed);
  }
}

function captureProjectSnapshot() {
  const tracks = [];
  document.querySelectorAll('.track-row').forEach(row => {
    const clip = row.querySelector('.track-clip');
    const clipName = row.querySelector('.track-clip-name');
    const eyeBtn = row.querySelector('.track-eye');
    const isHidden = eyeBtn && eyeBtn.querySelector('.material-symbols-rounded') && eyeBtn.querySelector('.material-symbols-rounded').textContent.trim() === 'visibility_off';

    tracks.push({
      layerId: row.dataset.layerId,
      category: row.dataset.category || 'media',
      name: (clipName && clipName.textContent.trim()) || 'Layer',
      colorTag: row.dataset.tagColor || 'none',
      isMask: row.dataset.isMask === 'true',
      marginLeft: parseFloat(clip ? clip.style.marginLeft : 0) || 0,
      width: parseFloat(clip ? clip.style.width : 300) || (clip ? clip.offsetWidth : 300) || 300,
      isHidden: !!isHidden,
      isLinked: row.classList.contains('linked-parent'),
      linkedTo: row.dataset.linkedTo ? JSON.parse(row.dataset.linkedTo) : [],
      parentBind: row.dataset.parentBind ? JSON.parse(row.dataset.parentBind) : null,
      linkedFrom: row.dataset.linkedFrom ? JSON.parse(row.dataset.linkedFrom) : [],
      dataset: { ...row.dataset }
    });
  });

  return {
    tracks,
    transforms: Array.from(layerTransforms.entries()).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
    keyframes: Array.from(layerKeyframes.entries()).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
    fills: Array.from(layerFills.entries()).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
    borderShadows: Array.from(layerBorderShadow.entries()).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
    shapeParams: Array.from(layerShapeParams.entries()).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
    cameraParams: Array.from(layerCameraParams.entries()).map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
    motionBlurs: Array.from(layerMotionBlur.entries()),
    markers: [...markers],
    isGlobalMotionBlurEnabled,
    projectMotionBlurTune,
    projectMotionBlurSamples,
    selectedLayerId: selectedTrackRow ? selectedTrackRow.dataset.layerId : null,
    isMultiSelectMode: !!isMultiSelectMode,
    selectedMultiRowIds: Array.from(selectedMultiRows).map(r => r.dataset.layerId).filter(Boolean)
  };
}

function restoreProjectSnapshot(snapshot) {
  if (!snapshot) return;

  // 1. Restore state Maps
  layerTransforms.clear();
  if (snapshot.transforms) {
    snapshot.transforms.forEach(([k, v]) => layerTransforms.set(k, JSON.parse(JSON.stringify(v))));
  }

  layerKeyframes.clear();
  if (snapshot.keyframes) {
    snapshot.keyframes.forEach(([k, v]) => layerKeyframes.set(k, JSON.parse(JSON.stringify(v))));
  }

  layerFills.clear();
  if (snapshot.fills) {
    snapshot.fills.forEach(([k, v]) => layerFills.set(k, JSON.parse(JSON.stringify(v))));
  }

  layerBorderShadow.clear();
  if (snapshot.borderShadows) {
    snapshot.borderShadows.forEach(([k, v]) => layerBorderShadow.set(k, JSON.parse(JSON.stringify(v))));
  }

  layerShapeParams.clear();
  if (snapshot.shapeParams) {
    snapshot.shapeParams.forEach(([k, v]) => layerShapeParams.set(k, JSON.parse(JSON.stringify(v))));
  }

  layerCameraParams.clear();
  if (snapshot.cameraParams) {
    snapshot.cameraParams.forEach(([k, v]) => layerCameraParams.set(k, JSON.parse(JSON.stringify(v))));
  }

  layerMotionBlur.clear();
  if (snapshot.motionBlurs) {
    snapshot.motionBlurs.forEach(([k, v]) => layerMotionBlur.set(k, v));
  }

  if (snapshot.markers) {
    markers = [...snapshot.markers];
  }

  if (snapshot.isGlobalMotionBlurEnabled !== undefined) {
    isGlobalMotionBlurEnabled = snapshot.isGlobalMotionBlurEnabled;
    const btnD = document.getElementById('btnToggleGlobalMotionBlurDesktop');
    const btnM = document.getElementById('btnToggleGlobalMotionBlurMobile');
    if (btnD) btnD.classList.toggle('active', isGlobalMotionBlurEnabled);
    if (btnM) btnM.classList.toggle('active', isGlobalMotionBlurEnabled);
  }

  if (snapshot.projectMotionBlurTune !== undefined) {
    projectMotionBlurTune = snapshot.projectMotionBlurTune;
  }
  if (snapshot.projectMotionBlurSamples !== undefined) {
    projectMotionBlurSamples = snapshot.projectMotionBlurSamples;
  }

  // 2. Efficient DOM Track Sync (Zero-Flicker & Preserves Event Listeners)
  const container = document.getElementById('trackRowsContainer');
  if (container && snapshot.tracks) {
    const currentRows = Array.from(container.querySelectorAll('.track-row'));
    const currentIds = currentRows.map(r => r.dataset.layerId);
    const snapIds = snapshot.tracks.map(t => t.layerId);

    const idsMatch = (currentIds.length === snapIds.length) && currentIds.every((id, idx) => id === snapIds[idx]);

    if (idsMatch) {
      // In-place update: update properties without tearing down DOM elements
      snapshot.tracks.forEach((tr, i) => {
        const row = currentRows[i];
        row.dataset.tagColor = tr.colorTag || 'none';
        row.dataset.isMask = tr.isMask ? 'true' : 'false';
        row.classList.toggle('is-mask-layer', !!tr.isMask);
        row.classList.toggle('linked-parent', !!tr.isLinked);

        const clip = row.querySelector('.track-clip');
        if (clip) {
          clip.style.width = `${tr.width}px`;
          clip.style.marginLeft = `${tr.marginLeft}px`;
          if (tr.colorTag && tr.colorTag !== 'none') {
            clip.style.borderLeft = `5px solid ${tr.colorTag}`;
          } else {
            clip.style.borderLeft = '';
          }
        }
        const nameEl = row.querySelector('.track-clip-name');
        if (nameEl && tr.name) nameEl.textContent = tr.name;

        const eye = row.querySelector('.track-eye .material-symbols-rounded');
        if (eye && !isMultiSelectMode) {
          const isAudio = tr.category === 'audio';
          eye.textContent = tr.isHidden ? (isAudio ? 'volume_off' : 'visibility_off') : (isAudio ? 'volume_up' : 'visibility');
        }
        const tw = row.querySelector('.track-trackway');
        if (tw) {
          tw.style.transform = `translateX(-${timelineOffset}px)`;
          tw.style.opacity = tr.isHidden ? '0.35' : '1';
        }
      });
    } else {
      // Rebuild tracks only when layers were actually added, removed or reordered
      container.innerHTML = '';
      snapshot.tracks.forEach(tr => {
        const row = document.createElement('div');
        row.className = 'track-row' + (tr.isLinked ? ' linked-parent' : '') + (tr.isMask ? ' is-mask-layer' : '');
        row.dataset.layerId = tr.layerId;
        row.dataset.category = tr.category || 'media';
        row.dataset.tagColor = tr.colorTag || 'none';
        if (tr.dataset) {
          Object.keys(tr.dataset).forEach(k => { row.dataset[k] = tr.dataset[k]; });
        }
        if (tr.linkedTo && tr.linkedTo.length > 0) row.dataset.linkedTo = JSON.stringify(tr.linkedTo);
        if (tr.parentBind) row.dataset.parentBind = JSON.stringify(tr.parentBind);
        if (tr.linkedFrom && tr.linkedFrom.length > 0) row.dataset.linkedFrom = JSON.stringify(tr.linkedFrom);

        const isMulti = isMultiSelectMode;
        const tagStyle = (tr.colorTag && tr.colorTag !== 'none') ? `border-left: 5px solid ${tr.colorTag};` : '';
        const isAudio = tr.category === 'audio';
        const defaultEye = isAudio ? 'volume_up' : 'visibility';
        const hiddenEye = isAudio ? 'volume_off' : 'visibility_off';

        row.innerHTML = `
          <button class="track-eye" title="Toggle Visibility / Tahan untuk Multi-Select">
            <span class="material-symbols-rounded">${isMulti ? 'radio_button_unchecked' : (tr.isHidden ? hiddenEye : defaultEye)}</span>
          </button>
          <div class="track-trackway" style="transform: translateX(-${timelineOffset}px);${tr.isHidden ? ' opacity: 0.35;' : ''}">
            <div class="track-clip" style="width: ${tr.width}px; margin-left: ${tr.marginLeft}px; ${tagStyle}" title="Klik untuk pilih / buka menu layer">
              <div class="clip-extend-handle handle-left" title="Tarik untuk memanjangkan awal layer">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
              </div>
              <span class="track-clip-name">${tr.name}</span>
              <div class="clip-extend-handle handle-right" title="Tarik untuk memanjangkan akhir layer">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
              </div>
            </div>
          </div>
          <button class="track-reorder-handle" title="Tahan & geser untuk atur urutan layer (Reorder)">
            <span class="material-symbols-rounded">menu</span>
          </button>
        `;
        bindTrackEvents(row);
        container.appendChild(row);
      });
    }
  }

  // 3. Selection & Multi-Select sync
  if (snapshot.isMultiSelectMode) {
    if (!isMultiSelectMode) {
      isMultiSelectMode = true;
      document.body.classList.add('multi-select-mode');
    }
    selectedMultiRows.clear();
    document.querySelectorAll('.track-row').forEach(r => {
      r.classList.remove('multi-selected');
      const eye = r.querySelector('.track-eye .material-symbols-rounded');
      if (eye) eye.textContent = 'radio_button_unchecked';
    });
    if (snapshot.selectedMultiRowIds) {
      snapshot.selectedMultiRowIds.forEach(id => {
        const r = document.querySelector(`.track-row[data-layer-id="${id}"]`);
        if (r) {
          selectedMultiRows.add(r);
          r.classList.add('multi-selected');
          const eye = r.querySelector('.track-eye .material-symbols-rounded');
          if (eye) eye.textContent = 'check_circle';
        }
      });
    }
    updateMultiSelectUI();
  } else {
    if (isMultiSelectMode) {
      exitMultiSelectMode();
    }
    if (snapshot.selectedLayerId) {
      const rowToSelect = document.querySelector(`.track-row[data-layer-id="${snapshot.selectedLayerId}"]`);
      if (rowToSelect && rowToSelect !== selectedTrackRow) {
        selectTrack(rowToSelect);
      }
    } else if (selectedTrackRow) {
      deselectTrack();
    }
  }

  // 4. Update Engine, 3D Mesh, Fills, Keyframes, Overlay
  syncThreeLayers();
  layerFills.forEach((_, fid) => {
    if (typeof applyFillToMeshGlobal === 'function') applyFillToMeshGlobal(fid);
  });
  rebuildTimeRuler(totalDuration);
  renderAllKeyframeMarkers();
  updateKeyframeUI();
  syncControllerUI();
  if (typeof syncBorderShadowUI === 'function') syncBorderShadowUI();
  calculateMaxDuration();
  render3D();
  renderCanvasOverlay();
  triggerAutoSave();
}

let _isGestureActive = false;

// After Effects Style Undo Group Engine
let _undoGroupDepth = 0;
let _undoGroupInitialSnapshot = null;

function beginUndoGroup(name = 'Operation') {
  if (_undoGroupDepth === 0) {
    _undoGroupInitialSnapshot = captureProjectSnapshot();
  }
  _undoGroupDepth++;
}

function endUndoGroup() {
  if (_undoGroupDepth > 0) {
    _undoGroupDepth--;
    if (_undoGroupDepth === 0 && _undoGroupInitialSnapshot) {
      undoStack.push(_undoGroupInitialSnapshot);
      if (undoStack.length > 60) undoStack.shift();
      redoStack.length = 0;
      _undoGroupInitialSnapshot = null;
      updateUndoRedoUI();
      triggerAutoSave();
    }
  }
}

function executeWithUndoGroup(name, fn) {
  beginUndoGroup(name);
  try {
    fn();
  } finally {
    endUndoGroup();
  }
}

function pushUndoState() {
  if (_undoGroupDepth > 0) return;
  undoStack.push(captureProjectSnapshot());
  if (undoStack.length > 60) undoStack.shift();
  redoStack.length = 0;
  updateUndoRedoUI();
}

function recordAction(action) {
  if (_undoGroupDepth === 0) {
    pushUndoState();
    triggerAutoSave();
  }
}

function updateUndoRedoUI() {
  const hasUndo = (undoStack.length > 0);
  const hasRedo = (redoStack.length > 0);

  const undoSelectors = ['[title="Undo"]', '#btnUndoDesktop', '#btnUndoMobile', '.undo-btn'];
  undoSelectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(btn => {
      btn.disabled = !hasUndo;
      btn.style.opacity = hasUndo ? '1.0' : '0.4';
      btn.style.pointerEvents = hasUndo ? 'auto' : 'none';
      btn.classList.toggle('disabled', !hasUndo);
    });
  });

  const redoSelectors = ['[title="Redo"]', '#btnRedoDesktop', '#btnRedoMobile', '.redo-btn'];
  redoSelectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(btn => {
      btn.disabled = !hasRedo;
      btn.style.opacity = hasRedo ? '1.0' : '0.4';
      btn.style.pointerEvents = hasRedo ? 'auto' : 'none';
      btn.classList.toggle('disabled', !hasRedo);
    });
  });
}

function undo() {
  if (undoStack.length === 0) return;
  const current = captureProjectSnapshot();
  redoStack.push(current);
  if (redoStack.length > 60) redoStack.shift();

  const prev = undoStack.pop();
  restoreProjectSnapshot(prev);
  updateUndoRedoUI();
}

function redo() {
  if (redoStack.length === 0) return;
  const current = captureProjectSnapshot();
  undoStack.push(current);
  if (undoStack.length > 60) undoStack.shift();

  const next = redoStack.pop();
  restoreProjectSnapshot(next);
  updateUndoRedoUI();
}

let isProgrammaticScrolling = false;

function initTimelineScrollAndScrub() {
  const viewport = document.getElementById('tracksViewport');
  const timecode = document.getElementById('timecodeDisplay');
  if (!viewport) return;

  let isDown = false;
  let startX = 0;
  let startY = 0;
  let startOffset = 0;
  let startScrollTop = 0;
  let downTimestamp = 0;
  let isRowTarget = false;
  let scrubRafId = null;
  let pendingScrubOffset = null;

  function scheduleScrub(offset) {
    pendingScrubOffset = offset;
    if (!scrubRafId) {
      scrubRafId = requestAnimationFrame(() => {
        scrubRafId = null;
        if (pendingScrubOffset !== null) {
          setTimelineOffset(pendingScrubOffset, true);
        }
      });
    }
  }

  viewport.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;
    if (e.target.closest('button, .track-eye, .track-del-btn, .timeline-marker-pin, .clip-extend-handle, .clip-keyframe-marker, .clip-keyframes-container, .layer-options-popup')) return;

    isDown = true;
    viewport.classList.add('is-dragging');
    startX = e.pageX;
    startY = e.pageY;
    startOffset = timelineOffset;
    startScrollTop = viewport.scrollTop;
    downTimestamp = performance.now();
    isRowTarget = !!e.target.closest('.track-clip');
  });

  window.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const dx = e.pageX - startX;
    const dy = e.pageY - startY;

    scheduleScrub(startOffset - dx);

    if (!selectedTrackRow) {
      viewport.scrollTop = startScrollTop - dy;
    }
  });

  window.addEventListener('mouseup', (e) => {
    if (isDown) {
      const dx = Math.abs(e.pageX - startX);
      const dy = Math.abs(e.pageY - startY);

      isDown = false;
      viewport.classList.remove('is-dragging');

      if (scrubRafId) {
        cancelAnimationFrame(scrubRafId);
        scrubRafId = null;
      }
      setTimelineOffset(timelineOffset, false);

      // If single click on empty timeline area or trackway space without dragging
      if (!isRowTarget && dx < 6 && dy < 6) {
        if (selectedTrackRow) {
          deselectTrack();
        }
      }
    }
  });

  viewport.addEventListener('touchstart', (e) => {
    if (e.target.closest('button, .track-eye, .track-del-btn, .timeline-marker-pin, .clip-extend-handle, .clip-keyframe-marker, .clip-keyframes-container, .layer-options-popup')) return;
    const touch = e.touches[0];
    isDown = true;
    startX = touch.pageX;
    startY = touch.pageY;
    startOffset = timelineOffset;
    startScrollTop = viewport.scrollTop;
    downTimestamp = performance.now();
    isRowTarget = !!e.target.closest('.track-clip');
  }, { passive: true });

  viewport.addEventListener('touchmove', (e) => {
    if (!isDown) return;
    const touch = e.touches[0];
    const dx = touch.pageX - startX;
    const dy = touch.pageY - startY;

    scheduleScrub(startOffset - dx);

    if (!selectedTrackRow) {
      viewport.scrollTop = startScrollTop - dy;
    }
  }, { passive: true });

  viewport.addEventListener('touchend', (e) => {
    if (isDown) {
      const touch = e.changedTouches ? e.changedTouches[0] : null;
      const curX = touch ? touch.pageX : startX;
      const curY = touch ? touch.pageY : startY;
      const dx = Math.abs(curX - startX);
      const dy = Math.abs(curY - startY);

      isDown = false;

      if (scrubRafId) {
        cancelAnimationFrame(scrubRafId);
        scrubRafId = null;
      }
      setTimelineOffset(timelineOffset, false);

      // If single tap on empty area on touch
      if (!isRowTarget && dx < 8 && dy < 8) {
        if (selectedTrackRow) {
          deselectTrack();
        }
      }
    }
  });

  viewport.addEventListener('wheel', (e) => {
    if (selectedTrackRow || e.shiftKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
      e.preventDefault();
      setTimelineOffset(timelineOffset + (e.deltaX || e.deltaY));
    } else {
      viewport.scrollTop += e.deltaY;
    }
  }, { passive: false });

  if (timecode) {
    timecode.addEventListener('click', () => {
      setTimelineOffset(timelineOffset + 5 * PX_PER_SEC);
    });
  }
}

function initPreviewControls() {
  const desktopMenuBtn = document.getElementById('btnDesktopMenu');
  const desktopPopover = document.getElementById('desktopMenuPopover');

  const mobileMenuBtn  = document.getElementById('btnMobileMenu');
  const mobilePopover  = document.getElementById('mobileMenuPopover');

  if (desktopMenuBtn && desktopPopover) {
    desktopMenuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isActive = desktopPopover.classList.toggle('active');
      desktopMenuBtn.classList.toggle('active', isActive);
    });
  }

  if (mobileMenuBtn && mobilePopover) {
    mobileMenuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isActive = mobilePopover.classList.toggle('active');
      mobileMenuBtn.classList.toggle('active', isActive);
    });
  }

  document.addEventListener('click', (e) => {
    if (desktopPopover && !desktopPopover.contains(e.target) && !desktopMenuBtn?.contains(e.target)) {
      desktopPopover.classList.remove('active');
      desktopMenuBtn?.classList.remove('active');
    }
    if (mobilePopover && !mobilePopover.contains(e.target) && !mobileMenuBtn?.contains(e.target)) {
      mobilePopover.classList.remove('active');
      mobileMenuBtn?.classList.remove('active');
    }
  });

  const qualityBtns = [
    document.getElementById('btnToggleQualityDesktop'),
    document.getElementById('btnToggleQualityMobile')
  ];
  qualityBtns.forEach(btn => {
    if (btn) btn.addEventListener('click', toggleLowerQuality);
  });

  const gridBtns = [
    document.getElementById('btnToggleGridDesktop'),
    document.getElementById('btnToggleGridMobile')
  ];
  gridBtns.forEach(btn => {
    if (btn) btn.addEventListener('click', toggleGrid);
  });

  const zoomInBtns = [
    document.getElementById('btnZoomInDesktop'),
    document.getElementById('btnZoomInMobile')
  ];
  zoomInBtns.forEach(btn => {
    if (btn) btn.addEventListener('click', zoomIn);
  });

  const zoomOutBtns = [
    document.getElementById('btnZoomOutDesktop'),
    document.getElementById('btnZoomOutMobile')
  ];
  zoomOutBtns.forEach(btn => {
    if (btn) btn.addEventListener('click', zoomOut);
  });

  const zoomResetBtns = [
    document.getElementById('btnZoomResetDesktop'),
    document.getElementById('btnZoomResetMobile')
  ];
  zoomResetBtns.forEach(btn => {
    if (btn) btn.addEventListener('click', zoomReset);
  });

  // Wire Undo & Redo buttons
  const undoBtns = [
    document.getElementById('btnUndoDesktop'),
    document.getElementById('btnUndoMobile'),
    ...document.querySelectorAll('[title="Undo"]')
  ];
  undoBtns.forEach(btn => {
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        undo();
      });
    }
  });

  const redoBtns = [
    document.getElementById('btnRedoDesktop'),
    document.getElementById('btnRedoMobile'),
    ...document.querySelectorAll('[title="Redo"]')
  ];
  redoBtns.forEach(btn => {
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        redo();
      });
    }
  });

  // Global Keyboard Shortcuts (Ctrl+Z, Ctrl+Y, Ctrl+Shift+Z)
  window.addEventListener('keydown', (e) => {
    if (e.target.matches('input, textarea, [contenteditable="true"]')) return;

    if (e.ctrlKey || e.metaKey) {
      if (e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) {
          redo();
        } else {
          undo();
        }
      } else if (e.key.toLowerCase() === 'y') {
        e.preventDefault();
        redo();
      }
    }
  });

  // Auto-capture undo state before gesture manipulation starts
  const controllerArea = document.getElementById('layerInspectorDrawer');
  if (controllerArea) {
    const onGestureStart = (e) => {
      if (e.target.closest('#move-pad, #dial-area, .fish-ui-ruler-container, .controller-wheel-row, .am-slider, .color-grid-item, .pop-menu-item, .graph-handle, .kf-diamond')) {
        if (!_isGestureActive) {
          pushUndoState();
          _isGestureActive = true;
        }
      }
    };
    controllerArea.addEventListener('pointerdown', onGestureStart, { capture: true });
    controllerArea.addEventListener('touchstart', onGestureStart, { capture: true, passive: true });
  }

  window.addEventListener('pointerup', () => { _isGestureActive = false; });
  window.addEventListener('touchend', () => { _isGestureActive = false; });
  window.addEventListener('mouseup', () => { _isGestureActive = false; });
}

function toggleLowerQuality() {
  isLowQuality = !isLowQuality;
  
  const videoLayer   = document.getElementById('canvasVideo');
  const qualityBadge = document.getElementById('canvasQualityBadge');

  if (videoLayer) videoLayer.classList.toggle('low-quality', isLowQuality);
  if (qualityBadge) qualityBadge.classList.toggle('active', isLowQuality);

  const qualityBtns = [
    document.getElementById('btnToggleQualityDesktop'),
    document.getElementById('btnToggleQualityMobile')
  ];
  qualityBtns.forEach(btn => {
    if (btn) btn.classList.toggle('active', isLowQuality);
  });

  // beneran low-res: turunin WebGL pixel ratio + re-create texture setengah resolusi
  try {
    if (typeof renderer3D !== 'undefined' && renderer3D) {
      const ratio = isLowQuality ? 0.5 : Math.min(window.devicePixelRatio || 1, 2);
      renderer3D.setPixelRatio(ratio);
      const container = document.getElementById('canvasVideo');
      if (container) {
        const w = container.clientWidth || 360;
        const h = container.clientHeight || 640;
        renderer3D.setSize(w, h);
      }
    }
    // clear pending debounced renders
    if (typeof pendingTextureRenders !== 'undefined') {
      pendingTextureRenders.forEach((h) => { try{ cancelAnimationFrame(h); }catch(e){} });
      pendingTextureRenders.clear();
    }
    // force re-render semua layer dengan resolusi baru (512 vs 1024)
    document.querySelectorAll('.track-row').forEach(row => {
      const id = row.dataset.layerId;
      if (id) {
        const mesh = typeof meshLayerMap !== 'undefined' ? meshLayerMap.get(id) : null;
        if (mesh && mesh.material && mesh.material.map) {
          try { mesh.material.map.dispose(); } catch(e) {}
          mesh.material.map = null;
        }
        if (typeof applyFillToMeshGlobal === 'function') applyFillToMeshGlobal(id);
      }
    });
    if (typeof render3D === 'function') render3D();
    if (typeof renderCanvasOverlay === 'function') renderCanvasOverlay();
  } catch(e) { console.warn('low quality toggle', e); }
}

function toggleGrid() {
  isGridOn = !isGridOn;

  const gridOverlay = document.getElementById('canvasGridOverlay');
  if (gridOverlay) gridOverlay.classList.toggle('active', isGridOn);

  const gridBtns = [
    document.getElementById('btnToggleGridDesktop'),
    document.getElementById('btnToggleGridMobile')
  ];
  gridBtns.forEach(btn => {
    if (btn) btn.classList.toggle('active', isGridOn);
  });
}

function zoomIn() {
  if (zoomIndex < zoomLevels.length - 1) {
    zoomIndex++;
    applyZoom();
  }
}

function zoomOut() {
  if (zoomIndex > 0) {
    zoomIndex--;
    applyZoom();
  }
}

function zoomReset() {
  zoomIndex = 2;
  applyZoom();
}

function applyZoom() {
  const currentZoom = zoomLevels[zoomIndex];
  const canvasWrap = document.getElementById('canvasWrap');
  
  if (canvasWrap) {
    canvasWrap.style.transform = `scale(${currentZoom})`;
    canvasWrap.style.transformOrigin = 'center center';
  }

  const zoomText = `${Math.round(currentZoom * 100)}%`;
  const labels = [
    document.getElementById('zoomValueDesktop'),
    document.getElementById('zoomValueMobile')
  ];
  labels.forEach(l => {
    if (l) l.textContent = zoomText;
  });
}

let selectedTrackRow = null;



function updateInspectorQuickButtons() {
  if (!selectedTrackRow) return;
  const clip = selectedTrackRow.querySelector('.track-clip');
  if (!clip) return;

  const curMargin = parseFloat(clip.style.marginLeft) || 0;
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
  const curEnd = curMargin + curWidth;

  const btnLeft = document.getElementById('btnInspTrimLeft');
  const btnSplit = document.getElementById('btnInspSplit');
  const btnRight = document.getElementById('btnInspTrimRight');

  if (!btnLeft || !btnSplit || !btnRight) return;

  if (timelineOffset > curEnd + 0.5) {
    btnSplit.style.display = 'none';
    btnLeft.style.display = 'flex';
    btnRight.style.display = 'flex';

    btnLeft.title = "Panjangkan / Extend Layer sampai ke Playhead";
    btnLeft.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="20" y1="3" x2="20" y2="21" stroke-width="1.9"/>
        <path d="M4 8.5h5" stroke-dasharray="2 2"/>
        <path d="M4 15.5h5" stroke-dasharray="2 2"/>
        <path d="M4 8.5v7" stroke-dasharray="2 2"/>
        <path d="M9 8.5h11v7H9"/>
      </svg>
    `;
    btnLeft.onclick = (e) => {
      e.stopPropagation();
      executeExtendRightToPlayhead(selectedTrackRow);
    };

    btnRight.title = "Geser Layer sampai ke Playhead (Move to Playhead)";
    btnRight.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="20" y1="3" x2="20" y2="21" stroke-width="1.9"/>
        <rect x="4" y="8.5" width="8" height="7" rx="1.5"/>
        <line x1="12" y1="12" x2="19" y2="12"/>
        <polyline points="16 9.5 19 12 16 14.5"/>
      </svg>
    `;
    btnRight.onclick = (e) => {
      e.stopPropagation();
      executeMoveRightToPlayhead(selectedTrackRow);
    };

  } else if (timelineOffset < curMargin - 0.5) {
    btnSplit.style.display = 'none';
    btnLeft.style.display = 'flex';
    btnRight.style.display = 'flex';

    btnLeft.title = "Geser Layer dari awal Playhead (Move to Playhead)";
    btnLeft.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="4" y1="3" x2="4" y2="21" stroke-width="1.9"/>
        <rect x="12" y="8.5" width="8" height="7" rx="1.5"/>
        <line x1="12" y1="12" x2="5" y2="12"/>
        <polyline points="8 9.5 5 12 8 14.5"/>
      </svg>
    `;
    btnLeft.onclick = (e) => {
      e.stopPropagation();
      executeMoveLeftToPlayhead(selectedTrackRow);
    };

    btnRight.title = "Panjangkan / Extend Layer mundur ke Playhead";
    btnRight.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="4" y1="3" x2="4" y2="21" stroke-width="1.9"/>
        <path d="M4 8.5h11v7H4"/>
        <path d="M15 8.5h5" stroke-dasharray="2 2"/>
        <path d="M15 15.5h5" stroke-dasharray="2 2"/>
        <path d="M20 8.5v7" stroke-dasharray="2 2"/>
      </svg>
    `;
    btnRight.onclick = (e) => {
      e.stopPropagation();
      executeExtendLeftToPlayhead(selectedTrackRow);
    };

  } else {
    btnSplit.style.display = 'flex';
    btnLeft.style.display = 'flex';
    btnRight.style.display = 'flex';

    btnLeft.title = "Potong Sisi Kiri (Trim Left to Playhead)";
    btnLeft.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="3" x2="12" y2="21" stroke-width="1.9"/>
        <path d="M4 8.5h4.5v7H4" stroke-dasharray="2 2"/>
        <path d="M15.5 8.5H20v7h-4.5"/>
      </svg>
    `;
    btnLeft.onclick = (e) => {
      e.stopPropagation();
      executeTrimLeftOnRow(selectedTrackRow, true);
    };

    btnSplit.title = "Bagi / Split di Posisi Playhead";
    btnSplit.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="3" x2="12" y2="21" stroke-width="1.9"/>
        <path d="M8.5 8.5H4v7h4.5"/>
        <path d="M15.5 8.5H20v7h-4.5"/>
      </svg>
    `;
    btnSplit.onclick = (e) => {
      e.stopPropagation();
      executeSplitOnRow(selectedTrackRow, true);
    };

    btnRight.title = "Potong Sisi Kanan (Trim Right to Playhead)";
    btnRight.innerHTML = `
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="3" x2="12" y2="21" stroke-width="1.9"/>
        <path d="M8.5 8.5H4v7h4.5"/>
        <path d="M20 8.5h-4.5v7H20" stroke-dasharray="2 2"/>
      </svg>
    `;
    btnRight.onclick = (e) => {
      e.stopPropagation();
      executeTrimRightOnRow(selectedTrackRow, true);
    };
  }
}

function snappyScrollTo(element, targetTop, duration = 110) {
  const startTop = element.scrollTop;
  const change = targetTop - startTop;
  if (Math.abs(change) < 1) return;

  const startTime = performance.now();
  isProgrammaticScrolling = true;

  function step(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easeProgress = 1 - Math.pow(1 - progress, 3);

    element.scrollTop = startTop + change * easeProgress;

    if (progress < 1) {
      requestAnimationFrame(step);
    } else {
      element.scrollTop = targetTop;
      setTimeout(() => {
        isProgrammaticScrolling = false;
      }, 40);
    }
  }

  requestAnimationFrame(step);
}

function selectTrack(row) {
  if (!row) return;

  if (selectedTrackRow && selectedTrackRow !== row) {
    selectedTrackRow.classList.remove('selected');
  }

  selectedTrackRow = row;
  row.classList.add('selected');

  const clip = row.querySelector('.track-clip');
  if (clip && !clip.querySelector('.clip-extend-handle')) {
    const leftH = document.createElement('div');
    leftH.className = 'clip-extend-handle handle-left';
    leftH.title = 'Tarik untuk memanjangkan awal layer';
    leftH.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`;
    clip.prepend(leftH);

    const rightH = document.createElement('div');
    rightH.className = 'clip-extend-handle handle-right';
    rightH.title = 'Tarik untuk memanjangkan akhir layer';
    rightH.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`;
    clip.appendChild(rightH);

    bindTrackEvents(row);
  }

  const addTrackPopover = document.getElementById('addTrackPopover');
  const fabAdd = document.getElementById('fabAddTrack');
  if (addTrackPopover) addTrackPopover.classList.remove('active');
  if (fabAdd) fabAdd.classList.remove('active');

  const topBar = document.getElementById('layerTopContextBar');
  const nameEl = document.getElementById('topInspLayerName');
  const iconEl = document.getElementById('topInspLayerIcon');
  const clipName = row.querySelector('.track-clip-name');

  if (nameEl && clipName) {
    nameEl.textContent = clipName.textContent.trim();
  }

  if (iconEl) {
    const cat = row.dataset.category || 'media';
    if (cat === 'shape') iconEl.textContent = 'interests';
    else if (cat === 'camera') iconEl.textContent = 'videocam';
    else if (cat === 'text') iconEl.textContent = 'title';
    else iconEl.textContent = 'perm_media';
  }

  if (topBar) {
    topBar.classList.add('active');
  }

  const currentTagColor = row.dataset.tagColor || 'none';
  document.querySelectorAll('.color-tag-btn').forEach(btn => {
    btn.classList.toggle('selected', btn.getAttribute('data-color') === currentTagColor);
  });

  const btnTopLink = document.getElementById('topBtnInspLink');
  if (btnTopLink) {
    let isLinked = false;
    try {
      isLinked = !!(row.dataset.linkedTo && JSON.parse(row.dataset.linkedTo).length > 0);
    } catch (_) {}
    btnTopLink.classList.toggle('active', isLinked);
  }

  const btnTopMotionBlur = document.getElementById('topBtnInspMotionBlur');
  if (btnTopMotionBlur) {
    const layerId = row.dataset.layerId || 'default';
    const isMbOn = !!layerMotionBlur.get(layerId);
    btnTopMotionBlur.classList.toggle('active', isMbOn);
    btnTopMotionBlur.title = isMbOn ? 'Motion Blur: ON' : 'Motion Blur: OFF';
  }

  const drawer = document.getElementById('layerInspectorDrawer');
  const panelMove = document.getElementById('panelMoveTransform');
  const panelColor = document.getElementById('panelColorFill');
  const panelGraph = document.getElementById('panelGraphEditor');
  const toolsGrid = document.querySelector('.inspector-tools-grid');
  const quickStrip = document.querySelector('.inspector-quick-strip');

  const panelBorderShadow = document.getElementById('panelBorderShadow');

  // Reset any subpanels back to tools grid default view
  if (panelMove) {
    panelMove.style.display = 'none';
    panelMove.classList.remove('slide-in', 'slide-out');
  }
  if (panelColor) {
    panelColor.style.display = 'none';
    panelColor.classList.remove('slide-in', 'slide-out');
  }
  if (panelBorderShadow) {
    panelBorderShadow.style.display = 'none';
    panelBorderShadow.classList.remove('slide-in', 'slide-out');
  }
  if (panelGraph) {
    panelGraph.style.display = 'none';
    panelGraph.classList.remove('slide-in', 'slide-out');
  }
  if (quickStrip) quickStrip.style.display = 'flex';
  if (toolsGrid) toolsGrid.style.display = 'grid';

  if (window.FishPopover) {
    window.FishPopover.close();
  }

  if (drawer) {
    drawer.classList.remove('subpanel-open', 'subpanel-color', 'subpanel-move', 'subpanel-border-shadow', 'subpanel-graph', 'in-subpanel');
    drawer.classList.add('active');
  }

  const cat = row.dataset.category || 'media';
  const clipText = clipName ? clipName.textContent.trim() : '';
  const isCamera = (cat === 'camera' || clipText.toLowerCase().startsWith('camera'));
  const isNull = (cat === 'null' || clipText.toLowerCase().startsWith('null'));

  // Configure drawer tools grid buttons
  const allTileBtns = toolsGrid ? Array.from(toolsGrid.querySelectorAll('.insp-tile-btn')) : [];
  if (isCamera) {
    // Camera layer: Show Move & Transform + Camera Control side by side (2-column layout)
    if (toolsGrid) {
      toolsGrid.classList.remove('single-item');
      toolsGrid.classList.add('camera-layout');
    }
    allTileBtns.forEach(btn => {
      if (btn.id === 'btnInspMoveTransform' || btn.id === 'btnInspCameraControl') {
        btn.style.display = 'flex';
      } else {
        btn.style.display = 'none';
      }
    });
  } else if (isNull) {
    // Null layer: ONLY show Move & Transform (Full Width flexible tile)
    if (toolsGrid) {
      toolsGrid.classList.remove('camera-layout');
      toolsGrid.classList.add('single-item');
    }
    allTileBtns.forEach(btn => {
      if (btn.id === 'btnInspMoveTransform') {
        btn.style.display = 'flex';
      } else {
        btn.style.display = 'none';
      }
    });
  } else {
    // Standard layers: show all valid tiles
    if (toolsGrid) {
      toolsGrid.classList.remove('single-item', 'camera-layout');
    }
    allTileBtns.forEach(btn => {
      if (btn.id === 'btnInspCameraControl') {
        btn.style.display = 'none';
      } else if (btn.id === 'btnInspEditShape') {
        btn.style.display = (cat === 'shape') ? 'flex' : 'none';
      } else if (btn.id === 'btnInspEditText') {
        btn.style.display = (cat === 'text') ? 'flex' : 'none';
      } else {
        btn.style.display = 'flex';
      }
    });
  }

  updateInspectorQuickButtons();
  syncControllerUI();
  if (typeof syncBorderShadowUI === 'function') syncBorderShadowUI();
  renderAllKeyframeMarkers();
  requestCanvasOverlayRender();

  const viewport = document.getElementById('tracksViewport');
  if (viewport) {
    viewport.classList.add('drawer-open');
    viewport.classList.add('locked-vertical');
    
    requestAnimationFrame(() => {
      const drawerEl = document.getElementById('layerInspectorDrawer');
      const drawerHeight = (drawerEl && drawerEl.offsetHeight) || 220;
      
      const viewportRect = viewport.getBoundingClientRect();
      const rowRect = row.getBoundingClientRect();
      
      const currentRelativeRowTop = rowRect.top - viewportRect.top;
      const rowHeight = rowRect.height || 34;
      
      const visibleTop = 28;
      const visibleBottom = Math.max(visibleTop + 60, viewportRect.height - drawerHeight);
      const visibleCenter = visibleTop + (visibleBottom - visibleTop) / 2;
      
      const desiredRelativeRowTop = visibleCenter - (rowHeight / 2);
      
      const deltaScroll = currentRelativeRowTop - desiredRelativeRowTop;
      const targetScrollTop = Math.max(0, viewport.scrollTop + deltaScroll);
      
      snappyScrollTo(viewport, targetScrollTop, 110);
    });
  }
}

function deselectTrack() {
  if (selectedTrackRow) {
    selectedTrackRow.classList.remove('selected');
    selectedTrackRow = null;
  }
  const topBar = document.getElementById('layerTopContextBar');
  if (topBar) {
    topBar.classList.remove('active');
  }
  const optionsPopup = document.getElementById('layerOptionsPopup');
  if (optionsPopup) {
    optionsPopup.classList.remove('active');
  }
  const drawer = document.getElementById('layerInspectorDrawer');
  if (drawer) {
    drawer.classList.remove('active', 'subpanel-open', 'subpanel-color', 'subpanel-move', 'subpanel-border-shadow', 'subpanel-graph', 'in-subpanel');
  }
  const panelMove = document.getElementById('panelMoveTransform');
  const panelColor = document.getElementById('panelColorFill');
  const panelBorderShadow = document.getElementById('panelBorderShadow');
  const panelGraph = document.getElementById('panelGraphEditor');
  const toolsGrid = document.querySelector('.inspector-tools-grid');
  const quickStrip = document.querySelector('.inspector-quick-strip');

  if (panelMove) {
    panelMove.style.display = 'none';
    panelMove.classList.remove('slide-in', 'slide-out');
  }
  if (panelColor) {
    panelColor.style.display = 'none';
    panelColor.classList.remove('slide-in', 'slide-out');
  }
  if (panelBorderShadow) {
    panelBorderShadow.style.display = 'none';
    panelBorderShadow.classList.remove('slide-in', 'slide-out');
  }
  if (panelGraph) {
    panelGraph.style.display = 'none';
    panelGraph.classList.remove('slide-in', 'slide-out');
  }
  if (quickStrip) quickStrip.style.display = 'flex';
  if (toolsGrid) toolsGrid.style.display = 'grid';

  if (window.FishPopover) {
    window.FishPopover.close();
  }
  renderCanvasOverlay();
  renderAllKeyframeMarkers();
  updateKeyframeUI();

  const viewport = document.getElementById('tracksViewport');
  if (viewport) {
    viewport.classList.remove('drawer-open');
    viewport.classList.remove('locked-vertical');
  }
}

function cleanupDeletedLayerData(layerId) {
  if (!layerId) return;
  layerTransforms.delete(layerId);
  layerKeyframes.delete(layerId);
  layerFills.delete(layerId);
  layerBorderShadow.delete(layerId);
  layerShapeParams.delete(layerId);
  layerMotionBlur.delete(layerId);
  mediaNaturalRatioMap.delete(layerId);
  if (layerAudioMap.has(layerId)) {
    const a = layerAudioMap.get(layerId);
    if (a) { a.pause(); a.removeAttribute("src"); try { a.load(); } catch(_) {} }
    layerAudioMap.delete(layerId);
  }
  if (layerVideoMap.has(layerId)) {
    const v = layerVideoMap.get(layerId);
    if (v) { v.pause(); v.removeAttribute("src"); try { v.load(); } catch(_) {} }
    layerVideoMap.delete(layerId);
  }
  const m = meshLayerMap.get(layerId);
  if (m) {
    scene3D.remove(m);
    if (m.geometry) m.geometry.dispose();
    if (m.material) m.material.dispose();
    meshLayerMap.delete(layerId);
  }
}

function deleteSelectedTrack() {
  if (!selectedTrackRow) return;
  const rowToDelete = selectedTrackRow;
  const layerId = rowToDelete.dataset.layerId;
  deselectTrack();

  const nextSib = rowToDelete.nextSibling;
  rowToDelete.classList.add('deleting');

  setTimeout(() => {
    rowToDelete.remove();
    cleanupDeletedLayerData(layerId);
    calculateMaxDuration();
    recordAction({
      type: 'DELETE_TRACK',
      element: rowToDelete,
      nextSibling: nextSib
    });
    syncThreeLayers();
    renderCanvasOverlay();
    saveCurrentProject();
  }, 290);
}

function initTrackReorder(row, handle) {
  let isDragging = false;
  let startPointerY = 0;
  let initialIndex = 0;
  let targetIndex = 0;
  const container = document.getElementById('trackRowsContainer');
  if (!container) return;

  const onPointerDown = (e) => {
    e.stopPropagation();
    isDragging = true;
    startPointerY = e.pageY || (e.touches && e.touches[0].pageY) || 0;

    const allRows = Array.from(container.querySelectorAll('.track-row'));
    initialIndex = allRows.indexOf(row);
    targetIndex = initialIndex;

    const rowStep = (allRows.length > 1) 
      ? Math.abs(allRows[1].offsetTop - allRows[0].offsetTop)
      : 44.5;

    row.classList.add('dragging-reorder');
    row.style.transform = 'translateY(0px)';

    allRows.forEach(r => {
      if (r !== row) {
        r.style.transition = 'transform 0.22s cubic-bezier(0.2, 0.9, 0.3, 1)';
      }
    });

    const onPointerMove = (me) => {
      if (!isDragging) return;
      const currentY = me.pageY || (me.touches && me.touches[0].pageY) || 0;
      const deltaY = currentY - startPointerY;
      row.style.transform = `translateY(${deltaY}px)`;

      const steps = Math.round(deltaY / rowStep);
      const newTargetIndex = Math.max(0, Math.min(initialIndex + steps, allRows.length - 1));

      if (newTargetIndex !== targetIndex) {
        targetIndex = newTargetIndex;

        allRows.forEach((r, idx) => {
          if (r === row) return;

          if (initialIndex < targetIndex) {
            if (idx > initialIndex && idx <= targetIndex) {
              r.style.transform = `translateY(-${rowStep}px)`;
            } else {
              r.style.transform = 'translateY(0px)';
            }
          } else if (initialIndex > targetIndex) {
            if (idx >= targetIndex && idx < initialIndex) {
              r.style.transform = `translateY(${rowStep}px)`;
            } else {
              r.style.transform = 'translateY(0px)';
            }
          } else {
            r.style.transform = 'translateY(0px)';
          }
        });
      }
    };

    const onPointerUp = () => {
      if (!isDragging) return;
      isDragging = false;
      row.classList.remove('dragging-reorder');

      allRows.forEach(r => {
        r.style.transition = 'none';
        r.style.transform = '';
      });

      if (targetIndex !== initialIndex) {
        const currentRows = Array.from(container.querySelectorAll('.track-row'));
        const targetElement = currentRows[targetIndex];
        if (targetIndex > initialIndex) {
          container.insertBefore(row, targetElement.nextSibling);
        } else {
          container.insertBefore(row, targetElement);
        }
      }

      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);
    };

    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);
    window.addEventListener('touchmove', onPointerMove, { passive: false });
    window.addEventListener('touchend', onPointerUp);
  };

  handle.addEventListener('mousedown', onPointerDown);
  handle.addEventListener('touchstart', onPointerDown, { passive: false });
}

let currentProjectId = sessionStorage.getItem('activeProjectId') || ('proj_' + Date.now());
