let _mediaDbPromise = null;
function getMediaDB() {
  if (!_mediaDbPromise) {
    _mediaDbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open('fishTool_media_db', 2);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains('media_items')) {
            db.createObjectStore('media_items', { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains('video_packages')) {
            db.createObjectStore('video_packages', { keyPath: 'id' });
          }
        };
        req.onsuccess = (e) => resolve(e.target.result);
        req.onerror = () => resolve(null);
      } catch (_) {
        resolve(null);
      }
    });
  }
  return _mediaDbPromise;
}

let _projectsDbPromise = null;
function getProjectsDB() {
  if (!_projectsDbPromise) {
    _projectsDbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open('fishTool_projects_db', 2);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains('saved_projects')) {
            db.createObjectStore('saved_projects', { keyPath: 'id' });
          }
        };
        req.onsuccess = (e) => resolve(e.target.result);
        req.onerror = () => resolve(null);
      } catch (_) {
        resolve(null);
      }
    });
  }
  return _projectsDbPromise;
}

let scene3D = null;
let camera3D = null;
let renderer3D = null;
const meshLayerMap = new Map();

const _rulerInstances = {};

function initInfiniteRuler(id, vertical) {
  const el = document.getElementById(id);
  if (!el) return;
  if (window.FishUI && window.FishUI.createRuler) {
    _rulerInstances[id] = window.FishUI.createRuler({
      container: el,
      vertical: !!vertical,
      onChange: (val, valChange) => {
        if (!selectedTrackRow) return;
        const layerId = selectedTrackRow.dataset.layerId || 'default';
        const t = getLayerTransform(layerId);
        if (id === 'z-ruler') {
          t.posZ = Math.round(t.posZ - valChange * 1.5);
        } else if (id === 'ruler-w') {
          const delta = Math.round(valChange * 0.5);
          t.scaleW = t.scaleW + delta;
          if (t.isLinked) {
            t.scaleH = t.scaleH + delta;
          }
        } else if (id === 'ruler-h') {
          const delta = Math.round(valChange * 0.5);
          t.scaleH = t.scaleH + delta;
          if (t.isLinked) {
            t.scaleW = t.scaleW + delta;
          }
        }
        recordTransformChange(layerId, t);
        syncControllerUI();
      }
    });
  }
}

function updateInfiniteRuler(id, offset) {
  if (_rulerInstances[id]) {
    _rulerInstances[id].setOffset(offset);
  }
}

const layerTransforms = new Map();
const layerKeyframes = new Map();
const layerFills = new Map(); // {type:'color'|'media'|'gradient', color, mediaUrl, gradientType, gradientStops}
const layerShapeParams = new Map();
const layerMotionBlur = new Map(); // layerId -> boolean
let isGlobalMotionBlurEnabled = true;
let projectMotionBlurTune = 0.5;
let projectMotionBlurSamples = 6;
const pendingTextureRenders = new Map(); // debounce biar tidak lag saat drag stroke/shadow
let projectFps = 30;

function getLayerShapeParams(id, shapeType) {
  if (!layerShapeParams.has(id)) {
    layerShapeParams.set(id, {
      square: { sizeX: 100, sizeY: 100, rounded: 0, renderMode: 'fill', thickness: 14, points: [{x:-50, y:-50}, {x:50, y:-50}, {x:50, y:50}, {x:-50, y:50}], selectedPointIdx: 0 },
      circle: { sizeX: 100, sizeY: 100, renderMode: 'fill', thickness: 14, points: [{x:0, y:-50}, {x:50, y:0}, {x:0, y:50}, {x:-50, y:0}], selectedPointIdx: 0 },
      round: { sizeX: 100, sizeY: 100, rounded: 22, renderMode: 'fill', thickness: 14 },
      triangle: { sizeX: 100, sizeY: 100, step: 3, curve: 0, renderMode: 'fill', thickness: 14, points: [{x:0, y:-50}, {x:50, y:50}, {x:-50, y:50}], selectedPointIdx: 0 },
      heart: { sizeX: 100, sizeY: 100, renderMode: 'fill', thickness: 14, points: [{x:0, y:-30}, {x:40, y:-60}, {x:60, y:-10}, {x:0, y:60}, {x:-60, y:-10}, {x:-40, y:-60}], selectedPointIdx: 0 },
      love: { sizeX: 100, sizeY: 100, renderMode: 'fill', thickness: 14, points: [{x:0, y:-30}, {x:40, y:-60}, {x:60, y:-10}, {x:0, y:60}, {x:-60, y:-10}, {x:-40, y:-60}], selectedPointIdx: 0 },
      star: { sizeX: 100, sizeY: 100, pointsCount: 5, innerRadius: 40, renderMode: 'fill', thickness: 14, points: [{x:0, y:-60}, {x:18, y:-20}, {x:60, y:-20}, {x:26, y:8}, {x:38, y:50}, {x:0, y:24}, {x:-38, y:50}, {x:-26, y:8}, {x:-60, y:-20}, {x:-18, y:-20}], selectedPointIdx: 0 },
      'star-4': { sizeX: 100, sizeY: 100, pointsCount: 4, innerRadius: 30, renderMode: 'fill', thickness: 14, points: [{x:0, y:-60}, {x:16, y:-16}, {x:60, y:0}, {x:16, y:16}, {x:0, y:60}, {x:-16, y:16}, {x:-60, y:0}, {x:-16, y:-16}], selectedPointIdx: 0 },
      hexagon: { sizeX: 100, sizeY: 100, sides: 6, rounded: 0, renderMode: 'fill', thickness: 14, points: [{x:0, y:-55}, {x:48, y:-28}, {x:48, y:28}, {x:0, y:55}, {x:-48, y:28}, {x:-48, y:-28}], selectedPointIdx: 0 },
      polygon: { sizeX: 100, sizeY: 100, sides: 5, rounded: 0, renderMode: 'fill', thickness: 14 },
      svg_path: { pathData: '', points: [], selectedPointIdx: 0, renderMode: 'fill', thickness: 14 },
      line: {
        points: [
          { x: -50, y: 0 },
          { x: 50, y: 0 }
        ],
        selectedPointIdx: 0,
        thickness: 14,
        renderMode: 'outline'
      },
      arrow: {
        points: [
          { x: -50, y: 0 },
          { x: 50, y: 0 }
        ],
        selectedPointIdx: 0,
        thickness: 16,
        headSize: 34,
        renderMode: 'outline'
      }
    });
  }
  const allParams = layerShapeParams.get(id);
  if (shapeType && allParams[shapeType]) {
    return allParams[shapeType];
  }
  if (shapeType === 'love' && allParams['heart']) return allParams['heart'];
  if (shapeType && !allParams[shapeType]) {
    allParams[shapeType] = { sizeX: 100, sizeY: 100, renderMode: 'fill', thickness: 14, points: [{x:0, y:-50}, {x:50, y:50}, {x:-50, y:50}], selectedPointIdx: 0 };
    return allParams[shapeType];
  }
  return allParams;
}

// Helper functions for layer linking
function getProjectFromDOM() {
  const container = document.getElementById('trackRowsContainer');
  if (!container) return { tracks: [] };

  const tracks = [];
  container.querySelectorAll('.track-row').forEach(row => {
    const clip = row.querySelector('.track-clip');
    if (!clip) return;

    const id = row.dataset.layerId;
    const name = clip.querySelector('.track-clip-name')?.textContent || row.dataset.category || 'Layer';
    const category = row.dataset.category || 'custom';
    const colorTag = row.dataset.tagColor || 'none';
    const visible = !row.querySelector('.track-eye')?.classList.contains('hidden-layer');

    const marginLeft = parseFloat(clip.style.marginLeft) || 0;
    const width = parseFloat(clip.style.width) || clip.offsetWidth || 300;
    const startTime = marginLeft / (typeof PX_PER_SEC !== 'undefined' ? PX_PER_SEC : 80);
    const duration = width / (typeof PX_PER_SEC !== 'undefined' ? PX_PER_SEC : 80);

    tracks.push({
      id,
      name,
      type: category === 'shape' ? 'shape' : category === 'text' ? 'text' : 'media',
      category,
      colorTag,
      visible,
      startTime,
      duration,
      linkedTo: row.dataset.linkedTo ? JSON.parse(row.dataset.linkedTo) : [],
      linkedFrom: row.dataset.linkedFrom ? JSON.parse(row.dataset.linkedFrom) : [],
      parentBind: row.dataset.parentBind ? JSON.parse(row.dataset.parentBind) : null
    });
  });

  return { tracks };
}

function saveProjectToDOM(project) {
  const container = document.getElementById('trackRowsContainer');
  if (!container || !project) return;

  project.tracks.forEach(track => {
    const row = container.querySelector(`.track-row[data-layer-id="${track.id}"]`);
    if (!row) return;

    if (track.linkedTo && track.linkedTo.length > 0) {
      row.dataset.linkedTo = JSON.stringify(track.linkedTo);
    } else {
      delete row.dataset.linkedTo;
      delete row.dataset.parentBind;
    }
    if (track.parentBind) {
      row.dataset.parentBind = JSON.stringify(track.parentBind);
    }
    if (track.linkedFrom && track.linkedFrom.length > 0) {
      row.dataset.linkedFrom = JSON.stringify(track.linkedFrom);
    } else {
      delete row.dataset.linkedFrom;
    }
  });
}
function getLayerFill(id) {
  if (!layerFills.has(id)) layerFills.set(id, {type:'color', color:'#FAB778', mediaUrl:null, gradientType:'linear', gradientStops:[{offset:0,color:'#000000'},{offset:1,color:'#FFFFFF'}]});
  return layerFills.get(id);
}

// ════════════════════════════════════════════════════════════════
// Text Layer Typography State & Google Fonts Catalog
// ════════════════════════════════════════════════════════════════
const layerTexts = new Map();

function getLayerText(id) {
  let t = layerTexts.get(id);
  if (!t) {
    t = {
      content: 'Heading Title',
      font: 'Poppins',
      size: 48,
      align: 'center', // 'left' | 'center' | 'right' | 'justify'
      bold: true,
      italic: false,
      underline: false,
      uppercase: false,
      letterSpacing: 0,
      lineHeight: 1.2
    };
    layerTexts.set(id, t);
  }
  return t;
}

const GOOGLE_FONTS_CATALOG = [
  // Sans-Serif
  { name: 'Plus Jakarta Sans', category: 'sans-serif', preview: 'Plus Jakarta Sans' },
  { name: 'Poppins', category: 'sans-serif', preview: 'Poppins Modern Design' },
  { name: 'Montserrat', category: 'sans-serif', preview: 'Montserrat Clean Bold' },
  { name: 'Inter', category: 'sans-serif', preview: 'Inter Dynamic Type' },
  { name: 'Roboto', category: 'sans-serif', preview: 'Roboto Standard' },
  { name: 'Open Sans', category: 'sans-serif', preview: 'Open Sans Neutral' },
  { name: 'Lato', category: 'sans-serif', preview: 'Lato Warm Sans' },
  { name: 'Oswald', category: 'sans-serif', preview: 'OSWALD CONDENSED' },
  { name: 'Raleway', category: 'sans-serif', preview: 'Raleway Elegant Sans' },
  { name: 'Nunito', category: 'sans-serif', preview: 'Nunito Soft Rounded' },
  { name: 'Rubik', category: 'sans-serif', preview: 'Rubik Smooth Geo' },
  { name: 'Work Sans', category: 'sans-serif', preview: 'Work Sans Modern' },
  { name: 'DM Sans', category: 'sans-serif', preview: 'DM Sans Geometric' },
  { name: 'Outfit', category: 'sans-serif', preview: 'Outfit Tech Clean' },
  { name: 'Ubuntu', category: 'sans-serif', preview: 'Ubuntu Contemporary' },

  // Serif
  { name: 'Playfair Display', category: 'serif', preview: 'Playfair Display Luxury' },
  { name: 'Merriweather', category: 'serif', preview: 'Merriweather Editorial' },
  { name: 'Lora', category: 'serif', preview: 'Lora Contemporary Serif' },
  { name: 'PT Serif', category: 'serif', preview: 'PT Serif Classic' },
  { name: 'Cinzel', category: 'serif', preview: 'CINZEL ROMAN EMPIRE' },
  { name: 'Cormorant Garamond', category: 'serif', preview: 'Cormorant Haute Couture' },
  { name: 'EB Garamond', category: 'serif', preview: 'EB Garamond Traditional' },
  { name: 'Bitter', category: 'serif', preview: 'Bitter Contemporary Slab' },
  { name: 'Spectral', category: 'serif', preview: 'Spectral Refined Serif' },
  { name: 'Bodoni Moda', category: 'serif', preview: 'Bodoni Moda Elegance' },

  // Display / Heading
  { name: 'Bebas Neue', category: 'display', preview: 'BEBAS NEUE IMPACT' },
  { name: 'Anton', category: 'display', preview: 'ANTON MASSIVE HEADLINE' },
  { name: 'Bangers', category: 'display', preview: 'BANGERS COMIC ACTION' },
  { name: 'Righteous', category: 'display', preview: 'Righteous 80s Retro' },
  { name: 'Alfa Slab One', category: 'display', preview: 'ALFA SLAB ULTRA HEAVY' },
  { name: 'Abril Fatface', category: 'display', preview: 'Abril Fatface Display' },
  { name: 'Bungee', category: 'display', preview: 'BUNGEE SIGNBOARD' },
  { name: 'Fredoka', category: 'display', preview: 'Fredoka Bold Bubble' },
  { name: 'Permanent Marker', category: 'display', preview: 'Permanent Marker Style' },
  { name: 'Shrikhand', category: 'display', preview: 'Shrikhand Retro Swash' },
  { name: 'Russo One', category: 'display', preview: 'RUSSO ONE POWER' },
  { name: 'Lobster', category: 'display', preview: 'Lobster Vintage Script' },
  { name: 'Rubik Glitch', category: 'display', preview: 'Rubik Glitch Cyber' },

  // Handwriting / Script
  { name: 'Pacifico', category: 'handwriting', preview: 'Pacifico Ocean Surf' },
  { name: 'Caveat', category: 'handwriting', preview: 'Caveat Natural Handwriting' },
  { name: 'Dancing Script', category: 'handwriting', preview: 'Dancing Script Cursive' },
  { name: 'Satisfy', category: 'handwriting', preview: 'Satisfy Brush Calligraphy' },
  { name: 'Great Vibes', category: 'handwriting', preview: 'Great Vibes Elegant Script' },
  { name: 'Sacramento', category: 'handwriting', preview: 'Sacramento Monoline Script' },
  { name: 'Kalam', category: 'handwriting', preview: 'Kalam Casual Ballpoint' },
  { name: 'Shadows Into Light', category: 'handwriting', preview: 'Shadows Into Light' },
  { name: 'Yellowtail', category: 'handwriting', preview: 'Yellowtail Flat Script' },

  // Monospace / Tech
  { name: 'JetBrains Mono', category: 'monospace', preview: 'JetBrains Mono 0123' },
  { name: 'Orbitron', category: 'monospace', preview: 'ORBITRON SCI-FI HUD' },
  { name: 'Fira Code', category: 'monospace', preview: 'Fira Code => () {}' },
  { name: 'Space Mono', category: 'monospace', preview: 'Space Mono 80s Synth' },
  { name: 'VT323', category: 'monospace', preview: 'VT323 RETRO TERMINAL' },
  { name: 'Press Start 2P', category: 'monospace', preview: 'PRESS START 8-BIT' },
  { name: 'Share Tech Mono', category: 'monospace', preview: 'Share Tech Digital Matrix' },
  { name: 'Silkscreen', category: 'monospace', preview: 'SILKSCREEN PIXEL ART' }
];

const loadedGoogleFonts = new Set(['Plus Jakarta Sans']);

function loadGoogleFont(fontName) {
  if (!fontName || fontName === 'sans-serif' || fontName === 'serif' || fontName === 'monospace') {
    return Promise.resolve();
  }
  if (loadedGoogleFonts.has(fontName)) {
    return Promise.resolve();
  }
  return new Promise((resolve) => {
    const formatted = fontName.replace(/\s+/g, '+');
    const linkId = 'gfont_' + fontName.replace(/[^a-zA-Z0-9]/g, '_');
    if (!document.getElementById(linkId)) {
      const link = document.createElement('link');
      link.id = linkId;
      link.rel = 'stylesheet';
      link.href = `https://fonts.googleapis.com/css2?family=${formatted}:ital,wght@0,400;0,600;0,700;0,800;1,400;1,700&display=swap`;
      link.onload = () => {
        loadedGoogleFonts.add(fontName);
        if (document.fonts) {
          document.fonts.ready.then(() => resolve());
        } else {
          resolve();
        }
      };
      link.onerror = () => resolve();
      document.head.appendChild(link);
    } else {
      loadedGoogleFonts.add(fontName);
      resolve();
    }
  });
}

let isMultiSelectMode = false;
let selectedMultiRows = new Set();

const SHAPE_ITEMS = [
  { title: 'Kotak', shapeType: 'square', icon: 'crop_square', filename: 'Shape_Kotak.svg' },
  { title: 'Lingkaran', shapeType: 'circle', icon: 'radio_button_unchecked', filename: 'Shape_Lingkaran.svg' },
  { title: 'Segitiga', shapeType: 'triangle', icon: 'change_history', filename: 'Shape_Segitiga.svg' },
  { title: 'Bintang', shapeType: 'star', icon: 'star', filename: 'Shape_Bintang.svg' },
  { title: 'Bintang 4', shapeType: 'star-4', icon: 'star', filename: 'Shape_Bintang_4.svg' },
  { title: 'Love', shapeType: 'heart', icon: 'favorite', filename: 'Shape_Love.svg' },
  { title: 'Panah', shapeType: 'arrow', icon: 'arrow_forward', filename: 'Shape_Panah.svg' },
  { title: 'Segi Enam', shapeType: 'hexagon', icon: 'hexagon', filename: 'Shape_SegiEnam.svg' }
];

const SHAPE_PICKER_ITEMS = SHAPE_ITEMS;

var CATEGORY_ITEMS = null;
