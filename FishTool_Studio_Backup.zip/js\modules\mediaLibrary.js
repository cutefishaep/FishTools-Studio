const GLOBAL_MEDIA_STORAGE_KEY = 'fishTool_globalMediaLibrary';
let _globalMediaMemoryCache = null;

function initGlobalMediaLibrary() {
    if (_globalMediaMemoryCache !== null) return;
    _globalMediaMemoryCache = [];
    
    // 1. Initial lightweight read from localStorage
    try {
      const stored = localStorage.getItem(GLOBAL_MEDIA_STORAGE_KEY);
      if (stored) _globalMediaMemoryCache = JSON.parse(stored);
    } catch (e) {}

    // 2. Asynchronously sync all full video/audio/photo items from IndexedDB
    getMediaDB().then((db) => {
      if (!db) return;
      try {
        const tx = db.transaction('media_items', 'readonly');
        const store = tx.objectStore('media_items');
        const req = store.getAll();
        req.onsuccess = () => {
          if (req.result && req.result.length > 0) {
            const idbItems = req.result.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            idbItems.forEach(item => {
              // Generate fresh valid blob URL if item contains a stored binary Blob/File
              if (item.blob && (item.blob instanceof Blob || item.blob.size)) {
                item.url = URL.createObjectURL(item.blob);
              }
              const existingIdx = _globalMediaMemoryCache.findIndex(m => m.id === item.id || m.name === item.name);
              if (existingIdx >= 0) {
                _globalMediaMemoryCache[existingIdx] = { ..._globalMediaMemoryCache[existingIdx], ...item };
              } else {
                _globalMediaMemoryCache.push(item);
              }
            });
            if (typeof syncAllMediaGrids === 'function') syncAllMediaGrids();
            loadAllVideoPackagesFromIDB();

            // Re-bind all timeline layers that use this media with fresh blob/data URLs
            document.querySelectorAll('.track-row').forEach(row => {
              const id = row.dataset.layerId;
              if (id) {
                const fill = getLayerFill(id);
                if (fill && fill.type === 'media') {
                  const clipName = row.querySelector('.track-clip-name')?.textContent.trim() || '';
                  const match = _globalMediaMemoryCache.find(m => m.url === fill.mediaUrl || m.id === fill.mediaUrl || (clipName && m.name === clipName));
                  if (match && match.url) {
                    fill.mediaUrl = match.url;
                  }
                  applyFillToMeshGlobal(id);
                  applyTransformToThreeMesh(id, getLayerTransform(id));
                }
              }
            });
            render3D();
            if (typeof requestCanvasOverlayRender === 'function') {
              requestCanvasOverlayRender();
            } else if (typeof renderCanvasOverlay === 'function') {
              renderCanvasOverlay();
            }
          }
        };
      } catch (err) {
        console.warn('IndexedDB load error', err);
      }
    });
  }

  initGlobalMediaLibrary();

  function getGlobalMediaLibrary() {
    if (_globalMediaMemoryCache === null) {
      initGlobalMediaLibrary();
    }
    return _globalMediaMemoryCache || [];
  }

  function saveGlobalMediaLibrary(list) {
    _globalMediaMemoryCache = list || [];

    // Save full items (with raw binary Blob/File objects) to IndexedDB with unlimited capacity
    getMediaDB().then((db) => {
      if (!db) return;
      try {
        const tx = db.transaction('media_items', 'readwrite');
        const store = tx.objectStore('media_items');
        store.clear();
        (list || []).forEach(item => {
          store.put(item);
        });
      } catch (err) {
        console.warn('Failed saving to IndexedDB', err);
      }
    });

    // Safely sync lightweight metadata to localStorage without throwing quota error
    try {
      const lightList = (list || []).slice(0, 8).map(item => ({
        id: item.id,
        name: item.name,
        type: item.type,
        createdAt: item.createdAt,
        url: (item.url && item.url.startsWith('data:') && item.url.length < 300000) ? item.url : ''
      }));
      localStorage.setItem(GLOBAL_MEDIA_STORAGE_KEY, JSON.stringify(lightList));
    } catch (e) {
      // Ignored safely because IndexedDB holds the persistent media
    }
  }

  function addGlobalMedia(dataUrlOrBlob, name, type, fileBlob) {
    const list = getGlobalMediaLibrary();
    const isBlob = (dataUrlOrBlob instanceof Blob) || (fileBlob instanceof Blob);
    const blobObj = isBlob ? (fileBlob || dataUrlOrBlob) : null;
    const liveUrl = (typeof dataUrlOrBlob === 'string') ? dataUrlOrBlob : (blobObj ? URL.createObjectURL(blobObj) : '');

    const existingIdx = list.findIndex(m => (m.name === name) || (m.url === liveUrl && liveUrl !== ''));
    if (existingIdx >= 0) {
      const item = list.splice(existingIdx, 1)[0];
      item.url = liveUrl || item.url;
      if (blobObj) item.blob = blobObj;
      list.unshift(item);
      saveGlobalMediaLibrary(list);
      syncAllMediaGrids();
      return item;
    }

    const newItem = {
      id: 'media_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      url: liveUrl,
      blob: blobObj,
      name: name || ('Media_' + (list.length + 1)),
      type: type || 'image',
      createdAt: Date.now()
    };
    list.unshift(newItem);
    saveGlobalMediaLibrary(list);
    syncAllMediaGrids();
    return newItem;
  }

  function removeGlobalMedia(mediaId) {
    const list = getGlobalMediaLibrary();
    const removedItem = list.find(m => m.id === mediaId);
    const updatedList = list.filter(m => m.id !== mediaId);
    saveGlobalMediaLibrary(updatedList);
    syncAllMediaGrids();

    // Also remove package from IndexedDB video_packages store
    getMediaDB().then((db) => {
      if (!db) return;
      try {
        const tx = db.transaction('video_packages', 'readwrite');
        tx.objectStore('video_packages').delete(mediaId);
      } catch(_) {}
    });

    if (removedItem) {
      const removedUrl = removedItem.url;
      const removedName = removedItem.name;

      // Delete all track rows / layers in timeline using this deleted media
      const rows = Array.from(document.querySelectorAll('.track-row'));
      rows.forEach(row => {
        const id = row.dataset.layerId;
        const fill = id ? getLayerFill(id) : null;
        const clipName = row.querySelector('.track-clip-name')?.textContent.trim() || '';

        const isMatch = (
          (fill && fill.type === 'media' && (fill.mediaUrl === mediaId || fill.mediaUrl === removedUrl)) ||
          (clipName && (clipName === removedName || clipName === mediaId)) ||
          (row.dataset.mediaId === mediaId)
        );

        if (isMatch) {
          // Clean up 3D mesh
          const mesh = meshLayerMap.get(id);
          if (mesh && scene3D) {
            scene3D.remove(mesh);
            if (mesh.geometry) mesh.geometry.dispose();
            if (mesh.material) mesh.material.dispose();
            meshLayerMap.delete(id);
          }

          // Clean up audio
          const audio = layerAudioMap.get(id);
          if (audio) {
            audio.pause();
            audio.removeAttribute('src');
            layerAudioMap.delete(id);
          }

          // Clean up maps
          layerFills.delete(id);
          layerTransforms.delete(id);
          layerKeyframes.delete(id);
          layerMotionBlur.delete(id);
          layerFrameTextureMap.delete(id);
          layerLastRenderedFrameIndex.delete(id);
          videoFrameSequenceMap.delete(mediaId);
          if (removedUrl) videoFrameSequenceMap.delete(removedUrl);
          if (removedName) videoFrameSequenceMap.delete(removedName);

          // Remove row from DOM
          row.remove();
        }
      });

      if (selectedTrackRow && !document.contains(selectedTrackRow)) {
        selectedTrackRow = null;
        renderCanvasOverlay();
      }

      calculateMaxDuration();
      rebuildTimeRuler(totalDuration);
      syncThreeLayers();
      render3D();
      triggerAutoSave();
    }
  }

  function syncAllMediaGrids() {
    const mediaList = getGlobalMediaLibrary();
    
    // 1. Render in Color & Fill panel -> Media tab (#uploadedMediaGrid)
    const mediaGrid = document.getElementById('uploadedMediaGrid');
    if (mediaGrid) {
      mediaGrid.innerHTML = `
        <button type="button" id="btnUploadMedia" class="media-upload-tile-btn" title="Upload Media">
          <span class="material-symbols-rounded">add</span>
        </button>
      `;
      const btnUpload = mediaGrid.querySelector('#btnUploadMedia');
      const inputFillMedia = document.getElementById('inputFillMedia');
      if (btnUpload && inputFillMedia) {
        btnUpload.addEventListener('click', (e) => {
          e.stopPropagation();
          inputFillMedia.click();
        });
      }

      if (mediaList && mediaList.length > 0) {
        mediaList.forEach(item => {
          const thumb = createMediaThumbnailElement(item, (mediaItem) => {
            // Apply fill to currently selected layer
            if (selectedTrackRow) {
              const id = selectedTrackRow.dataset.layerId || 'default';
              const fill = getLayerFill(id);
              fill.type = 'media';
              fill.mediaUrl = mediaItem.id || mediaItem.url;
              fill.color = null;
              fill.gradientType = null;
              applyFillToMeshGlobal(id);
              triggerAutoSave();
            }
          });
          mediaGrid.appendChild(thumb);
        });
      }
    }

    // 2. If Add Track Popover is open on 'media' tab, update its items
    const popover = document.getElementById('addTrackPopover');
    const activeTab = document.querySelector('#popoverCategoryTabs .cat-tab-btn.active');
    if (popover && popover.classList.contains('active') && activeTab && activeTab.dataset.cat === 'media') {
      renderCategoryItems('media');
    }
  }

  function promptDeleteMedia(mediaItem, anchorEl) {
    if (window.FishPopover) {
      window.FishPopover.confirmDelete({
        anchorElement: anchorEl,
        onConfirm: () => {
          removeGlobalMedia(mediaItem.id);
        }
      });
    }
  }

  function createMediaThumbnailElement(item, onClick) {
    const btn = document.createElement('div');
    btn.className = 'media-thumb-item';
    btn.title = `${item.name}\n(Klik untuk gunakan, Tahan lama / Klik Kanan untuk hapus)`;

    const isVideo = (item.type && item.type.startsWith('video')) || (item.name && /\.(mp4|webm|mov|mkv)$/i.test(item.name));
    if (isVideo) {
      if (item.thumbnailUrl || (item.url && item.url.startsWith('data:image/'))) {
        const img = document.createElement('img');
        img.src = item.thumbnailUrl || item.url;
        img.alt = item.name;
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'cover';
        img.style.borderRadius = '12px';
        btn.appendChild(img);
      } else {
        const vid = document.createElement('video');
        vid.src = item.url;
        vid.muted = true;
        vid.playsInline = true;
        vid.preload = 'metadata';
        vid.style.width = '100%';
        vid.style.height = '100%';
        vid.style.objectFit = 'cover';
        vid.style.borderRadius = '12px';
        btn.appendChild(vid);
      }

      const playBadge = document.createElement('div');
      playBadge.style.cssText = 'position:absolute; inset:0; display:flex; align-items:center; justify-content:center; background:rgba(0,0,0,0.3); pointer-events:none; border-radius:12px;';
      playBadge.innerHTML = '<span class="material-symbols-rounded" style="font-size:22px; color:#FFF2C2;">play_circle</span>';
      btn.appendChild(playBadge);
    } else {
      const img = document.createElement('img');
      img.src = item.url;
      img.alt = item.name;
      btn.appendChild(img);
    }

    // Delete badge icon
    const delBadge = document.createElement('button');
    delBadge.type = 'button';
    delBadge.className = 'media-del-badge';
    delBadge.title = 'Hapus Media';
    delBadge.innerHTML = '<span class="material-symbols-rounded" style="font-size:14px;">close</span>';
    delBadge.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      removeGlobalMedia(item.id);
    });
    btn.appendChild(delBadge);

    // Long press and right click handlers
    let pressTimer = null;
    let isLongPress = false;

    const startPress = (e) => {
      isLongPress = false;
      btn.classList.add('holding-delete');
      pressTimer = setTimeout(() => {
        isLongPress = true;
        btn.classList.remove('holding-delete');
        if (navigator.vibrate) navigator.vibrate(35);
        promptDeleteMedia(item, btn);
      }, 450);
    };

    const cancelPress = () => {
      clearTimeout(pressTimer);
      btn.classList.remove('holding-delete');
    };

    btn.addEventListener('mousedown', (e) => {
      if (e.button === 2) {
        // Right click
        e.preventDefault();
        e.stopPropagation();
        cancelPress();
        promptDeleteMedia(item, btn);
        return;
      }
      startPress(e);
    });

    btn.addEventListener('touchstart', startPress, { passive: true });
    btn.addEventListener('touchend', cancelPress);
    btn.addEventListener('touchmove', cancelPress);
    btn.addEventListener('mouseup', cancelPress);
    btn.addEventListener('mouseleave', cancelPress);

    btn.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      e.stopPropagation();
      cancelPress();
      promptDeleteMedia(item, btn);
    });

    btn.addEventListener('click', (e) => {
      if (isLongPress) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      if (onClick) onClick(item);
    });

    return btn;
  }

const _notReadyTextureCacheMap = new Map();
function getNotReadyVideoTexture(aspectRatio = 1.7778) {
  const aspectKey = Math.round(Number(aspectRatio || 1.7778) * 100) / 100;
  if (_notReadyTextureCacheMap.has(aspectKey)) {
    return _notReadyTextureCacheMap.get(aspectKey);
  }

  let canvasW = 1280;
  let canvasH = 720;
  if (aspectRatio >= 1) {
    canvasW = 1280;
    canvasH = Math.max(200, Math.round(1280 / aspectRatio));
  } else {
    canvasH = 1280;
    canvasW = Math.max(200, Math.round(1280 * aspectRatio));
  }

  const canvas = document.createElement('canvas');
  canvas.width = canvasW;
  canvas.height = canvasH;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#22130C';
  ctx.fillRect(0, 0, canvasW, canvasH);

  ctx.strokeStyle = 'rgba(250, 183, 120, 0.35)';
  ctx.lineWidth = 4;
  ctx.strokeRect(12, 12, canvasW - 24, canvasH - 24);

  const cx = canvasW / 2;
  const cy = canvasH / 2;

  const fontSizeTitle = Math.max(20, Math.min(36, Math.round(canvasW * 0.048)));
  const fontSizeSub = Math.max(14, Math.min(22, Math.round(canvasW * 0.028)));

  ctx.fillStyle = '#FFF2C2';
  ctx.font = `bold ${fontSizeTitle}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('Media is not ready yet', cx, cy - fontSizeTitle * 0.8);

  ctx.fillStyle = '#FAB778';
  ctx.font = `600 ${fontSizeSub}px sans-serif`;
  ctx.fillText('Memproses frame sequence...', cx, cy + fontSizeSub * 1.2);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.generateMipmaps = false;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.flipY = true;

  _notReadyTextureCacheMap.set(aspectKey, tex);
  return tex;
}

async function saveVideoPackageToIDB(pkg) {
  const db = await getMediaDB();
  if (!db) return;
  try {
    const tx = db.transaction('video_packages', 'readwrite');
    const store = tx.objectStore('video_packages');
    store.put({
      id: pkg.id,
      name: pkg.name,
      manifest: {
        fps: pkg.fps,
        width: pkg.width,
        height: pkg.height,
        duration: pkg.duration,
        totalFrames: pkg.totalFrames,
        aspectRatio: pkg.aspectRatio,
        createdAt: Date.now()
      },
      frames: pkg.frameBlobs || [],
      audioBlob: pkg.audioBlob || null
    });
  } catch (e) {
    console.warn('Failed saving video package to IDB', e);
  }
}

async function loadAllVideoPackagesFromIDB() {
  // Legacy frame decoding removed in favor of hardware-accelerated video streaming
  return;
}
 // layerId -> THREE.CanvasTexture


function initTrackRows() {
  const loaded = loadSavedProject();
  if (!loaded) {
    document.querySelectorAll('.track-row').forEach((row, idx) => {
      if (!row.dataset.layerId) {
        row.dataset.layerId = 'layer_' + (idx + 1);
      }
      bindTrackEvents(row);
    });
    renderAllKeyframeMarkers();
  }
  saveCurrentProject();
}

function bindTrackEvents(row) {
  if (!row) return;
  if (row._eventsBound) return;
  row._eventsBound = true;

  if (!row.dataset.layerId) {
    const existing = document.querySelectorAll('.track-row');
    const idx = Array.from(existing).indexOf(row);
    row.dataset.layerId = 'layer_' + (idx >= 0 ? idx + 1 : Date.now());
  }

  if (row.dataset.tagColor && row.dataset.tagColor !== 'none') {
    const clip = row.querySelector('.track-clip');
    if (clip) clip.style.borderLeft = `5px solid ${row.dataset.tagColor}`;
  }

  renderKeyframeMarkersOnClip(row);

  const eyeBtn = row.querySelector('.track-eye');
  if (eyeBtn) {
    let eyeLongPressTimer = null;
    let isLongPressTriggered = false;
    let startX = 0;
    let startY = 0;
    let hasSwiped = false;

    const onEyePointerDown = (e) => {
      e.stopPropagation();
      isLongPressTriggered = false;
      hasSwiped = false;
      const pt = (e.touches && e.touches[0]) || e;
      startX = pt.clientX;
      startY = pt.clientY;

      if (!isMultiSelectMode) {
        eyeLongPressTimer = setTimeout(() => {
          isLongPressTriggered = true;
          enterMultiSelectMode(row);
          if (navigator.vibrate) navigator.vibrate(25);
        }, 220);
      }

      const onEyePointerMove = (me) => {
        const mpt = (me.touches && me.touches[0]) || me;
        const curX = mpt.clientX;
        const curY = mpt.clientY;
        const dist = Math.hypot(curX - startX, curY - startY);

        if (dist > 8) {
          if (!isMultiSelectMode && !isLongPressTriggered) {
            clearTimeout(eyeLongPressTimer);
            isLongPressTriggered = true;
            enterMultiSelectMode(row);
          }

          hasSwiped = true;
          const el = document.elementFromPoint(curX, curY);
          if (el) {
            const targetRow = el.closest('.track-row');
            if (targetRow && !selectedMultiRows.has(targetRow)) {
              selectedMultiRows.add(targetRow);
              targetRow.classList.add('multi-selected');
              const eye = targetRow.querySelector('.track-eye .material-symbols-rounded');
              if (eye) {
                eye.textContent = 'check';
                eye.style.color = '#082618';
              }
              if (navigator.vibrate) navigator.vibrate(12);
              updateMultiSelectUI();
            }
          }
        }
      };

      const onEyePointerUp = () => {
        clearTimeout(eyeLongPressTimer);
        window.removeEventListener('mousemove', onEyePointerMove);
        window.removeEventListener('mouseup', onEyePointerUp);
        window.removeEventListener('touchmove', onEyePointerMove);
        window.removeEventListener('touchend', onEyePointerUp);

        if (!hasSwiped && !isLongPressTriggered) {
          if (isMultiSelectMode) {
            toggleRowMultiSelect(row);
          } else {
            toggleEye(eyeBtn, true);
          }
        }
      };

      window.addEventListener('mousemove', onEyePointerMove);
      window.addEventListener('mouseup', onEyePointerUp);
      window.addEventListener('touchmove', onEyePointerMove, { passive: false });
      window.addEventListener('touchend', onEyePointerUp);
    };

    eyeBtn.addEventListener('mousedown', onEyePointerDown);
    eyeBtn.addEventListener('touchstart', onEyePointerDown, { passive: false });
  }

  const handle = row.querySelector('.track-reorder-handle');
  if (handle) {
    initTrackReorder(row, handle);
  }

  const clip = row.querySelector('.track-clip');
  if (clip) {
    let longPressTimer = null;
    let isHolding = false;
    let didScrub = false;
    let startX = 0;
    let startY = 0;
    let startMargin = 0;
    let startOffset = 0;
    let startScrollTop = 0;

    const onPointerDown = (e) => {
      if (e.target.closest('.clip-extend-handle') || e.target.closest('.clip-keyframe-marker') || e.target.closest('.clip-keyframes-container')) return;

      e.stopPropagation();
      const viewport = document.getElementById('tracksViewport');
      const pointerX = e.pageX || (e.touches && e.touches[0].pageX) || 0;
      const pointerY = e.pageY || (e.touches && e.touches[0].pageY) || 0;
      startX = pointerX;
      startY = pointerY;
      startMargin = parseFloat(clip.style.marginLeft) || 0;
      startOffset = timelineOffset;
      startScrollTop = viewport ? viewport.scrollTop : 0;
      isHolding = false;
      didScrub = false;

      longPressTimer = setTimeout(() => {
        isHolding = true;
        clip.classList.add('clip-holding');
        if (navigator.vibrate) navigator.vibrate(20);
      }, 220);

      const onPointerMove = (me) => {
        const curX = me.pageX || (me.touches && me.touches[0].pageX) || 0;
        const curY = me.pageY || (me.touches && me.touches[0].pageY) || 0;
        const dx = curX - startX;
        const dy = curY - startY;

        if (!isHolding) {
          if (Math.abs(dx) > 3 || (!selectedTrackRow && Math.abs(dy) > 3)) {
            clearTimeout(longPressTimer);
            didScrub = true;
          }
          if (didScrub) {
            me.preventDefault();
            setTimelineOffset(startOffset - dx);
            if (viewport && !selectedTrackRow) {
              viewport.scrollTop = startScrollTop - dy;
            }
          }
          return;
        }

        me.preventDefault();
        const newMargin = Math.max(0, startMargin + dx);
        clip.style.marginLeft = `${newMargin}px`;
      };

      const onPointerUp = () => {
        clearTimeout(longPressTimer);
        window.removeEventListener('mousemove', onPointerMove);
        window.removeEventListener('mouseup', onPointerUp);
        window.removeEventListener('touchmove', onPointerMove);
        window.removeEventListener('touchend', onPointerUp);

        if (isHolding) {
          isHolding = false;
          clip.classList.remove('clip-holding');
          const finalMargin = parseFloat(clip.style.marginLeft) || 0;
          if (Math.abs(finalMargin - startMargin) > 2) {
            recordAction({
              type: 'MOVE_CLIP',
              clip: clip,
              oldMargin: startMargin,
              newMargin: finalMargin
            });
            calculateMaxDuration();
          }
        } else if (!didScrub) {
          if (isMultiSelectMode) {
            toggleRowMultiSelect(row);
          } else {
            selectTrack(row);
          }
        }
      };

      window.addEventListener('mousemove', onPointerMove);
      window.addEventListener('mouseup', onPointerUp);
      window.addEventListener('touchmove', onPointerMove, { passive: false });
      window.addEventListener('touchend', onPointerUp);
    };

    clip.addEventListener('mousedown', onPointerDown);
    clip.addEventListener('touchstart', onPointerDown, { passive: false });

    const handleLeft = row.querySelector('.clip-extend-handle.handle-left');
    const handleRight = row.querySelector('.clip-extend-handle.handle-right');

    if (handleLeft) {
      const onLeftHandleDown = (e) => {
        e.stopPropagation();
        e.preventDefault();
        const pointerX = e.pageX || (e.touches && e.touches[0].pageX) || 0;
        const startX = pointerX;
        const startMargin = parseFloat(clip.style.marginLeft) || 0;
        const startWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
        const startEnd = startMargin + startWidth;

        const onLeftMove = (me) => {
          const curX = me.pageX || (me.touches && me.touches[0].pageX) || 0;
          const dx = curX - startX;
          const newMargin = Math.max(0, Math.min(startEnd - 20, startMargin + dx));
          const newWidth = startEnd - newMargin;
          clip.style.marginLeft = `${newMargin}px`;
          clip.style.width = `${newWidth}px`;
        };

        const onLeftUp = () => {
          window.removeEventListener('mousemove', onLeftMove);
          window.removeEventListener('mouseup', onLeftUp);
          window.removeEventListener('touchmove', onLeftMove);
          window.removeEventListener('touchend', onLeftUp);

          const finalMargin = parseFloat(clip.style.marginLeft) || 0;
          const finalWidth = parseFloat(clip.style.width) || 300;
          if (Math.abs(finalMargin - startMargin) > 2) {
            recordAction({
              type: 'TRIM_CLIP',
              clip: clip,
              oldMargin: startMargin,
              oldWidth: startWidth,
              newMargin: finalMargin,
              newWidth: finalWidth
            });
            calculateMaxDuration();
            updateInspectorQuickButtons();
          }
        };

        window.addEventListener('mousemove', onLeftMove);
        window.addEventListener('mouseup', onLeftUp);
        window.addEventListener('touchmove', onLeftMove, { passive: false });
        window.addEventListener('touchend', onLeftUp);
      };

      handleLeft.addEventListener('mousedown', onLeftHandleDown);
      handleLeft.addEventListener('touchstart', onLeftHandleDown, { passive: false });
    }

    if (handleRight) {
      const onRightHandleDown = (e) => {
        e.stopPropagation();
        e.preventDefault();
        const pointerX = e.pageX || (e.touches && e.touches[0].pageX) || 0;
        const startX = pointerX;
        const startMargin = parseFloat(clip.style.marginLeft) || 0;
        const startWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;

        const onRightMove = (me) => {
          const curX = me.pageX || (me.touches && me.touches[0].pageX) || 0;
          const dx = curX - startX;
          const newWidth = Math.max(20, startWidth + dx);
          clip.style.width = `${newWidth}px`;
        };

        const onRightUp = () => {
          window.removeEventListener('mousemove', onRightMove);
          window.removeEventListener('mouseup', onRightUp);
          window.removeEventListener('touchmove', onRightMove);
          window.removeEventListener('touchend', onRightUp);

          const finalWidth = parseFloat(clip.style.width) || 300;
          if (Math.abs(finalWidth - startWidth) > 2) {
            recordAction({
              type: 'TRIM_CLIP',
              clip: clip,
              oldMargin: startMargin,
              oldWidth: startWidth,
              newMargin: startMargin,
              newWidth: finalWidth
            });
            calculateMaxDuration();
            updateInspectorQuickButtons();
          }
        };

        window.addEventListener('mousemove', onRightMove);
        window.addEventListener('mouseup', onRightUp);
        window.addEventListener('touchmove', onRightMove, { passive: false });
        window.addEventListener('touchend', onRightUp);
      };

      handleRight.addEventListener('mousedown', onRightHandleDown);
      handleRight.addEventListener('touchstart', onRightHandleDown, { passive: false });
    }
  }

  row.addEventListener('contextmenu', (e) => {
    openLayerContextMenu(e, row);
  });
}




function enterMultiSelectMode(initialRow) {
  if (isMultiSelectMode) return;
  deselectTrack();

  isMultiSelectMode = true;
  document.body.classList.add('multi-select-mode');
  selectedMultiRows.clear();

  if (initialRow) {
    toggleRowMultiSelect(initialRow, true);
  }

  updateMultiSelectUI();
}

function exitMultiSelectMode() {
  if (!isMultiSelectMode) return;
  isMultiSelectMode = false;
  document.body.classList.remove('multi-select-mode');

  selectedMultiRows.forEach(row => {
    row.classList.remove('multi-selected');
  });
  selectedMultiRows.clear();

  document.querySelectorAll('.track-row').forEach(r => {
    r.classList.remove('multi-selected');
    const eyeBtn = r.querySelector('.track-eye');
    if (eyeBtn) {
      const icon = eyeBtn.querySelector('.material-symbols-rounded');
      const trackway = eyeBtn.nextElementSibling;
      const isHidden = trackway && trackway.style.opacity === '0.35';
      if (icon) {
        icon.textContent = isHidden ? 'visibility_off' : 'visibility';
        icon.style.color = isHidden ? 'rgba(255, 240, 194, 0.4)' : 'var(--col-yellow)';
      }
    }
  });

  const header = document.getElementById('multiSelectHeaderBar');
  const footer = document.getElementById('multiSelectFooterBar');
  const alignSub = document.getElementById('multiHeaderAlign');
  const mainSub = document.getElementById('multiHeaderMain');

  if (header) header.classList.remove('active');
  if (footer) footer.classList.remove('active');
  if (alignSub) alignSub.classList.remove('active');
  if (mainSub) mainSub.classList.remove('hidden-sub');
}

function toggleRowMultiSelect(row, forceState) {
  const shouldSelect = (forceState !== undefined) ? forceState : !selectedMultiRows.has(row);

  if (shouldSelect) {
    selectedMultiRows.add(row);
    row.classList.add('multi-selected');
    const eyeIcon = row.querySelector('.track-eye .material-symbols-rounded');
    if (eyeIcon) eyeIcon.textContent = 'check';
  } else {
    selectedMultiRows.delete(row);
    row.classList.remove('multi-selected');
    const eyeIcon = row.querySelector('.track-eye .material-symbols-rounded');
    if (eyeIcon) eyeIcon.textContent = 'radio_button_unchecked';
  }

  if (selectedMultiRows.size === 0) {
    exitMultiSelectMode();
  } else {
    updateMultiSelectUI();
  }
}

function updateMultiSelectUI() {
  const header = document.getElementById('multiSelectHeaderBar');
  const footer = document.getElementById('multiSelectFooterBar');
  const countEl = document.getElementById('multiSelectCount');

  if (header) header.classList.add('active');
  if (footer) footer.classList.add('active');

  const count = selectedMultiRows.size;
  if (countEl) {
    countEl.textContent = `${count} ${count === 1 ? 'layer' : 'layers'} selected`;
  }

  document.querySelectorAll('.track-row').forEach(row => {
    const eyeIcon = row.querySelector('.track-eye .material-symbols-rounded');
    if (eyeIcon) {
      if (selectedMultiRows.has(row)) {
        eyeIcon.textContent = 'check';
        eyeIcon.style.color = '#082618';
      } else {
        eyeIcon.textContent = 'radio_button_unchecked';
        eyeIcon.style.color = 'var(--col-yellow)';
      }
    }
  });

  updateMultiSelectQuickButtons();
}

function selectAllLayers() {
  const rows = document.querySelectorAll('.track-row');
  if (rows.length === 0) return;

  if (!isMultiSelectMode) {
    enterMultiSelectMode();
  }

  const allSelected = Array.from(rows).every(r => selectedMultiRows.has(r));
  if (allSelected) {
    exitMultiSelectMode();
  } else {
    rows.forEach(r => {
      selectedMultiRows.add(r);
      r.classList.add('multi-selected');
      const eye = r.querySelector('.track-eye .material-symbols-rounded');
      if (eye) {
        eye.textContent = 'check';
        eye.style.color = '#082618';
      }
    });
    updateMultiSelectUI();
  }
}

function selectOtherLayers() {
  const rows = document.querySelectorAll('.track-row');
  if (rows.length === 0) return;

  if (!isMultiSelectMode) {
    enterMultiSelectMode();
  }

  rows.forEach(r => {
    if (selectedMultiRows.has(r)) {
      selectedMultiRows.delete(r);
      r.classList.remove('multi-selected');
      const eye = r.querySelector('.track-eye .material-symbols-rounded');
      if (eye) {
        eye.textContent = 'radio_button_unchecked';
        eye.style.color = 'var(--col-yellow)';
      }
    } else {
      selectedMultiRows.add(r);
      r.classList.add('multi-selected');
      const eye = r.querySelector('.track-eye .material-symbols-rounded');
      if (eye) {
        eye.textContent = 'check';
        eye.style.color = '#082618';
      }
    }
  });

  if (selectedMultiRows.size === 0) {
    exitMultiSelectMode();
  } else {
    updateMultiSelectUI();
  }
}

function initMultiSelectControls() {
  const btnExit = document.getElementById('btnExitMultiSelect');
  const btnExitAlign = document.getElementById('btnExitMultiSelectFromAlign');
  if (btnExit) btnExit.addEventListener('click', exitMultiSelectMode);
  if (btnExitAlign) btnExitAlign.addEventListener('click', exitMultiSelectMode);

  const btnSelectAll = document.getElementById('btnSelectAllLayers');
  if (btnSelectAll) {
    btnSelectAll.addEventListener('click', (e) => {
      e.stopPropagation();
      selectAllLayers();
    });
  }

  const btnToggleAlign = document.getElementById('btnToggleAlignMenu');
  const btnBackGroup = document.getElementById('btnBackToGroupMenu');
  const mainHeader = document.getElementById('multiHeaderMain');
  const alignHeader = document.getElementById('multiHeaderAlign');

  if (btnToggleAlign && mainHeader && alignHeader) {
    btnToggleAlign.addEventListener('click', (e) => {
      e.stopPropagation();
      mainHeader.classList.add('hidden-sub');
      alignHeader.classList.add('active');
    });
  }

  if (btnBackGroup && mainHeader && alignHeader) {
    btnBackGroup.addEventListener('click', (e) => {
      e.stopPropagation();
      alignHeader.classList.remove('active');
      mainHeader.classList.remove('hidden-sub');
    });
  }

  const btnDeleteBatch = document.getElementById('btnDeleteSelectedBatch');
  if (btnDeleteBatch) {
    btnDeleteBatch.addEventListener('click', (e) => {
      e.stopPropagation();
      if (selectedMultiRows.size === 0) return;
      beginUndoGroup('Batch Delete Layers');
      try {
        const rowsToDelete = Array.from(selectedMultiRows);
        rowsToDelete.forEach(row => {
          const layerId = row.dataset.layerId;
          row.classList.add('deleting');
          setTimeout(() => {
            row.remove();
            cleanupDeletedLayerData(layerId);
          }, 250);
        });
        setTimeout(() => {
          exitMultiSelectMode();
          calculateMaxDuration();
          syncThreeLayers();
          renderCanvasOverlay();
          saveCurrentProject();
        }, 270);
      } finally {
        endUndoGroup();
      }
    });
  }

  const btnGroup = document.getElementById('btnGroupSelected');
  if (btnGroup) {
    btnGroup.addEventListener('click', (e) => {
      e.stopPropagation();
      if (selectedMultiRows.size === 0) return;
      beginUndoGroup('Group Layers');
      try {
        addTrackWithType('camera', `Group (${selectedMultiRows.size} layers)`);
        exitMultiSelectMode();
      } finally {
        endUndoGroup();
      }
    });
  }

  const btnMaskGroup = document.getElementById('btnMaskGroupSelected');
  if (btnMaskGroup) {
    btnMaskGroup.addEventListener('click', (e) => {
      e.stopPropagation();
      if (selectedMultiRows.size === 0) return;
      beginUndoGroup('Mask Group');
      try {
        addTrackWithType('shape', `Mask Group`);
        exitMultiSelectMode();
      } finally {
        endUndoGroup();
      }
    });
  }

  const btnExcludeGroup = document.getElementById('btnExcludeGroupSelected');
  if (btnExcludeGroup) {
    btnExcludeGroup.addEventListener('click', (e) => {
      e.stopPropagation();
      if (selectedMultiRows.size === 0) return;
      beginUndoGroup('Exclude Group');
      try {
        addTrackWithType('shape', `Exclude Group`);
        exitMultiSelectMode();
      } finally {
        endUndoGroup();
      }
    });
  }

  document.querySelectorAll('#multiHeaderAlign [data-align]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const alignType = btn.getAttribute('data-align');
      executeBatchAlign(alignType);
    });
  });

  const btnAlignStart = document.getElementById('btnBatchAlignStart');
  if (btnAlignStart) {
    btnAlignStart.addEventListener('click', (e) => {
      e.stopPropagation();
      beginUndoGroup('Batch Align Start');
      try {
        selectedMultiRows.forEach(row => {
          const clip = row.querySelector('.track-clip');
          if (clip) {
            clip.style.marginLeft = `${timelineOffset}px`;
          }
        });
        calculateMaxDuration();
        syncThreeLayers();
      } finally {
        endUndoGroup();
      }
    });
  }

  const btnStaircase = document.getElementById('btnBatchStaircase');
  if (btnStaircase) {
    btnStaircase.addEventListener('click', (e) => {
      e.stopPropagation();
      beginUndoGroup('Batch Staircase Alignment');
      try {
        const arr = Array.from(selectedMultiRows);
        let curStart = timelineOffset;
        arr.forEach(row => {
          const clip = row.querySelector('.track-clip');
          if (clip) {
            const w = parseFloat(clip.style.width) || clip.offsetWidth || 240;
            clip.style.marginLeft = `${curStart}px`;
            curStart += w;
          }
        });
        calculateMaxDuration();
        syncThreeLayers();
      } finally {
        endUndoGroup();
      }
    });
  }

  const btnAlignEnd = document.getElementById('btnBatchAlignEnd');
  if (btnAlignEnd) {
    btnAlignEnd.addEventListener('click', (e) => {
      e.stopPropagation();
      beginUndoGroup('Batch Align End');
      try {
        selectedMultiRows.forEach(row => {
          const clip = row.querySelector('.track-clip');
          if (clip) {
            const w = parseFloat(clip.style.width) || clip.offsetWidth || 240;
            clip.style.marginLeft = `${Math.max(0, timelineOffset - w)}px`;
          }
        });
        calculateMaxDuration();
        syncThreeLayers();
      } finally {
        endUndoGroup();
      }
    });
  }

  updateMultiSelectQuickButtons();
}

function updateMultiSelectQuickButtons() {
  if (!isMultiSelectMode || selectedMultiRows.size === 0) return;

  let minMargin = Infinity;
  let maxEnd = -Infinity;

  selectedMultiRows.forEach(row => {
    const clip = row.querySelector('.track-clip');
    if (clip) {
      const m = parseFloat(clip.style.marginLeft) || 0;
      const w = parseFloat(clip.style.width) || clip.offsetWidth || 300;
      if (m < minMargin) minMargin = m;
      if (m + w > maxEnd) maxEnd = m + w;
    }
  });

  const btnLeft = document.getElementById('btnBatchTrimLeft');
  const btnSplit = document.getElementById('btnBatchSplit');
  const btnRight = document.getElementById('btnBatchTrimRight');

  if (!btnLeft || !btnSplit || !btnRight) return;

  if (timelineOffset > maxEnd + 0.5) {
    btnSplit.style.display = 'none';
    btnLeft.style.display = 'flex';
    btnRight.style.display = 'flex';

    btnLeft.title = "Panjangkan / Extend Semua Layer Terpilih ke Playhead";
    btnLeft.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="20" y1="3" x2="20" y2="21" stroke-width="1.9"/>
        <path d="M4 8.5h5" stroke-dasharray="2 2"/>
        <path d="M4 15.5h5" stroke-dasharray="2 2"/>
        <path d="M4 8.5v7" stroke-dasharray="2 2"/>
        <path d="M9 8.5h11v7H9"/>
      </svg>
    `;
    btnLeft.onclick = (e) => {
      e.stopPropagation();
      executeBatchExtendRightToPlayhead();
    };

    btnRight.title = "Geser Semua Layer Terpilih sampai ke Playhead (Move to Playhead)";
    btnRight.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="20" y1="3" x2="20" y2="21" stroke-width="1.9"/>
        <rect x="4" y="8.5" width="8" height="7" rx="1.5"/>
        <line x1="12" y1="12" x2="19" y2="12"/>
        <polyline points="16 9.5 19 12 16 14.5"/>
      </svg>
    `;
    btnRight.onclick = (e) => {
      e.stopPropagation();
      executeBatchMoveRightToPlayhead();
    };

  } else if (timelineOffset < minMargin - 0.5) {
    btnSplit.style.display = 'none';
    btnLeft.style.display = 'flex';
    btnRight.style.display = 'flex';

    btnLeft.title = "Geser Semua Layer Terpilih dari awal Playhead (Move to Playhead)";
    btnLeft.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="4" y1="3" x2="4" y2="21" stroke-width="1.9"/>
        <rect x="12" y="8.5" width="8" height="7" rx="1.5"/>
        <line x1="12" y1="12" x2="5" y2="12"/>
        <polyline points="8 9.5 5 12 8 14.5"/>
      </svg>
    `;
    btnLeft.onclick = (e) => {
      e.stopPropagation();
      executeBatchMoveLeftToPlayhead();
    };

    btnRight.title = "Panjangkan / Extend Semua Layer Terpilih mundur ke Playhead";
    btnRight.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="4" y1="3" x2="4" y2="21" stroke-width="1.9"/>
        <path d="M4 8.5h11v7H4"/>
        <path d="M15 8.5h5" stroke-dasharray="2 2"/>
        <path d="M15 15.5h5" stroke-dasharray="2 2"/>
        <path d="M20 8.5v7" stroke-dasharray="2 2"/>
      </svg>
    `;
    btnRight.onclick = (e) => {
      e.stopPropagation();
      executeBatchExtendLeftToPlayhead();
    };

  } else {
    btnSplit.style.display = 'flex';
    btnLeft.style.display = 'flex';
    btnRight.style.display = 'flex';

    btnLeft.title = "Potong Kiri Semua Layer Terpilih ke Playhead";
    btnLeft.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="3" x2="12" y2="21" stroke-width="1.9"/>
        <path d="M4 8.5h4.5v7H4" stroke-dasharray="2 2"/>
        <path d="M15.5 8.5H20v7h-4.5"/>
      </svg>
    `;
    btnLeft.onclick = (e) => {
      e.stopPropagation();
      beginUndoGroup('Batch Trim Left');
      try {
        selectedMultiRows.forEach(row => {
          executeTrimLeftOnRow(row, false);
        });
        calculateMaxDuration();
        updateMultiSelectQuickButtons();
        syncThreeLayers();
      } finally {
        endUndoGroup();
      }
    };

    btnSplit.title = "Bagi Semua Layer Terpilih di Playhead";
    btnSplit.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="3" x2="12" y2="21" stroke-width="1.9"/>
        <path d="M8.5 8.5H4v7h4.5"/>
        <path d="M15.5 8.5H20v7h-4.5"/>
      </svg>
    `;
    btnSplit.onclick = (e) => {
      e.stopPropagation();
      beginUndoGroup('Batch Split');
      try {
        const rows = Array.from(selectedMultiRows);
        rows.forEach(row => {
          const res = executeSplitOnRow(row, false);
          if (res && res.newRow) {
            selectedMultiRows.add(res.newRow);
            res.newRow.classList.add('multi-selected');
          }
        });
        updateMultiSelectUI();
        calculateMaxDuration();
        syncThreeLayers();
      } finally {
        endUndoGroup();
      }
    };

    btnRight.title = "Potong Kanan Semua Layer Terpilih ke Playhead";
    btnRight.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <line x1="12" y1="3" x2="12" y2="21" stroke-width="1.9"/>
        <path d="M8.5 8.5H4v7h4.5"/>
        <path d="M20 8.5h-4.5v7H20" stroke-dasharray="2 2"/>
      </svg>
    `;
    btnRight.onclick = (e) => {
      e.stopPropagation();
      beginUndoGroup('Batch Trim Right');
      try {
        selectedMultiRows.forEach(row => {
          executeTrimRightOnRow(row, false);
        });
        calculateMaxDuration();
        updateMultiSelectQuickButtons();
        syncThreeLayers();
      } finally {
        endUndoGroup();
      }
    };
  }
}

function executeBatchExtendRightToPlayhead() {
  beginUndoGroup('Batch Extend Right');
  try {
    selectedMultiRows.forEach(row => {
      const clip = row.querySelector('.track-clip');
      if (clip) {
        const curMargin = parseFloat(clip.style.marginLeft) || 0;
        const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
        if (timelineOffset >= curMargin + curWidth) {
          const newWidth = Math.max(20, timelineOffset - curMargin);
          clip.style.width = `${newWidth}px`;
        }
      }
    });
    calculateMaxDuration();
    updateMultiSelectQuickButtons();
    syncThreeLayers();
  } finally {
    endUndoGroup();
  }
}

function executeBatchMoveRightToPlayhead() {
  beginUndoGroup('Batch Move Right');
  try {
    selectedMultiRows.forEach(row => {
      const clip = row.querySelector('.track-clip');
      if (clip) {
        const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
        clip.style.marginLeft = `${Math.max(0, timelineOffset - curWidth)}px`;
      }
    });
    calculateMaxDuration();
    updateMultiSelectQuickButtons();
    syncThreeLayers();
  } finally {
    endUndoGroup();
  }
}

function executeBatchMoveLeftToPlayhead() {
  beginUndoGroup('Batch Move Left');
  try {
    selectedMultiRows.forEach(row => {
      const clip = row.querySelector('.track-clip');
      if (clip) {
        clip.style.marginLeft = `${Math.max(0, timelineOffset)}px`;
      }
    });
    calculateMaxDuration();
    updateMultiSelectQuickButtons();
    syncThreeLayers();
  } finally {
    endUndoGroup();
  }
}

function executeBatchExtendLeftToPlayhead() {
  beginUndoGroup('Batch Extend Left');
  try {
    selectedMultiRows.forEach(row => {
      const clip = row.querySelector('.track-clip');
      if (clip) {
        const curMargin = parseFloat(clip.style.marginLeft) || 0;
        const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
        const curEnd = curMargin + curWidth;
        if (timelineOffset <= curMargin) {
          const newMargin = Math.max(0, timelineOffset);
          const newWidth = Math.max(20, curEnd - newMargin);
          clip.style.marginLeft = `${newMargin}px`;
          clip.style.width = `${newWidth}px`;
        }
      }
    });
    calculateMaxDuration();
    updateMultiSelectQuickButtons();
    syncThreeLayers();
  } finally {
    endUndoGroup();
  }
}

function executeBatchAlign(type) {
  if (selectedMultiRows.size === 0) return;
  const rows = Array.from(selectedMultiRows);

  if (type === 'left') {
    let minMargin = Infinity;
    rows.forEach(r => {
      const clip = r.querySelector('.track-clip');
      if (clip) {
        const m = parseFloat(clip.style.marginLeft) || 0;
        if (m < minMargin) minMargin = m;
      }
    });
    if (minMargin !== Infinity) {
      rows.forEach(r => {
        const clip = r.querySelector('.track-clip');
        if (clip) clip.style.marginLeft = `${minMargin}px`;
      });
    }
  } else if (type === 'center') {
    let sumCenter = 0;
    rows.forEach(r => {
      const clip = r.querySelector('.track-clip');
      if (clip) {
        const m = parseFloat(clip.style.marginLeft) || 0;
        const w = parseFloat(clip.style.width) || clip.offsetWidth || 200;
        sumCenter += (m + w / 2);
      }
    });
    const avgCenter = sumCenter / rows.length;
    rows.forEach(r => {
      const clip = r.querySelector('.track-clip');
      if (clip) {
        const w = parseFloat(clip.style.width) || clip.offsetWidth || 200;
        clip.style.marginLeft = `${Math.max(0, avgCenter - w / 2)}px`;
      }
    });
  } else if (type === 'right') {
    let maxEnd = 0;
    rows.forEach(r => {
      const clip = r.querySelector('.track-clip');
      if (clip) {
        const m = parseFloat(clip.style.marginLeft) || 0;
        const w = parseFloat(clip.style.width) || clip.offsetWidth || 200;
        if (m + w > maxEnd) maxEnd = m + w;
      }
    });
    rows.forEach(r => {
      const clip = r.querySelector('.track-clip');
      if (clip) {
        const w = parseFloat(clip.style.width) || clip.offsetWidth || 200;
        clip.style.marginLeft = `${Math.max(0, maxEnd - w)}px`;
      }
    });
  } else if (type === 'dist-h') {
    if (rows.length > 2) {
      let minStart = Infinity, maxStart = 0;
      rows.forEach(r => {
        const clip = r.querySelector('.track-clip');
        if (clip) {
          const m = parseFloat(clip.style.marginLeft) || 0;
          if (m < minStart) minStart = m;
          if (m > maxStart) maxStart = m;
        }
      });
      const step = (maxStart - minStart) / (rows.length - 1);
      rows.forEach((r, idx) => {
        const clip = r.querySelector('.track-clip');
        if (clip) clip.style.marginLeft = `${minStart + idx * step}px`;
      });
    }
  }

  calculateMaxDuration();
}

function spawnFallingCutFragment(clip, discardedRect, direction = 'left') {
  if (!clip || !discardedRect || discardedRect.width <= 0) return;

  const fragment = document.createElement('div');
  fragment.className = `cut-physics-fragment dir-${direction}`;
  
  const computed = window.getComputedStyle(clip);
  fragment.style.left = `${discardedRect.left}px`;
  fragment.style.top = `${discardedRect.top}px`;
  fragment.style.width = `${discardedRect.width}px`;
  fragment.style.height = `${discardedRect.height}px`;
  
  if (computed.backgroundColor && computed.backgroundColor !== 'rgba(0, 0, 0, 0)') {
    fragment.style.backgroundColor = computed.backgroundColor;
  }
  if (computed.background) fragment.style.background = computed.background;
  fragment.style.borderRadius = computed.borderRadius || '12px';
  fragment.style.borderLeft = computed.borderLeft;
  fragment.style.boxShadow = 'none';
  fragment.style.filter = 'none';

  const name = clip.querySelector('.track-clip-name')?.textContent || '';
  if (name && discardedRect.width > 35) {
    const span = document.createElement('span');
    span.textContent = name;
    span.style.color = computed.color || '#FFF2C2';
    span.style.fontWeight = '800';
    span.style.fontSize = '0.8rem';
    span.style.padding = '0 0.85rem';
    span.style.display = 'flex';
    span.style.alignItems = 'center';
    span.style.height = '100%';
    span.style.whiteSpace = 'nowrap';
    span.style.overflow = 'hidden';
    span.style.textOverflow = 'ellipsis';
    fragment.appendChild(span);
  }

  document.body.appendChild(fragment);
  setTimeout(() => fragment.remove(), 420);
}

function spawnCutFragment(row, marginLeft, width, direction = 'left') {
  if (!row || width <= 0) return;
  const clip = row.querySelector('.track-clip');
  if (!clip) return;
  const clipRect = clip.getBoundingClientRect();
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
  const ratio = clipRect.width / curWidth;
  const discardedPx = Math.max(1, width * ratio);

  spawnFallingCutFragment(clip, {
    left: clipRect.left,
    top: clipRect.top,
    width: discardedPx,
    height: clipRect.height
  }, direction);
}

function spawnSplitEffect(trackway, offset) {
  if (!trackway) return;
  const flash = document.createElement('div');
  flash.className = 'cut-split-flash';
  flash.style.left = `calc(50% - 52px + ${offset}px)`;
  trackway.appendChild(flash);
  setTimeout(() => flash.remove(), 260);
}

function executeTrimLeftOnRow(row, shouldRecord = true) {
  if (!row) return null;
  const clip = row.querySelector('.track-clip');
  const trackway = row.querySelector('.track-trackway');
  if (!clip || !trackway) return null;

  const curMargin = parseFloat(clip.style.marginLeft) || 0;
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
  const curEnd = curMargin + curWidth;

  if (timelineOffset > curMargin && timelineOffset < curEnd) {
    if (shouldRecord) beginUndoGroup('Trim Left');
    try {
      const discardedWidth = timelineOffset - curMargin;
      const clipRect = clip.getBoundingClientRect();
      const ratio = clipRect.width / curWidth;
      const discardedPx = Math.max(1, discardedWidth * ratio);

      spawnFallingCutFragment(clip, {
        left: clipRect.left,
        top: clipRect.top,
        width: discardedPx,
        height: clipRect.height
      }, 'left');

      const newMargin = timelineOffset;
      const newWidth = Math.max(20, curEnd - timelineOffset);

      clip.style.marginLeft = `${newMargin}px`;
      clip.style.width = `${newWidth}px`;

      const recordData = {
        clip: clip,
        oldMargin: curMargin,
        oldWidth: curWidth,
        newMargin: newMargin,
        newWidth: newWidth
      };

      if (shouldRecord) calculateMaxDuration();

      syncThreeLayers();
      renderCanvasOverlay();
      return recordData;
    } finally {
      if (shouldRecord) endUndoGroup();
    }
  }
  return null;
}

function executeTrimRightOnRow(row, shouldRecord = true) {
  if (!row) return null;
  const clip = row.querySelector('.track-clip');
  const trackway = row.querySelector('.track-trackway');
  if (!clip || !trackway) return null;

  const curMargin = parseFloat(clip.style.marginLeft) || 0;
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
  const curEnd = curMargin + curWidth;

  if (timelineOffset > curMargin && timelineOffset < curEnd) {
    if (shouldRecord) beginUndoGroup('Trim Right');
    try {
      const discardedWidth = curEnd - timelineOffset;
      const clipRect = clip.getBoundingClientRect();
      const ratio = clipRect.width / curWidth;
      const remainingPx = (timelineOffset - curMargin) * ratio;
      const discardedPx = Math.max(1, discardedWidth * ratio);

      spawnFallingCutFragment(clip, {
        left: clipRect.left + remainingPx,
        top: clipRect.top,
        width: discardedPx,
        height: clipRect.height
      }, 'right');

      const newWidth = Math.max(20, timelineOffset - curMargin);

      clip.style.width = `${newWidth}px`;

      const recordData = {
        clip: clip,
        oldMargin: curMargin,
        oldWidth: curWidth,
        newMargin: curMargin,
        newWidth: newWidth
      };

      if (shouldRecord) calculateMaxDuration();

      syncThreeLayers();
      renderCanvasOverlay();
      return recordData;
    } finally {
      if (shouldRecord) endUndoGroup();
    }
  }
  return null;
}

function executeSplitOnRow(row, shouldRecord = true) {
  if (!row) return null;
  const clip = row.querySelector('.track-clip');
  const trackway = row.querySelector('.track-trackway');
  if (!clip || !trackway) return null;

  const curMargin = parseFloat(clip.style.marginLeft) || 0;
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
  const curEnd = curMargin + curWidth;

  if (timelineOffset > curMargin + 5 && timelineOffset < curEnd - 5) {
    if (shouldRecord) beginUndoGroup('Split Layer');
    try {
      const leftW = timelineOffset - curMargin;
      const rightW = curEnd - timelineOffset;

      spawnSplitEffect(trackway, timelineOffset);

      clip.style.width = `${leftW}px`;
      clip.classList.add('clip-split-snap');
      setTimeout(() => clip.classList.remove('clip-split-snap'), 280);

      const cat = row.dataset.category || 'text';
      const name = row.querySelector('.track-clip-name')?.textContent || 'Text Layer';
      const origId = row.dataset.layerId;
      const newId = 'layer_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);

      const newRow = createTrackRowElement(cat, name, rightW, timelineOffset, newId);
      if (row.dataset.tagColor) newRow.dataset.tagColor = row.dataset.tagColor;
      if (row.dataset.shapeType) newRow.dataset.shapeType = row.dataset.shapeType;
      newRow.classList.add('split-slide-in');
      row.parentNode.insertBefore(newRow, row);
      bindTrackEvents(newRow);
      setTimeout(() => newRow.classList.remove('split-slide-in'), 360);

      const newClip = newRow.querySelector('.track-clip');
      if (newClip) {
        newClip.classList.add('clip-split-snap');
        if (row.dataset.tagColor && row.dataset.tagColor !== 'none') {
          newClip.style.borderLeft = `5px solid ${row.dataset.tagColor}`;
        }
        setTimeout(() => newClip.classList.remove('clip-split-snap'), 280);
      }

      if (origId && newId) {
        if (layerTransforms.has(origId)) layerTransforms.set(newId, JSON.parse(JSON.stringify(layerTransforms.get(origId))));
        if (layerKeyframes.has(origId)) layerKeyframes.set(newId, JSON.parse(JSON.stringify(layerKeyframes.get(origId))));
        if (layerFills.has(origId)) layerFills.set(newId, JSON.parse(JSON.stringify(layerFills.get(origId))));
        if (layerBorderShadow.has(origId)) layerBorderShadow.set(newId, JSON.parse(JSON.stringify(layerBorderShadow.get(origId))));
        if (layerShapeParams.has(origId)) layerShapeParams.set(newId, JSON.parse(JSON.stringify(layerShapeParams.get(origId))));
        if (layerCameraParams.has(origId)) layerCameraParams.set(newId, JSON.parse(JSON.stringify(layerCameraParams.get(origId))));
        if (layerMotionBlur.has(origId)) layerMotionBlur.set(newId, layerMotionBlur.get(origId));
      }

      const recordData = {
        origClip: clip,
        origWidth: curWidth,
        leftWidth: leftW,
        newRow: newRow
      };

      if (shouldRecord) calculateMaxDuration();

      syncThreeLayers();
      renderCanvasOverlay();
      return { recordData, newRow };
    } finally {
      if (shouldRecord) endUndoGroup();
    }
  }
  return null;
}

function executeExtendRightToPlayhead(row) {
  if (!row) return;
  const clip = row.querySelector('.track-clip');
  if (!clip) return;
  const curMargin = parseFloat(clip.style.marginLeft) || 0;
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;

  if (timelineOffset >= curMargin + curWidth) {
    beginUndoGroup('Extend Right');
    try {
      const newWidth = Math.max(20, timelineOffset - curMargin);
      clip.style.width = `${newWidth}px`;
      calculateMaxDuration();
      updateInspectorQuickButtons();
      syncThreeLayers();
      renderCanvasOverlay();
    } finally {
      endUndoGroup();
    }
  }
}

function executeMoveRightToPlayhead(row) {
  if (!row) return;
  const clip = row.querySelector('.track-clip');
  if (!clip) return;
  const curMargin = parseFloat(clip.style.marginLeft) || 0;
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;

  beginUndoGroup('Move Right');
  try {
    const newMargin = Math.max(0, timelineOffset - curWidth);
    clip.style.marginLeft = `${newMargin}px`;
    calculateMaxDuration();
    updateInspectorQuickButtons();
    syncThreeLayers();
    renderCanvasOverlay();
  } finally {
    endUndoGroup();
  }
}

function executeMoveLeftToPlayhead(row) {
  if (!row) return;
  const clip = row.querySelector('.track-clip');
  if (!clip) return;
  const curMargin = parseFloat(clip.style.marginLeft) || 0;

  beginUndoGroup('Move Left');
  try {
    const newMargin = Math.max(0, timelineOffset);
    clip.style.marginLeft = `${newMargin}px`;
    calculateMaxDuration();
    updateInspectorQuickButtons();
    syncThreeLayers();
    renderCanvasOverlay();
  } finally {
    endUndoGroup();
  }
}

function executeExtendLeftToPlayhead(row) {
  if (!row) return;
  const clip = row.querySelector('.track-clip');
  if (!clip) return;
  const curMargin = parseFloat(clip.style.marginLeft) || 0;
  const curWidth = parseFloat(clip.style.width) || clip.offsetWidth || 300;
  const curEnd = curMargin + curWidth;

  if (timelineOffset <= curMargin) {
    beginUndoGroup('Extend Left');
    try {
      const newMargin = Math.max(0, timelineOffset);
      const newWidth = Math.max(20, curEnd - newMargin);
      clip.style.marginLeft = `${newMargin}px`;
      clip.style.width = `${newWidth}px`;
      calculateMaxDuration();
      updateInspectorQuickButtons();
      syncThreeLayers();
      renderCanvasOverlay();
    } finally {
      endUndoGroup();
    }
  }
}

function createTrackRowElement(cat, name, width, marginLeft, customId = null) {
  const row = document.createElement('div');
  row.className = 'track-row';
  row.dataset.category = cat || 'media';
  row.dataset.layerId = customId || ('layer_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5));

  row.innerHTML = `
    <button class="track-eye" title="Toggle Visibility / Tahan untuk Multi-Select">
      <span class="material-symbols-rounded">${isMultiSelectMode ? 'radio_button_unchecked' : 'visibility'}</span>
    </button>
    <div class="track-trackway" style="transform: translateX(-${timelineOffset}px);">
      <div class="track-clip" style="width: ${width}px; margin-left: ${marginLeft}px;">
        <div class="clip-extend-handle handle-left" title="Tarik untuk memanjangkan awal layer">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </div>
        <span class="track-clip-name">${name}</span>
        <div class="clip-extend-handle handle-right" title="Tarik untuk memanjangkan akhir layer">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
      </div>
    </div>
    <button class="track-reorder-handle" title="Tahan & geser untuk atur urutan layer (Reorder)">
      <span class="material-symbols-rounded">menu</span>
    </button>
  `;

  return row;
}

function toggleEye(btn, shouldRecord = false) {
  const icon = btn.querySelector('.material-symbols-rounded');
  const trackway = btn.nextElementSibling;
  const row = btn.closest('.track-row');
  const isAudio = row && row.dataset.category === 'audio';

  if (isAudio) {
    const isMuted = icon.textContent.trim() === 'volume_off';
    if (isMuted) {
      icon.textContent = 'volume_up';
      icon.style.color = '#2ecc71';
      if (trackway) trackway.style.opacity = '1';
    } else {
      icon.textContent = 'volume_off';
      icon.style.color = 'rgba(255, 240, 194, 0.4)';
      if (trackway) trackway.style.opacity = '0.35';
    }
    syncAudioPlayback();
  } else {
    const isHidden = icon.textContent.trim() === 'visibility_off';
    if (isHidden) {
      icon.textContent = 'visibility';
      icon.style.color = 'var(--col-yellow)';
      if (trackway) trackway.style.opacity = '1';
    } else {
      icon.textContent = 'visibility_off';
      icon.style.color = 'rgba(255, 240, 194, 0.4)';
      if (trackway) trackway.style.opacity = '0.35';
    }
  }

  if (shouldRecord) {
    recordAction({
      type: 'TOGGLE_EYE',
      eyeBtn: btn
    });
  }

  syncThreeLayers();
  renderCanvasOverlay();
}



let currentMediaTabFilter = 'foto'; // 'foto' | 'video' | 'audio'

var CATEGORY_ITEMS = {
  shape: [],
  media: [],
  camera: [
    { icon: 'videocam', name: 'Camera', filename: 'Camera_1', sub: 'Camera Layer', cat: 'camera' },
    { icon: 'crop_free', name: 'Null', filename: 'Null_1', sub: 'Null Object', cat: 'null' }
  ],
  text: [
    { icon: 'title', name: 'Judul Utama', filename: 'Heading_Title.txt', sub: 'Text Header' },
    { icon: 'subtitles', name: 'Subtitle Caption', filename: 'Subtitle_Text.txt', sub: 'Text Caption' },
    { icon: 'label', name: 'Badge Callout', filename: 'Badge_Callout.txt', sub: 'Text Pill' }
  ]
};
