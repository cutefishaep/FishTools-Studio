let activeControllerPanel = 'move';

function solveCubicBezier(p1x, p1y, p2x, p2y, t) {
  if (t <= 0) return 0;
  if (t >= 1) return 1;
  let s = t;
  for (let i = 0; i < 8; i++) {
    const x = 3 * (1 - s) * (1 - s) * s * p1x + 3 * (1 - s) * s * s * p2x + s * s * s;
    const dx = 3 * (1 - s) * (1 - s) * p1x + 6 * (1 - s) * s * (p2x - p1x) + 3 * s * s * (1 - p2x);
    const diff = x - t;
    if (Math.abs(diff) < 1e-4) break;
    if (Math.abs(dx) > 1e-5) {
      s -= diff / dx;
    } else {
      break;
    }
    s = Math.max(0, Math.min(1, s));
  }
  return 3 * (1 - s) * (1 - s) * s * p1y + 3 * (1 - s) * s * s * p2y + s * s * s;
}

let graphEditorState = {
  channel: 'position',
  layerId: null,
  kfIndex: 0,
  cp1: { x: 0.33, y: 0.33 },
  cp2: { x: 0.67, y: 0.67 },
  dragging: null,
  dirty: false,
  showGrid: true,
  isOvershoot: false
};

let graphLibrary = JSON.parse(localStorage.getItem('fishGraphLibrary') || '[]');
let globalMoveTransformKfController = null;
let globalGraphEditor = null;

function openGraphEditor(channel, anchorEl) {
  if (selectedTrackRow) {
    graphEditorState.layerId = selectedTrackRow.dataset.layerId || 'default';
  }
  graphEditorState.channel = channel;
  graphEditorState.dirty = false;
  if (graphEditorState.showGrid === undefined) graphEditorState.showGrid = true;

  const kfs = layerKeyframes.get(graphEditorState.layerId) || [];
  const chanKfs = kfs.filter(k => graphKeyForChannel(channel, k) !== undefined).sort((a, b) => a.time - b.time);

  if (chanKfs.length >= 2) {
    let nearest = 0;
    let minDist = Infinity;
    chanKfs.forEach((k, i) => { const d = Math.abs(k.time - elapsed); if (d < minDist) { minDist = d; nearest = i; } });
    graphEditorState.kfIndex = Math.min(nearest, chanKfs.length - 2);
    const kf = chanKfs[graphEditorState.kfIndex];
    const cp = kf['easing_' + channel] || kf.easing || { cp1x: 0.33, cp1y: 0.33, cp2x: 0.67, cp2y: 0.67 };
    graphEditorState.cp1 = { x: cp.cp1x, y: cp.cp1y };
    graphEditorState.cp2 = { x: cp.cp2x, y: cp.cp2y };
  } else {
    graphEditorState.cp1 = { x: 0.33, y: 0.33 };
    graphEditorState.cp2 = { x: 0.67, y: 0.67 };
  }

  const channelLabels = { position: 'Position Graph', rotX: 'Rotation X Graph', rotY: 'Rotation Y Graph', rotZ: 'Rotation Z Graph', scale: 'Scale Graph', opacity: 'Opacity Graph', strokeColor: 'Stroke Color', strokeSize: 'Stroke Size', shadowColor: 'Shadow Color', shadowSize: 'Shadow Size', shadowAlpha: 'Shadow Alpha', shadowPosX: 'Shadow X', shadowPosY: 'Shadow Y' };
  const finalAnchor = anchorEl || document.getElementById('btnKeyframeGraph') || document.getElementById('panelMoveTransform');

  if (window.FishUI && window.FishUI.openGraphPopover) {
    window.FishUI.openGraphPopover({
      anchorElement: finalAnchor,
      title: channelLabels[channel] || `${channel} Graph`,
      cp1: graphEditorState.cp1,
      cp2: graphEditorState.cp2,
      isOvershoot: (graphEditorState.cp1.y > 1.01 || graphEditorState.cp1.y < -0.01 || graphEditorState.cp2.y > 1.01 || graphEditorState.cp2.y < -0.01),
      onCurveChange: ({ cp1, cp2, isOvershoot }) => {
        graphEditorState.cp1 = { ...cp1 };
        graphEditorState.cp2 = { ...cp2 };
        graphEditorState.isOvershoot = isOvershoot;
        graphEditorState.dirty = true;
        applyGraphEasingToKeyframe();
      }
    });
  }
}

function updateGraphButtonsUI() {
  const btnGrid = document.getElementById('btnToggleGrid');
  if (btnGrid) {
    btnGrid.classList.toggle('active', graphEditorState.showGrid !== false);
  }
  const btnOvershoot = document.getElementById('btnToggleOvershoot');
  if (btnOvershoot) {
    btnOvershoot.classList.toggle('active', !!graphEditorState.isOvershoot);
  }
}

function graphKeyForChannel(channel, k) {
  if (channel === 'position') return k.posX !== undefined ? k.posX : undefined;
  if (channel === 'rotX') return k.rotX;
  if (channel === 'rotY') return k.rotY;
  if (channel === 'rotZ') return k.rotZ;
  if (channel === 'scale') return k.scaleW;
  if (channel === 'opacity') return k.opacity;
  if (['strokeColor','strokeSize','shadowColor','shadowSize','shadowAlpha','shadowPosX','shadowPosY'].includes(channel)) return k[channel];
  return k[channel];
}

function applyGraphEasingToKeyframe() {
  if (!graphEditorState.layerId) return;
  const kfs = layerKeyframes.get(graphEditorState.layerId) || [];
  const chanKfs = kfs.filter(k => graphKeyForChannel(graphEditorState.channel, k) !== undefined).sort((a, b) => a.time - b.time);
  if (chanKfs.length >= 2 && graphEditorState.kfIndex < chanKfs.length - 1) {
    const easingData = {
      cp1x: graphEditorState.cp1.x,
      cp1y: graphEditorState.cp1.y,
      cp2x: graphEditorState.cp2.x,
      cp2y: graphEditorState.cp2.y
    };
    const easingKey = 'easing_' + graphEditorState.channel;
    chanKfs[graphEditorState.kfIndex][easingKey] = easingData;
    chanKfs[graphEditorState.kfIndex].easing = easingData;
    if (typeof saveCurrentProject === 'function') saveCurrentProject();
    syncControllerUI();
    renderCanvasOverlay();
  }
}

function closeGraphEditor(save) {
  const panelMove = document.getElementById('panelMoveTransform');
  const panelGraph = document.getElementById('panelGraphEditor');
  if (panelGraph) {
    panelGraph.classList.remove('slide-in');
    panelGraph.classList.add('slide-out');
    setTimeout(() => {
      panelGraph.style.display = 'none';
      panelGraph.classList.remove('slide-out');
      if (panelMove) {
        panelMove.style.display = 'flex';
        panelMove.classList.remove('slide-out');
        panelMove.classList.add('slide-in');
      }
      renderAllKeyframeMarkers();
      updateKeyframeUI();
    }, 140);
  } else if (panelMove) {
    panelMove.style.display = 'flex';
  }

  if (save && graphEditorState.layerId) {
    applyGraphEasingToKeyframe();
  }
}


let activeRotationAxis = 'Z';

function getLayerTransform(id, targetTime = elapsed) {
  if (!layerTransforms.has(id)) {
    layerTransforms.set(id, {
      posX: 0,
      posY: 0,
      posZ: 0,
      rotZ: 0,
      rotX: 0,
      rotY: 0,
      rotationAxis: activeRotationAxis || 'Z',
      scaleW: 100,
      scaleH: 100,
      isLinked: true,
      opacity: 100,
      blendMode: 'NORMAL'
    });
  }

  const base = layerTransforms.get(id);
  if (base.isLinked === undefined) base.isLinked = true;
  const kfs = layerKeyframes.get(id);
  if (!kfs || kfs.length === 0) {
    return base;
  }

  function interpolateChannel(prop, defaultVal) {
    const relevant = kfs.filter(k => k[prop] !== undefined);
    if (relevant.length === 0) return defaultVal;
    if (relevant.length === 1 || targetTime <= relevant[0].time) return relevant[0][prop];
    const last = relevant[relevant.length - 1];
    if (targetTime >= last.time) return last[prop];

    for (let i = 0; i < relevant.length - 1; i++) {
      const k1 = relevant[i];
      const k2 = relevant[i + 1];
      if (targetTime >= k1.time && targetTime <= k2.time) {
        const span = k2.time - k1.time;
        const rawT = span > 0 ? (targetTime - k1.time) / span : 0;
        let channelKey = prop;
        if (prop === 'posX' || prop === 'posY' || prop === 'posZ') channelKey = 'position';
        else if (prop === 'scaleW' || prop === 'scaleH') channelKey = 'scale';

        const easing = k1['easing_' + channelKey] || k1['easing_' + prop] || k1.easing;
        let t = rawT;
        if (easing && easing.cp1x !== undefined) {
          t = solveCubicBezier(easing.cp1x, easing.cp1y, easing.cp2x, easing.cp2y, rawT);
        }
        return k1[prop] + (k2[prop] - k1[prop]) * t;
      }
    }
    return defaultVal;
  }

  return {
    ...base,
    posX: interpolateChannel('posX', base.posX),
    posY: interpolateChannel('posY', base.posY),
    posZ: interpolateChannel('posZ', base.posZ),
    rotX: interpolateChannel('rotX', base.rotX),
    rotY: interpolateChannel('rotY', base.rotY),
    rotZ: interpolateChannel('rotZ', base.rotZ),
    scaleW: interpolateChannel('scaleW', base.scaleW),
    scaleH: interpolateChannel('scaleH', base.scaleH),
    opacity: interpolateChannel('opacity', base.opacity),
    isLinked: base.isLinked,
    rotationAxis: base.rotationAxis || activeRotationAxis || 'Z'
  };
}

function isCameraLayer(layerId) {
  if (!layerId) return false;
  const row = document.querySelector(`.track-row[data-layer-id="${layerId}"]`);
  if (!row) return false;
  const cat = row.dataset.category || '';
  const clipName = row.querySelector('.track-clip-name')?.textContent || '';
  return cat === 'camera' || clipName.toLowerCase().startsWith('camera');
}

function getLayerWorldTransform(id, visited = new Set(), targetTime = elapsed) {
  const t = getLayerTransform(id, targetTime);
  if (!id || visited.has(id)) return { ...t };
  visited.add(id);

  const row = document.querySelector(`.track-row[data-layer-id="${id}"]`);
  let parentId = null;
  let bindPose = null;

  if (row && row.dataset.linkedTo) {
    try {
      const parsed = JSON.parse(row.dataset.linkedTo);
      if (parsed && parsed.length > 0) parentId = parsed[0];
    } catch (_) {}
  }

  if (row && row.dataset.parentBind) {
    try {
      bindPose = JSON.parse(row.dataset.parentBind);
    } catch (_) {}
  }

  if (parentId && parentId !== id && layerTransforms.has(parentId)) {
    const pt = getLayerWorldTransform(parentId, visited, targetTime);

    const bp = bindPose || {
      posX: pt.posX,
      posY: pt.posY,
      posZ: pt.posZ,
      rotX: pt.rotX,
      rotY: pt.rotY,
      rotZ: pt.rotZ,
      scaleW: pt.scaleW,
      scaleH: pt.scaleH
    };

    if (typeof THREE !== 'undefined') {
      const isCam = isCameraLayer(id);
      const isParentCam = isCameraLayer(parentId);

      // Parent current world transform
      const pPos = new THREE.Vector3(pt.posX / 200, pt.posY / 200, (pt.posZ / 200) + (isParentCam ? 5.0 : 0));
      const pEuler = new THREE.Euler((pt.rotX * Math.PI) / 180, (pt.rotY * Math.PI) / 180, -(pt.rotZ * Math.PI) / 180, 'YXZ');
      const pQuat = new THREE.Quaternion().setFromEuler(pEuler);
      const pScale = new THREE.Vector3(
        bp.scaleW > 0 ? pt.scaleW / bp.scaleW : 1,
        bp.scaleH > 0 ? pt.scaleH / bp.scaleH : 1,
        1
      );
      const pMat = new THREE.Matrix4().compose(pPos, pQuat, pScale);

      // Parent bind pose transform matrix (inverted)
      const bpPos = new THREE.Vector3(bp.posX / 200, bp.posY / 200, (bp.posZ / 200) + (isParentCam ? 5.0 : 0));
      const bpEuler = new THREE.Euler((bp.rotX * Math.PI) / 180, (bp.rotY * Math.PI) / 180, -(bp.rotZ * Math.PI) / 180, 'YXZ');
      const bpQuat = new THREE.Quaternion().setFromEuler(bpEuler);
      const bpScale = new THREE.Vector3(1, 1, 1);
      const bpMatInv = new THREE.Matrix4().compose(bpPos, bpQuat, bpScale).invert();

      // Child local transform (camera has base 5.0 unit visual offset in 3D world)
      const cPos = new THREE.Vector3(t.posX / 200, t.posY / 200, (t.posZ / 200) + (isCam ? 5.0 : 0));
      const cEuler = new THREE.Euler((t.rotX * Math.PI) / 180, (t.rotY * Math.PI) / 180, -(t.rotZ * Math.PI) / 180, 'YXZ');
      const cQuat = new THREE.Quaternion().setFromEuler(cEuler);
      const cScale = new THREE.Vector3(t.scaleW / 100, t.scaleH / 100, 1);
      const cMat = new THREE.Matrix4().compose(cPos, cQuat, cScale);

      // Relative matrix: child in parent bind space
      const relMat = new THREE.Matrix4().multiplyMatrices(bpMatInv, cMat);

      // World matrix: parent current * relMat
      const worldMat = new THREE.Matrix4().multiplyMatrices(pMat, relMat);

      const wPos = new THREE.Vector3();
      const wQuat = new THREE.Quaternion();
      const wScale = new THREE.Vector3();
      worldMat.decompose(wPos, wQuat, wScale);

      const wEuler = new THREE.Euler().setFromQuaternion(wQuat, 'YXZ');

      const finalPosZ = isCam ? (wPos.z - 5.0) * 200 : wPos.z * 200;

      return {
        posX: wPos.x * 200,
        posY: wPos.y * 200,
        posZ: finalPosZ,
        rotX: (wEuler.x * 180) / Math.PI,
        rotY: (wEuler.y * 180) / Math.PI,
        rotZ: -(wEuler.z * 180) / Math.PI,
        scaleW: wScale.x * 100,
        scaleH: wScale.y * 100,
        opacity: Math.max(0, Math.min(100, t.opacity * (pt.opacity / 100))),
        isLinked: t.isLinked,
        rotationAxis: t.rotationAxis
      };
    }

    // Pure math fallback if THREE is not loaded in current environment
    const deltaRotZ = (pt.rotZ - bp.rotZ);
    const rad = (deltaRotZ * Math.PI) / 180;
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);

    const scaleFactorX = bp.scaleW > 0 ? (pt.scaleW / bp.scaleW) : 1;
    const scaleFactorY = bp.scaleH > 0 ? (pt.scaleH / bp.scaleH) : 1;

    const relX = (t.posX - bp.posX);
    const relY = (t.posY - bp.posY);

    const orbitedX = (relX * cos - relY * sin) * scaleFactorX;
    const orbitedY = (relX * sin + relY * cos) * scaleFactorY;

    return {
      posX: pt.posX + orbitedX,
      posY: pt.posY + orbitedY,
      posZ: t.posZ + (pt.posZ - bp.posZ),
      rotX: t.rotX + (pt.rotX - bp.rotX),
      rotY: t.rotY + (pt.rotY - bp.rotY),
      rotZ: t.rotZ + deltaRotZ,
      scaleW: t.scaleW * scaleFactorX,
      scaleH: t.scaleH * scaleFactorY,
      opacity: Math.max(0, Math.min(100, t.opacity * (pt.opacity / 100))),
      isLinked: t.isLinked,
      rotationAxis: t.rotationAxis
    };
  }

  return { ...t };
}
