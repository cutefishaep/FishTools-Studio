function renderLayerTexture(id, fill, bs, onDone) {
  // Canvas adaptif + low quality beneran (bukan cuma alpha) — optimized biar shadow gede gak lag
  const strokeEnabledTmp2 = bs && bs.stroke && bs.stroke.enabled;
  const shadowEnabledTmp2 = bs && bs.shadow && bs.shadow.enabled;
  const shadowSizeTmp = shadowEnabledTmp2 ? (bs.shadow.size || 4) : 0;
  const isHeavyShadow = shadowEnabledTmp2 && shadowSizeTmp > 18;
  const isVeryHeavyShadow = shadowEnabledTmp2 && shadowSizeTmp > 45;
  let baseCanvas;
  if (typeof isLowQuality !== 'undefined' && isLowQuality) baseCanvas = 512;
  else if (isVeryHeavyShadow) baseCanvas = 384; // ~7x lebih enteng dari 1024 (384*384 vs 1024*1024)
  else if (isHeavyShadow) baseCanvas = 512; // 4x lebih enteng
  else baseCanvas = 1024;
  const scaleFactor = baseCanvas / 1024; // biar blur/offset/stroke visual tetap sama walau canvas kecil
  let requiredPad2 = 64 * scaleFactor;
  if (strokeEnabledTmp2) requiredPad2 = Math.max(requiredPad2, (bs.stroke.size || 4) * 4 * scaleFactor + 24 * scaleFactor);
  if (shadowEnabledTmp2) {
    const blur2 = (bs.shadow.size || 4) * 2.5 * scaleFactor;
    const off2 = Math.max(Math.abs(bs.shadow.posX || 3), Math.abs(bs.shadow.posY || 3)) * 1.5 * scaleFactor;
    requiredPad2 = Math.max(requiredPad2, blur2 + off2 + 24 * scaleFactor);
  }
  requiredPad2 = Math.min(512 * scaleFactor, Math.ceil(requiredPad2));
  const canvasSize = baseCanvas;
  const planeSize = 4.0;
  const wireframeBase = 1.6;
  const shapeW = Math.round((wireframeBase / planeSize) * canvasSize);
  const shapeH = shapeW;
  const pad = Math.round((canvasSize - shapeW) / 2);
  const cx = canvasSize / 2;
  const cy = canvasSize / 2;

  const canvas = document.createElement('canvas');
  canvas.width = canvasSize;
  canvas.height = canvasSize;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvasSize, canvasSize);

  const rowTmp = document.querySelector(`.track-row[data-layer-id="${id}"]`);
  const catTmp = rowTmp ? (rowTmp.dataset.category || 'media') : 'media';
  const clipName = rowTmp?.querySelector('.track-clip-name')?.textContent || '';
  let shapeType = rowTmp ? (rowTmp.dataset.shapeType || '') : '';

  if (!shapeType) {
    const lower = (clipName + '_' + catTmp).toLowerCase();
    if (lower.includes('camera')) shapeType = 'camera';
    else if (lower.includes('null')) shapeType = 'null';
    else if (lower.includes('heart') || lower.includes('love')) shapeType = 'heart';
    else if (lower.includes('star-4') || lower.includes('bintang_4') || lower.includes('bintang 4')) shapeType = 'star-4';
    else if (lower.includes('star') || lower.includes('bintang')) shapeType = 'star';
    else if (lower.includes('hexagon') || lower.includes('segi_enam') || lower.includes('segi enam')) shapeType = 'hexagon';
    else if (lower.includes('circle') || lower.includes('bulat') || lower.includes('lingkaran')) shapeType = 'circle';
    else if (lower.includes('triangle') || lower.includes('segitiga')) shapeType = 'triangle';
    else if (lower.includes('round')) shapeType = 'round';
    else if (lower.includes('square') || lower.includes('kotak')) shapeType = 'square';
    else if (lower.includes('line') || lower.includes('garis')) shapeType = 'line';
    else if (lower.includes('arrow') || lower.includes('panah')) shapeType = 'arrow';
    else if (catTmp === 'text' || lower.includes('.txt') || lower.includes('heading') || lower.includes('subtitle') || lower.includes('title') || lower.includes('text')) shapeType = 'text';
    else if (lower.includes('svg') || catTmp === 'svg') shapeType = 'svg_path';
    else if (catTmp === 'camera') shapeType = 'camera';
    else if (catTmp === 'null') shapeType = 'null';
    else if (catTmp === 'shape') shapeType = 'square';
    else if (catTmp === 'media' || catTmp === 'video' || (fill && fill.type === 'media')) shapeType = 'media';
    else shapeType = 'square';
  }

  if (shapeType === 'camera' || shapeType === 'null' || catTmp === 'camera' || catTmp === 'null' || clipName.toLowerCase().startsWith('camera') || clipName.toLowerCase().startsWith('null')) {
    // Camera & Null Objects have NO visible graphic/mesh body - only wireframe is shown when selected
    if (onDone) onDone(canvas);
    return;
  }

  const shadowEnabled = bs && bs.shadow && bs.shadow.enabled;
  const strokeEnabled = bs && bs.stroke && bs.stroke.enabled;

  function applyShadowContext() {
    if (shadowEnabled) {
      const p = parseHexOrRgbLocal(bs.shadow.color || '#000000');
      const shadowAlpha = (bs.shadow.alpha !== undefined ? bs.shadow.alpha : 100) / 100;
      ctx.shadowColor = `rgba(${p.r}, ${p.g}, ${p.b}, ${shadowAlpha})`;
      // scale blur/offset biar visual sama walau canvas kecil, + cap biar gak brutal
      const rawBlur = Math.max(0, (bs.shadow.size !== undefined ? bs.shadow.size : 4) * 2.5 * scaleFactor);
      ctx.shadowBlur = Math.min(80 * scaleFactor, rawBlur);
      ctx.shadowOffsetX = (bs.shadow.posX !== undefined ? bs.shadow.posX : 3) * 1.5 * scaleFactor;
      ctx.shadowOffsetY = -(bs.shadow.posY !== undefined ? bs.shadow.posY : 3) * 1.5 * scaleFactor;
    } else {
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    }
  }

  function applyStrokeContext(align) {
    if (!strokeEnabled) return;
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
    const p = parseHexOrRgbLocal(bs.stroke.color || '#000000');
    ctx.strokeStyle = `rgba(${p.r}, ${p.g}, ${p.b}, 1)`;
    const baseSize = Math.max(1, (bs.stroke.size !== undefined ? bs.stroke.size : 4) * 2 * scaleFactor);
    if (align === 'inside' || align === 'outside') {
      ctx.lineWidth = baseSize * 2;
    } else {
      ctx.lineWidth = baseSize;
    }
    ctx.lineCap = bs.stroke.cap || 'butt';
    ctx.lineJoin = 'miter';
  }

  const strokeAlign = (bs.stroke.align || 'center');

  // ══════════════════════════════════════════════════════════════
  // TEXT LAYER RENDERING BRANCH (Google Fonts & Typography Engine)
  // ══════════════════════════════════════════════════════════════
  if (shapeType === 'text' || catTmp === 'text') {
    const tData = (typeof getLayerText === 'function') ? getLayerText(id) : { content: 'Heading Title', font: 'Poppins', size: 48, align: 'center', bold: true, italic: false, underline: false, uppercase: false, letterSpacing: 0, lineHeight: 1.2 };
    const content = tData.content || 'Heading Title';
    const textToDraw = tData.uppercase ? content.toUpperCase() : content;
    const lines = textToDraw.split('\n');

    const fontSize = Math.max(10, (tData.size || 48)) * 2 * scaleFactor;
    const fontName = tData.font || 'Poppins';
    const isBold = !!tData.bold;
    const isItalic = !!tData.italic;
    const isUnderline = !!tData.underline;
    const align = tData.align || 'center';
    const letterSpacing = (tData.letterSpacing || 0) * scaleFactor;
    const lineHeightRatio = (tData.lineHeight !== undefined ? tData.lineHeight : 1.2);
    const lineSpacingPx = fontSize * lineHeightRatio;

    ctx.font = `${isItalic ? 'italic ' : ''}${isBold ? 'bold ' : 'normal '}${fontSize}px "${fontName}", sans-serif`;
    if ('letterSpacing' in ctx) {
      ctx.letterSpacing = `${letterSpacing}px`;
    }

    ctx.textAlign = (align === 'justify') ? 'center' : align;
    ctx.textBaseline = 'middle';

    const totalTextH = (lines.length - 1) * lineSpacingPx + fontSize;
    const startY = cy - (totalTextH / 2) + (fontSize / 2);

    // Apply shadow
    applyShadowContext();

    // Determine text fill style
    let fillStyle = '#FAB778';
    if (fill.type === 'color' && fill.color) {
      fillStyle = fill.color;
    } else if (fill.type === 'gradient') {
      const g = ctx.createLinearGradient(0, cy - totalTextH / 2, 0, cy + totalTextH / 2);
      if (fill.gradientStops && fill.gradientStops.length) {
        fill.gradientStops.forEach(st => g.addColorStop(st.offset, st.color));
      } else {
        g.addColorStop(0, '#FFFFFF');
        g.addColorStop(1, '#FAB778');
      }
      fillStyle = g;
    }
    ctx.fillStyle = fillStyle;

    lines.forEach((lineText, idx) => {
      const lineY = startY + idx * lineSpacingPx;
      let drawX = cx;
      if (align === 'left') drawX = 40 * scaleFactor;
      else if (align === 'right') drawX = canvasSize - 40 * scaleFactor;

      ctx.fillText(lineText, drawX, lineY);

      if (isUnderline) {
        const metrics = ctx.measureText(lineText);
        const textW = metrics.width;
        let lineStartX = drawX - textW / 2;
        if (align === 'left') lineStartX = drawX;
        else if (align === 'right') lineStartX = drawX - textW;

        ctx.lineWidth = Math.max(2, fontSize * 0.07);
        ctx.strokeStyle = fillStyle;
        ctx.beginPath();
        ctx.moveTo(lineStartX, lineY + fontSize * 0.45);
        ctx.lineTo(lineStartX + textW, lineY + fontSize * 0.45);
        ctx.stroke();
      }
    });

    if (strokeEnabled) {
      applyStrokeContext('center');
      lines.forEach((lineText, idx) => {
        const lineY = startY + idx * lineSpacingPx;
        let drawX = cx;
        if (align === 'left') drawX = 40 * scaleFactor;
        else if (align === 'right') drawX = canvasSize - 40 * scaleFactor;

        ctx.strokeText(lineText, drawX, lineY);
      });
    }

    if (onDone) onDone(canvas);
    return;
  }

  // helper to create current shape path
  const makeShapePath = () => {
    ctx.beginPath();

    switch (shapeType) {
      case 'circle': {
        const p = getLayerShapeParams(id, 'circle');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const rx = Math.max(1, (shapeW / 2) * Math.abs(scaleX));
        const ry = Math.max(1, (shapeH / 2) * Math.abs(scaleY));
        ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
        break;
      }
      case 'square': {
        const p = getLayerShapeParams(id, 'square');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const w = shapeW * Math.abs(scaleX);
        const h = shapeH * Math.abs(scaleY);
        const x = cx - w / 2;
        const y = cy - h / 2;
        const maxR = Math.min(w, h) / 2;
        const r = Math.max(0, Math.min(maxR, ((p.rounded || 0) / 100) * maxR));
        if (r > 0 && typeof ctx.roundRect === 'function') {
          ctx.roundRect(x, y, w, h, r);
        } else {
          ctx.rect(x, y, w, h);
        }
        break;
      }
      case 'round': {
        const p = getLayerShapeParams(id, 'round');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const w = shapeW * Math.abs(scaleX);
        const h = shapeH * Math.abs(scaleY);
        const x = cx - w / 2;
        const y = cy - h / 2;
        const r = Math.min(w, h) * 0.22;
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(x, y, w, h, r);
        } else {
          ctx.rect(x, y, w, h);
        }
        break;
      }
      case 'triangle': {
        const p = getLayerShapeParams(id, 'triangle');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const w = shapeW * scaleX;
        const h = shapeH * scaleY;
        const absW = Math.abs(w);
        const absH = Math.abs(h);
        const curve = Math.max(0, (p.curve || 0) / 100);
        const x1 = cx, y1 = cy - h / 2;
        const x2 = cx + w / 2, y2 = cy + h / 2;
        const x3 = cx - w / 2, y3 = cy + h / 2;
        if (curve > 0) {
          const cornerR = Math.min(absW, absH) * 0.28 * curve;
          ctx.moveTo((x1 + x2) / 2, (y1 + y2) / 2);
          ctx.arcTo(x2, y2, x3, y3, cornerR);
          ctx.arcTo(x3, y3, x1, y1, cornerR);
          ctx.arcTo(x1, y1, x2, y2, cornerR);
          ctx.closePath();
        } else {
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.lineTo(x3, y3);
          ctx.closePath();
        }
        break;
      }
      case 'heart':
      case 'love': {
        const p = getLayerShapeParams(id, 'heart');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const w = shapeW * Math.abs(scaleX);
        const h = shapeH * Math.abs(scaleY);
        if (p.points && p.points.length >= 4) {
          const canvasPts = p.points.map(pt => ({
            x: cx + ((Number(pt.x) || 0) / 100) * (shapeW / 2),
            y: cy - ((Number(pt.y) || 0) / 100) * (shapeH / 2)
          }));
          ctx.moveTo(canvasPts[0].x, canvasPts[0].y);
          for (let i = 1; i < canvasPts.length; i++) {
            ctx.lineTo(canvasPts[i].x, canvasPts[i].y);
          }
          ctx.closePath();
        } else {
          const topCurve = h * 0.38;
          ctx.moveTo(cx, cy + h * 0.44);
          ctx.bezierCurveTo(cx - w * 0.54, cy + h * 0.12, cx - w * 0.54, cy - topCurve, cx - w * 0.25, cy - topCurve);
          ctx.bezierCurveTo(cx - w * 0.08, cy - topCurve, cx, cy - topCurve * 0.45, cx, cy - topCurve * 0.15);
          ctx.bezierCurveTo(cx, cy - topCurve * 0.45, cx + w * 0.08, cy - topCurve, cx + w * 0.25, cy - topCurve);
          ctx.bezierCurveTo(cx + w * 0.54, cy - topCurve, cx + w * 0.54, cy + h * 0.12, cx, cy + h * 0.44);
          ctx.closePath();
        }
        break;
      }
      case 'star': {
        const p = getLayerShapeParams(id, 'star');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const outerR = (shapeW / 2) * Math.abs(scaleX);
        const innerR = outerR * ((p.innerRadius || 40) / 100);
        const numPoints = p.pointsCount || 5;
        let rot = -Math.PI / 2;
        const step = Math.PI / numPoints;
        ctx.moveTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR * Math.abs(scaleY / (scaleX || 1)));
        for (let i = 0; i < numPoints; i++) {
          let x = cx + Math.cos(rot) * outerR;
          let y = cy + Math.sin(rot) * outerR * Math.abs(scaleY / (scaleX || 1));
          ctx.lineTo(x, y);
          rot += step;
          x = cx + Math.cos(rot) * innerR;
          y = cy + Math.sin(rot) * innerR * Math.abs(scaleY / (scaleX || 1));
          ctx.lineTo(x, y);
          rot += step;
        }
        ctx.closePath();
        break;
      }
      case 'star-4': {
        const p = getLayerShapeParams(id, 'star-4');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const outerR = (shapeW / 2) * Math.abs(scaleX);
        const innerR = outerR * ((p.innerRadius || 30) / 100);
        const numPoints = 4;
        let rot = -Math.PI / 2;
        const step = Math.PI / numPoints;
        ctx.moveTo(cx + Math.cos(rot) * outerR, cy + Math.sin(rot) * outerR * Math.abs(scaleY / (scaleX || 1)));
        for (let i = 0; i < numPoints; i++) {
          let x = cx + Math.cos(rot) * outerR;
          let y = cy + Math.sin(rot) * outerR * Math.abs(scaleY / (scaleX || 1));
          ctx.lineTo(x, y);
          rot += step;
          x = cx + Math.cos(rot) * innerR;
          y = cy + Math.sin(rot) * innerR * Math.abs(scaleY / (scaleX || 1));
          ctx.lineTo(x, y);
          rot += step;
        }
        ctx.closePath();
        break;
      }
      case 'hexagon': {
        const p = getLayerShapeParams(id, 'hexagon');
        const scaleX = (p.sizeX !== undefined ? p.sizeX : 100) / 100;
        const scaleY = (p.sizeY !== undefined ? p.sizeY : 100) / 100;
        const r = (shapeW / 2) * Math.abs(scaleX);
        const sides = 6;
        for (let i = 0; i < sides; i++) {
          const angle = (i * 2 * Math.PI / sides) - (Math.PI / 2);
          const x = cx + Math.cos(angle) * r;
          const y = cy + Math.sin(angle) * r * Math.abs(scaleY / (scaleX || 1));
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        break;
      }
      case 'svg_path':
      case 'svg': {
        const p = getLayerShapeParams(id, 'svg_path');
        if (p.points && p.points.length >= 2) {
          const canvasPts = p.points.map(pt => ({
            x: cx + ((Number(pt.x) || 0) / 100) * (shapeW / 2),
            y: cy - ((Number(pt.y) || 0) / 100) * (shapeH / 2)
          }));
          ctx.moveTo(canvasPts[0].x, canvasPts[0].y);
          for (let i = 1; i < canvasPts.length; i++) {
            ctx.lineTo(canvasPts[i].x, canvasPts[i].y);
          }
          if (p.isClosed !== false) ctx.closePath();
        } else {
          ctx.rect(pad, pad, shapeW, shapeH);
        }
        break;
      }
      case 'line': {
        const p = getLayerShapeParams(id, 'line');
        const pts = p.points && p.points.length >= 2 ? p.points : [{ x: -50, y: 0 }, { x: 50, y: 0 }];
        const thick = Math.max(4, (p.thickness || 14) * scaleFactor);
        const canvasPts = pts.map(pt => ({
          x: cx + ((Number(pt.x) || 0) / 100) * (shapeW / 2),
          y: cy - ((Number(pt.y) || 0) / 100) * (shapeH / 2)
        }));

        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.lineWidth = thick;
        ctx.moveTo(canvasPts[0].x, canvasPts[0].y);
        for (let i = 1; i < canvasPts.length; i++) {
          ctx.lineTo(canvasPts[i].x, canvasPts[i].y);
        }
        break;
      }
      case 'arrow': {
        const p = getLayerShapeParams(id, 'arrow');
        const pts = p.points && p.points.length >= 2 ? p.points : [{ x: -50, y: 0 }, { x: 50, y: 0 }];
        const thick = Math.max(4, (p.thickness || 16) * scaleFactor);
        const canvasPts = pts.map(pt => ({
          x: cx + ((Number(pt.x) || 0) / 100) * (shapeW / 2),
          y: cy - ((Number(pt.y) || 0) / 100) * (shapeH / 2)
        }));

        const lastIdx = canvasPts.length - 1;
        const pPrev = canvasPts[lastIdx - 1];
        const pTip = canvasPts[lastIdx];
        const dx = pTip.x - pPrev.x;
        const dy = pTip.y - pPrev.y;
        const totalLen = Math.hypot(dx, dy) || 1;
        const ux = dx / totalLen;
        const uy = dy / totalLen;
        const actualHeadLen = Math.min(totalLen * 0.85, (p.headSize || 36) * scaleFactor);
        const pBase = {
          x: pTip.x - ux * actualHeadLen,
          y: pTip.y - uy * actualHeadLen
        };

        const bodyPts = canvasPts.slice(0, lastIdx).concat([pBase]);

        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.lineWidth = thick;
        ctx.moveTo(bodyPts[0].x, bodyPts[0].y);
        for (let i = 1; i < bodyPts.length; i++) {
          ctx.lineTo(bodyPts[i].x, bodyPts[i].y);
        }
        break;
      }
      default: {
        const radius = Math.max(4, Math.round(16 * scaleFactor));
        if (typeof ctx.roundRect === 'function') {
          ctx.roundRect(pad, pad, shapeW, shapeH, radius);
        } else {
          ctx.rect(pad, pad, shapeW, shapeH);
        }
        break;
      }
    }
  };

  // Draw based on fill type
  if (fill.type === 'media' && fill.mediaUrl) {
    if (fill.mediaUrl.startsWith('video_pkg_') || fill.mediaUrl.startsWith('pkg_')) {
      if (onDone) onDone(canvas);
      return;
    }
    const isVideo = (catTmp === 'video') || (clipName && /\.(mp4|webm|mov|mkv|ogg|avi)$/i.test(clipName)) || (fill.mediaType && fill.mediaType.startsWith('video')) || (fill.mediaUrl && (fill.mediaUrl.startsWith('data:video/') || /\.(mp4|webm|mov|mkv|ogg|avi)$/i.test(fill.mediaUrl)));

    if (isVideo) {
      let video = layerVideoMap.get(id);
      if (!video || video.src !== fill.mediaUrl) {
        if (video) {
          video.pause();
          video.removeAttribute("src"); try { video.load(); } catch(_) {}
        }
        video = document.createElement('video');
        video.src = fill.mediaUrl;
        video.crossOrigin = 'anonymous';
        video.playsInline = true;
        video.muted = false;
        video.preload = 'auto';
        layerVideoMap.set(id, video);
      }

      const drawVideoFrame = () => {
        const natW = video.videoWidth || 1920;
        const natH = video.videoHeight || 1080;
        const natAspect = (natW && natH) ? (natW / natH) : 1.0;
        const prevAspect = mediaNaturalRatioMap.get(id);
        mediaNaturalRatioMap.set(id, natAspect);
        if (fill.mediaUrl) mediaNaturalRatioMap.set(fill.mediaUrl, natAspect);
        fill.aspectRatio = natAspect;

        let drawW, drawH;
        if (natAspect >= 1) {
          drawW = shapeW;
          drawH = Math.round(shapeW / natAspect);
        } else {
          drawH = shapeH;
          drawW = Math.round(shapeH * natAspect);
        }
        const drawX = Math.round(cx - drawW / 2);
        const drawY = Math.round(cy - drawH / 2);

        applyShadowContext();
        if (video.readyState >= 2) {
          ctx.drawImage(video, 0, 0, canvasSize, canvasSize);
        } else {
          ctx.fillStyle = '#111111';
          ctx.fillRect(0, 0, canvasSize, canvasSize);
        }
        if (strokeEnabled) {
          applyStrokeContext('center');
          ctx.strokeRect(0, 0, canvasSize, canvasSize);
        }
        if (onDone) onDone(canvas);
        if (prevAspect !== natAspect) {
          requestCanvasOverlayRender();
        }
      };

      if (video.readyState >= 2) {
        drawVideoFrame();
      } else {
        video.onloadeddata = drawVideoFrame;
        video.onerror = () => {
          applyShadowContext();
          ctx.fillStyle = '#FAB778';
          ctx.fillRect(pad, pad, shapeW, shapeH);
          if (onDone) onDone(canvas);
        };
      }
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const natW = img.naturalWidth || 512;
      const natH = img.naturalHeight || 512;
      const natAspect = (natW && natH) ? (natW / natH) : 1.0;
      const prevAspect = mediaNaturalRatioMap.get(id);
      mediaNaturalRatioMap.set(id, natAspect);
      if (fill.mediaUrl) mediaNaturalRatioMap.set(fill.mediaUrl, natAspect);
      fill.aspectRatio = natAspect;

      applyShadowContext();
      ctx.drawImage(img, 0, 0, canvasSize, canvasSize);
      if (strokeEnabled) {
        applyStrokeContext('center');
        ctx.strokeRect(0, 0, canvasSize, canvasSize);
      }
      if (onDone) onDone(canvas);
      applyTransformToThreeMesh(id, getLayerTransform(id));
      render3D();
      if (prevAspect !== natAspect) {
        requestCanvasOverlayRender();
      }
    };
    img.onerror = () => {
      applyShadowContext();
      ctx.fillStyle = '#FAB778';
      ctx.fillRect(pad, pad, shapeW, shapeH);
      if (strokeEnabled) {
        applyStrokeContext('center');
        ctx.strokeRect(pad, pad, shapeW, shapeH);
      }
      if (onDone) onDone(canvas);
    };
    img.src = fill.mediaUrl;
    return;
  }

  // Color or Gradient Fill
  applyShadowContext();

  let fillStyle = '#FAB778';
  if (fill.type === 'gradient' && fill.gradientStops) {
    const sorted = fill.gradientStops.slice().sort((a,b) => a.offset - b.offset);
    const gradType = fill.gradientType || 'linear';
    let g;
    if (gradType === 'radial') {
      g = ctx.createRadialGradient(cx, cy, 0, cx, cy, shapeW / 2);
    } else if (gradType === 'conical' || gradType === 'conic') {
      if (ctx.createConicGradient) {
        g = ctx.createConicGradient(0, cx, cy);
      } else {
        g = ctx.createLinearGradient(pad, cy, pad + shapeW, cy);
      }
    } else {
      g = ctx.createLinearGradient(pad, cy, pad + shapeW, cy);
    }
    sorted.forEach(s => {
      let col = s.color;
      if (s.alpha !== undefined && s.alpha < 1) {
        const p = parseHexOrRgbLocal(col);
        col = `rgba(${p.r}, ${p.g}, ${p.b}, ${s.alpha})`;
      }
      g.addColorStop(Math.max(0, Math.min(1, s.offset)), col);
    });
    fillStyle = g;
  } else {
    const p = parseHexOrRgbLocal(fill.color || '#FAB778');
    const alphaVal = (fill.alpha !== undefined) ? fill.alpha : (p.a !== undefined ? p.a : 1);
    fillStyle = `rgba(${p.r}, ${p.g}, ${p.b}, ${alphaVal})`;
  }

  ctx.fillStyle = fillStyle;

  if (shapeType === 'line') {
    ctx.strokeStyle = fillStyle;
    makeShapePath();
    ctx.stroke();
    if (strokeEnabled) {
      applyStrokeContext('center');
      makeShapePath();
      ctx.stroke();
    }
  } else if (shapeType === 'arrow') {
    ctx.strokeStyle = fillStyle;
    makeShapePath();
    ctx.stroke();

    const p = getLayerShapeParams(id, 'arrow');
    const pts = p.points && p.points.length >= 2 ? p.points : [{ x: -50, y: 0 }, { x: 50, y: 0 }];
    const canvasPts = pts.map(pt => ({
      x: cx + ((Number(pt.x) || 0) / 100) * (shapeW / 2),
      y: cy - ((Number(pt.y) || 0) / 100) * (shapeH / 2)
    }));
    const lastIdx = canvasPts.length - 1;
    const pPrev = canvasPts[lastIdx - 1];
    const pTip = canvasPts[lastIdx];
    const dx = pTip.x - pPrev.x;
    const dy = pTip.y - pPrev.y;
    const totalLen = Math.hypot(dx, dy) || 1;
    const ux = dx / totalLen;
    const uy = dy / totalLen;
    const actualHeadLen = Math.min(totalLen * 0.85, (p.headSize || 36) * scaleFactor);
    const headW = actualHeadLen * 0.85;
    const pBase = {
      x: pTip.x - ux * actualHeadLen,
      y: pTip.y - uy * actualHeadLen
    };
    const nx = -uy * headW;
    const ny = ux * headW;

    ctx.fillStyle = fillStyle;
    ctx.beginPath();
    ctx.moveTo(pTip.x, pTip.y);
    ctx.lineTo(pBase.x + nx, pBase.y + ny);
    ctx.lineTo(pBase.x + nx * 0.35, pBase.y + ny * 0.35);
    ctx.lineTo(pBase.x - nx * 0.35, pBase.y - ny * 0.35);
    ctx.lineTo(pBase.x - nx, pBase.y - ny);
    ctx.closePath();
    ctx.fill();

    if (strokeEnabled) {
      applyStrokeContext('center');
      makeShapePath();
      ctx.stroke();
    }
  } else {
    // Other shapes (circle, square, triangle, heart, star, hexagon, round)
    const curShapeP = getLayerShapeParams(id, shapeType);
    const isOutlineOnly = curShapeP && curShapeP.renderMode === 'outline';
    if (isOutlineOnly) {
      ctx.strokeStyle = fillStyle;
      ctx.lineWidth = Math.max(2, (curShapeP.thickness || 14) * scaleFactor);
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      makeShapePath();
      ctx.stroke();
    } else {
      makeShapePath();
      ctx.fill();
    }
    if (strokeEnabled) {
      if (strokeAlign === 'inside') {
        ctx.save();
        makeShapePath(); ctx.clip();
        applyStrokeContext('inside');
        makeShapePath(); ctx.stroke();
        ctx.restore();
      } else if (strokeAlign === 'outside') {
        applyStrokeContext('outside');
        makeShapePath(); ctx.stroke();
        ctx.save();
        makeShapePath(); ctx.clip();
        ctx.fillStyle = fillStyle;
        ctx.fill();
        ctx.restore();
      } else {
        applyStrokeContext('center');
        makeShapePath(); ctx.stroke();
      }
    }
  }

  if (onDone) onDone(canvas);
}

const layerBaseCanvasMap = new Map();
const layerBlurTextureCache = new Map();

function getBlurredTextureForLayer(id, blurPx) {
  const baseCanvas = layerBaseCanvasMap.get(id);
  if (!baseCanvas) return null;
  const qBlur = Math.min(32, Math.max(0, Math.round(blurPx || 0)));
  const key = id + '_' + qBlur;
  let cached = layerBlurTextureCache.get(key);
  if (cached) return cached;

  if (qBlur === 0) {
    const tex = new THREE.CanvasTexture(baseCanvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.generateMipmaps = false;
    tex.minFilter = THREE.LinearFilter;
    tex.magFilter = THREE.LinearFilter;
    layerBlurTextureCache.set(key, tex);
    return tex;
  }

  const blurCanvas = document.createElement('canvas');
  blurCanvas.width = baseCanvas.width;
  blurCanvas.height = baseCanvas.height;
  const bCtx = blurCanvas.getContext('2d');
  bCtx.filter = `blur(${qBlur}px)`;
  bCtx.drawImage(baseCanvas, 0, 0);

  const tex = new THREE.CanvasTexture(blurCanvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.generateMipmaps = false;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  layerBlurTextureCache.set(key, tex);
  return tex;
}


// ══════════════════════════════════════════════════════════════
// GLOBAL MEDIA STORAGE & VIDEO FRAME SEQUENCE SYSTEM
// ══════════════════════════════════════════════════════════════
const layerVideoTextureMap = new Map(); // layerId -> THREE.VideoTexture
const videoFrameSequenceMap = new Map(); // mediaId/url/name -> { fps, duration, frames, width, height, aspectRatio, audioUrl, isReady }
const layerFrameTextureMap = new Map();
const layerLastRenderedFrameIndex = new Map(); // layerId -> frameIndex // layerId -> THREE.CanvasTexture



// ----------------------------------------------------
// Global Media Pool / Library (Synchronized across panels)
// ----------------------------------------------------

function applyFillToMeshGlobal(id) {
  const fill = getLayerFill(id);
  if (!fill) return;
  const bs = (typeof getLayerBorderShadow === 'function') ? getLayerBorderShadow(id) : null;
  const mesh = meshLayerMap.get(id);
  if (!mesh || !mesh.material) return;
  const t = getLayerTransform(id);
  const transformOpacity = (t && t.opacity !== undefined) ? (t.opacity / 100) : 1;

  const row = document.querySelector(`.track-row[data-layer-id="${id}"]`);
  const clipName = row?.querySelector('.track-clip-name')?.textContent.trim() || '';

  // 1. High Speed Frame Sequence (PNG/Bitmap Sequence) Rendering (Synchronous, Zero Delay)
  const isPkg = fill.mediaUrl && (fill.mediaUrl.startsWith('video_pkg_') || fill.mediaUrl.startsWith('pkg_'));
  const seq = videoFrameSequenceMap.get(fill.mediaUrl) || videoFrameSequenceMap.get(id) || (clipName && videoFrameSequenceMap.get(clipName));
  if (seq || isPkg) {
    if (!seq || !seq.isReady || !seq.frames || seq.frames.length === 0) {
      const notReadyTex = getNotReadyVideoTexture(getMediaAspectRatio(id, fill?.mediaUrl));
      if (mesh.material.map !== notReadyTex) {
        mesh.material.map = notReadyTex;
        mesh.material.color = new THREE.Color('#FFFFFF');
        mesh.material.transparent = true;
        mesh.material.needsUpdate = true;
      }
      mesh.material.opacity = transformOpacity;
      return;
    }
    const clip = row ? row.querySelector('.track-clip') : null;
    const startTime = clip ? (parseFloat(clip.style.marginLeft) || 0) / PX_PER_SEC : 0;
    const localTime = Math.max(0, elapsed - startTime);
    const frameIndex = Math.min(seq.frames.length - 1, Math.max(0, Math.floor(localTime * (seq.fps || 30))));
    const currentFrame = seq.frames[frameIndex];

    if (!currentFrame || (currentFrame.width === 0 && (!currentFrame.naturalWidth || currentFrame.naturalWidth === 0))) {
      const notReadyTex = getNotReadyVideoTexture(getMediaAspectRatio(id, fill?.mediaUrl));
      if (mesh.material.map !== notReadyTex) {
        mesh.material.map = notReadyTex;
        mesh.material.color = new THREE.Color('#FFFFFF');
        mesh.material.transparent = true;
        mesh.material.needsUpdate = true;
      }
      mesh.material.opacity = transformOpacity;
      return;
    }

    const lastIndex = layerLastRenderedFrameIndex.get(id);
    let fTex = layerFrameTextureMap.get(id);
    if (!fTex) {
      fTex = new THREE.CanvasTexture(currentFrame);
      fTex.colorSpace = THREE.SRGBColorSpace;
      fTex.minFilter = THREE.LinearFilter;
      fTex.magFilter = THREE.LinearFilter;
      fTex.generateMipmaps = false;
      fTex.flipY = true;
      layerFrameTextureMap.set(id, fTex);
      layerLastRenderedFrameIndex.set(id, frameIndex);
    } else if (lastIndex !== frameIndex || fTex.image !== currentFrame) {
      fTex.image = currentFrame;
      fTex.generateMipmaps = false;
      fTex.flipY = true;
      fTex.needsUpdate = true;
      layerLastRenderedFrameIndex.set(id, frameIndex);
    }

    if (mesh.material.map !== fTex) {
      mesh.material.map = fTex;
      mesh.material.color = new THREE.Color('#FFFFFF');
      mesh.material.transparent = true;
      mesh.material.needsUpdate = true;
    }
    mesh.material.opacity = transformOpacity;

    if (seq.aspectRatio) {
      mediaNaturalRatioMap.set(id, seq.aspectRatio);
      fill.aspectRatio = seq.aspectRatio;
    }
    return;
  }

  if (pendingTextureRenders.has(id)) {
    cancelAnimationFrame(pendingTextureRenders.get(id));
  }
  const handle = requestAnimationFrame(() => {
    pendingTextureRenders.delete(id);

    const isVideo = (fill.type === 'media' && fill.mediaUrl && !fill.mediaUrl.startsWith('video_pkg_') && !fill.mediaUrl.startsWith('pkg_') && ((fill.mediaType && fill.mediaType.startsWith('video')) || fill.mediaUrl.startsWith('data:video/') || fill.mediaUrl.startsWith('blob:') || /\.(mp4|webm|mov|mkv|ogg)$/i.test(fill.mediaUrl)));

    if (isVideo) {
      let video = layerVideoMap.get(id);
      if (!video || video.src !== fill.mediaUrl) {
        if (video) {
          video.pause();
          video.removeAttribute("src"); try { video.load(); } catch(_) {}
        }
        video = document.createElement('video');
        video.src = fill.mediaUrl;
        video.crossOrigin = 'anonymous';
        video.playsInline = true;
        video.muted = true;
        video.preload = 'auto';
        layerVideoMap.set(id, video);
        try { video.load(); } catch(e) {}
      }

      let vTex = layerVideoTextureMap.get(id);
      if (!vTex || vTex.image !== video) {
        if (vTex) try { vTex.dispose(); } catch(_) {}
        vTex = new THREE.VideoTexture(video);
        vTex.colorSpace = THREE.SRGBColorSpace;
        vTex.minFilter = THREE.LinearFilter;
        vTex.magFilter = THREE.LinearFilter;
        vTex.generateMipmaps = false;
        layerVideoTextureMap.set(id, vTex);
      }

      const refreshVideoFrame = () => {
        vTex.needsUpdate = true;
        if (video.videoWidth && video.videoHeight) {
          const aspect = video.videoWidth / video.videoHeight;
          mediaNaturalRatioMap.set(id, aspect);
          if (fill.mediaUrl) mediaNaturalRatioMap.set(fill.mediaUrl, aspect);
          fill.aspectRatio = aspect;
        }
        render3D();
      };

      video.addEventListener('loadeddata', refreshVideoFrame, { once: true });
      video.addEventListener('loadedmetadata', refreshVideoFrame, { once: true });
      video.addEventListener('canplay', refreshVideoFrame, { once: true });
      video.addEventListener('seeked', refreshVideoFrame);

      vTex.needsUpdate = true;
      mesh.material.map = vTex;
      mesh.material.color = new THREE.Color('#FFFFFF');
      mesh.material.transparent = true;
      mesh.material.opacity = transformOpacity;
      mesh.material.needsUpdate = true;

      refreshVideoFrame();
      return;
    }

    renderLayerTexture(id, fill, bs, (canvas) => {
      layerBaseCanvasMap.set(id, canvas);

      // Invalidate old blur textures for this layer
      for (const k of Array.from(layerBlurTextureCache.keys())) {
        if (k.startsWith(id + '_')) {
          const oldTex = layerBlurTextureCache.get(k);
          if (oldTex) try { oldTex.dispose(); } catch(_) {}
          layerBlurTextureCache.delete(k);
        }
      }

      mesh.userData = mesh.userData || {};
      mesh.userData._currentBlurPx = 0;

      const tex = getBlurredTextureForLayer(id, 0);
      mesh.material.map = tex;
      mesh.material.color = new THREE.Color('#FFFFFF');
      mesh.material.transparent = true;
      mesh.material.depthTest = true;
      mesh.material.depthWrite = true;
      mesh.material.alphaTest = 0.02;
      mesh.material.side = THREE.DoubleSide;
      const fillAlpha = (() => {
        if (fill && fill.type === 'color') {
          const p = typeof parseHexOrRgbLocal === 'function' ? parseHexOrRgbLocal(fill.color || '#FAB778') : {a:1};
          return (fill.alpha !== undefined) ? fill.alpha : (p.a !== undefined ? p.a : 1);
        }
        return 1;
      })();
      mesh.material.opacity = Math.max(0, Math.min(1, transformOpacity * fillAlpha));
      mesh.material.needsUpdate = true;
      render3D();
    });
  });
  pendingTextureRenders.set(id, handle);
}

function getTextLayerDimensions(id) {
  const tData = (typeof getLayerText === 'function') ? getLayerText(id) : { content: 'Heading Title', font: 'Poppins', size: 48, align: 'center', bold: true, italic: false, underline: false, uppercase: false, letterSpacing: 0, lineHeight: 1.2 };
  const content = tData.content || 'Heading Title';
  const textToDraw = tData.uppercase ? content.toUpperCase() : content;
  const lines = textToDraw.split('\n');

  const canvas = (typeof document !== 'undefined' && document.createElement) ? document.createElement('canvas') : null;
  const ctx = canvas ? canvas.getContext('2d') : null;
  const fontSize = Math.max(10, (tData.size || 48)) * 2;
  const fontName = tData.font || 'Poppins';
  const isBold = !!tData.bold;
  const isItalic = !!tData.italic;
  const letterSpacing = (tData.letterSpacing || 0);
  const lineHeightRatio = (tData.lineHeight !== undefined ? tData.lineHeight : 1.2);
  const lineSpacingPx = fontSize * lineHeightRatio;

  let maxW = 100;
  if (ctx) {
    ctx.font = `${isItalic ? 'italic ' : ''}${isBold ? 'bold ' : 'normal '}${fontSize}px "${fontName}", sans-serif`;
    if ('letterSpacing' in ctx) {
      ctx.letterSpacing = `${letterSpacing}px`;
    }
    lines.forEach(l => {
      const w = ctx.measureText(l).width + (l.length * letterSpacing);
      if (w > maxW) maxW = w;
    });
  } else {
    maxW = content.length * fontSize * 0.6;
  }

  const totalH = (lines.length - 1) * lineSpacingPx + fontSize;
  const paddedW = Math.max(40, maxW + 28);
  const paddedH = Math.max(20, totalH + 16);

  const unitsW = (paddedW / 1024) * 4.0;
  const unitsH = (paddedH / 1024) * 4.0;

  return {
    widthUnits: unitsW,
    heightUnits: unitsH,
    pixelWidth: paddedW,
    pixelHeight: paddedH
  };
}
